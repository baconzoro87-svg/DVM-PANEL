import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createProxyMiddleware } from 'http-proxy-middleware';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3001', 10);
const API_TARGET = process.env.API_TARGET || 'http://127.0.0.1:3002';

console.log(`[dvm-panel-frontend] Proxy target set to: ${API_TARGET}`);

// Proxy API & Uploads without prefix stripping
app.use(createProxyMiddleware({
  pathFilter: ['/api', '/uploads', '/ws'],
  target: API_TARGET,
  changeOrigin: true,
  ws: true,
  logger: console
}));

// Serve static frontend build
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

// Fallback to index.html for SPA client-side routing
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log(`🌐 DVM Panel Web Interface running on http://0.0.0.0:${PORT}`);
  console.log(`📡 Connected to API Backend on ${API_TARGET}`);
  console.log('====================================================');
});
