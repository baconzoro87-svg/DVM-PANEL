import React, { useState } from 'react';
import { useOutletContext, Link } from 'react-router-dom';
import {
  Cpu,
  Layers,
  HardDrive,
  Activity,
  ArrowDownUp,
  Terminal,
  FolderTree,
  Archive,
  Copy,
  Check,
  Eye,
  EyeOff,
  Key,
  Radio,
  Server as ServerIcon,
  ShieldCheck,
  Code,
  Sliders,
  Settings,
  BarChart2,
  Network as NetIcon
} from 'lucide-react';
import GlassCard from '../../../components/GlassCard';
import StatCard from '../../../components/StatCard';

export default function ServerOverview() {
  const { server, stats } = useOutletContext();
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);
  const [copiedKey, setCopiedKey] = useState(null);
  const [showPassword, setShowPassword] = useState(false);

  const host = window.location.hostname || 'localhost';
  const sshUser = server.ssh_user || 'root';
  const sshPassword = server.ssh_password || 'root';
  const sshPort = server.port_ssh || 25501;
  const sshCmd = `ssh -p ${sshPort} ${sshUser}@${host}`;

  const copyToClipboard = (text, type) => {
    navigator.clipboard.writeText(text);
    if (type === 'cmd') {
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2000);
    } else if (type === 'pass') {
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    } else {
      setCopiedKey(type);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const cpuPercent = stats?.cpu_percent || 0;
  const memPercent = stats?.memory_percent || 0;
  const memUsageStr = stats?.memory_usage_str || `${server.memory_limit} allocated`;
  const netIO = stats?.network_io || '0B / 0B';
  const blockIO = stats?.block_io || '0B / 0B';

  // Parse environment variables passed at launch
  let envVarsObj = {};
  try {
    if (typeof server.env_vars === 'string') {
      envVarsObj = JSON.parse(server.env_vars || '{}');
    } else if (typeof server.env_vars === 'object' && server.env_vars !== null) {
      envVarsObj = server.env_vars;
    }
  } catch (e) {}

  if (!envVarsObj.VM_NAME) envVarsObj.VM_NAME = server.name;
  if (!envVarsObj.HOSTNAME) envVarsObj.HOSTNAME = server.hostname || server.name;
  if (!envVarsObj.RAM) envVarsObj.RAM = server.memory_limit || '1G';
  if (!envVarsObj.CPUS) envVarsObj.CPUS = server.cpu_limit || '1';
  if (!envVarsObj.DISK_SIZE) envVarsObj.DISK_SIZE = server.disk_limit || '10G';

  return (
    <div className="space-y-6">
      {/* Live Resource Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="CPU Load"
          value={`${cpuPercent}%`}
          subtitle={`${server.cpu_limit} Core(s) Limit`}
          icon={Cpu}
          color="brand"
          progress={cpuPercent}
        />

        <StatCard
          title="Memory (RAM)"
          value={memUsageStr}
          subtitle={`Limit: ${server.memory_limit}`}
          icon={Layers}
          color="purple"
          progress={memPercent}
        />

        <StatCard
          title="Network I/O"
          value={netIO}
          subtitle="Real-time Rx / Tx"
          icon={ArrowDownUp}
          color="cyan"
        />

        <StatCard
          title="Disk Storage"
          value={server.disk_limit || '10G'}
          subtitle={`Block I/O: ${blockIO}`}
          icon={HardDrive}
          color="emerald"
        />
      </div>

      {/* Main Details & SSH Guide */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: SSH Connection Info & Quick Links */}
        <div className="lg:col-span-2 space-y-6">
          {/* SSH Direct Connection Card */}
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-5 h-5 text-brand-400" />
                SSH Remote Connection (Terminal & SSH Clients)
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Port {sshPort} Active
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Connect directly to this virtual machine from your local terminal using OpenSSH, PuTTY, or VS Code Remote SSH.
            </p>

            <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-3 font-mono text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-300 pb-2 border-b border-white/10">
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans uppercase">Host</span>
                  <span className="text-white font-bold">{host}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans uppercase">SSH Port</span>
                  <span className="text-brand-300 font-bold">{sshPort}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-sans uppercase">User</span>
                  <span className="text-emerald-300 font-bold">{sshUser}</span>
                </div>
              </div>

              {/* SSH Command Line with Copy */}
              <div className="flex items-center justify-between gap-3 pt-1">
                <div className="overflow-hidden">
                  <span className="text-[10px] text-slate-400 font-sans block">SSH Command:</span>
                  <code className="text-emerald-400 font-bold truncate block text-xs select-all mt-0.5">{sshCmd}</code>
                </div>
                <button
                  onClick={() => copyToClipboard(sshCmd, 'cmd')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-sans font-semibold transition-all shrink-0"
                >
                  {copiedCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              {/* Password Line with Show/Hide & Copy */}
              <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/10">
                <div>
                  <span className="text-[10px] text-slate-400 font-sans block">Password:</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <code className="text-amber-300 font-bold text-xs select-all">
                      {showPassword ? sshPassword : '••••••••'}
                    </code>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-slate-400 hover:text-white"
                      title={showPassword ? 'Hide Password' : 'Show Password'}
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => copyToClipboard(sshPassword, 'pass')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-slate-200 text-xs font-sans font-semibold transition-all shrink-0"
                >
                  {copiedPass ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPass ? 'Copied' : 'Copy Password'}</span>
                </button>
              </div>
            </div>
          </GlassCard>

          {/* Quick Navigation Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <Link to={`/servers/${server.id}/console`} className="group">
              <GlassCard className="p-3.5 flex flex-col items-center text-center gap-2 hover:border-emerald-500/50">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Terminal className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-emerald-300">Terminal</h4>
                  <p className="text-[10px] text-slate-500">Live SSH</p>
                </div>
              </GlassCard>
            </Link>

            <Link to={`/servers/${server.id}/analytics`} className="group">
              <GlassCard className="p-3.5 flex flex-col items-center text-center gap-2 hover:border-purple-500/50">
                <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-purple-300">Analytics</h4>
                  <p className="text-[10px] text-slate-500">Live Graphs</p>
                </div>
              </GlassCard>
            </Link>

            <Link to={`/servers/${server.id}/network`} className="group">
              <GlassCard className="p-3.5 flex flex-col items-center text-center gap-2 hover:border-cyan-500/50">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <NetIcon className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-cyan-300">Network</h4>
                  <p className="text-[10px] text-slate-500">Port Mapping</p>
                </div>
              </GlassCard>
            </Link>

            <Link to={`/servers/${server.id}/files`} className="group">
              <GlassCard className="p-3.5 flex flex-col items-center text-center gap-2 hover:border-amber-500/50">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FolderTree className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-amber-300">Files</h4>
                  <p className="text-[10px] text-slate-500">SFTP Browser</p>
                </div>
              </GlassCard>
            </Link>

            <Link to={`/servers/${server.id}/settings`} className="group">
              <GlassCard className="p-3.5 flex flex-col items-center text-center gap-2 hover:border-brand-500/50">
                <div className="w-9 h-9 rounded-xl bg-brand-500/10 border border-brand-500/20 text-brand-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Settings className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-brand-300">Settings</h4>
                  <p className="text-[10px] text-slate-500">Quotas & Env</p>
                </div>
              </GlassCard>
            </Link>
          </div>
        </div>

        {/* Right Col: Instance Technical Specs */}
        <div>
          <GlassCard className="p-6 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ServerIcon className="w-5 h-5 text-emerald-400" />
              Instance Details
            </h3>

            <div className="space-y-2.5 text-xs font-mono divide-y divide-white/5">
              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-400 font-sans">Instance Name:</span>
                <span className="text-white font-bold">{server.name}</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-400 font-sans">Hostname:</span>
                <span className="text-slate-200">{server.hostname || server.name}</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-400 font-sans">OS Image:</span>
                <span className="text-brand-300 truncate max-w-[160px]">{server.image}</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-400 font-sans">Privileged Mode:</span>
                <span className="text-emerald-400 font-bold">Enabled (--privileged)</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-400 font-sans">Container ID:</span>
                <span className="text-slate-400">{server.container_id?.substring(0, 12) || 'Docker'}</span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-slate-400 font-sans">SSH Authentication:</span>
                <span className="text-slate-200">{sshUser}:{showPassword ? sshPassword : '***'}</span>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* Dedicated Container Environment Variables Card */}
      <GlassCard className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Container Environment Variables</h3>
              <p className="text-xs text-slate-400">
                Variables passed to the container at launch (<code className="text-brand-300">$VM_NAME</code>, <code className="text-brand-300">$HOSTNAME</code>, <code className="text-brand-300">$RAM</code>, <code className="text-brand-300">$CPUS</code>, <code className="text-brand-300">$DISK_SIZE</code>)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-xl text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {Object.keys(envVarsObj).length} Active Variables
            </span>
            <Link
              to={`/servers/${server.id}/settings`}
              className="px-3 py-1 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold border border-white/10"
            >
              Edit in Settings
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 font-mono text-xs">
          {Object.entries(envVarsObj).map(([key, val]) => (
            <div
              key={key}
              className="p-3.5 rounded-xl bg-black/40 border border-white/10 hover:border-cyan-500/30 transition-all flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-bold text-slate-400 font-sans tracking-wide">
                  ${key}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(`-e ${key}="${val}"`, `env-${key}`)}
                  className="p-1 text-slate-500 hover:text-white transition-colors"
                  title="Copy -e flag"
                >
                  {copiedKey === `env-${key}` ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
              <span className="text-emerald-300 font-bold truncate text-xs bg-black/30 px-2 py-1 rounded border border-white/5">
                {String(val)}
              </span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
