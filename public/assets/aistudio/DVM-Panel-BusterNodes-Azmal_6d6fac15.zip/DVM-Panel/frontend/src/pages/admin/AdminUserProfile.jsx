import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  User,
  Server,
  ArrowLeft,
  Shield,
  Layers,
  Cpu,
  HardDrive,
  Clock,
  Activity,
  Calendar,
  ExternalLink
} from 'lucide-react';
import { api } from '../../utils/api';
import GlassCard from '../../components/GlassCard';

export default function AdminUserProfile() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/admin/users/${id}`).then((res) => {
      if (res.success) {
        setData(res);
      }
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return <div className="py-20 text-center text-slate-400 text-xs">Loading user profile...</div>;
  }

  if (!data || !data.user) {
    return (
      <GlassCard className="p-8 text-center">
        <p className="text-rose-400 font-semibold text-sm">User not found.</p>
        <Link to="/admin/users" className="mt-4 inline-block px-4 py-2 rounded-xl bg-brand-500 text-white text-xs font-semibold">
          Back to User List
        </Link>
      </GlassCard>
    );
  }

  const { user, servers = [], activities = [], loginHistory = [] } = data;

  return (
    <div className="space-y-6">
      {/* Back button & User header */}
      <div>
        <Link to="/admin/users" className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 mb-2">
          <ArrowLeft className="w-4 h-4" /> Back to User Directory
        </Link>
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center font-bold text-lg text-brand-300">
            {user.username?.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white">{user.username}</h1>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                user.role === 'admin' ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30' : 'bg-white/5 text-slate-300 border border-white/10'
              }`}>
                {user.role}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{user.email}</p>
          </div>
        </div>
      </div>

      {/* Quota Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <GlassCard className="p-4 text-center">
          <span className="text-slate-400 text-xs block">VMs Deployed</span>
          <span className="text-2xl font-black text-white font-mono mt-1 block">
            {servers.length} / {user.max_servers || 3}
          </span>
        </GlassCard>

        <GlassCard className="p-4 text-center">
          <span className="text-slate-400 text-xs block">RAM Limit</span>
          <span className="text-2xl font-black text-purple-400 font-mono mt-1 block">
            {user.ram_limit || '2G'}
          </span>
        </GlassCard>

        <GlassCard className="p-4 text-center">
          <span className="text-slate-400 text-xs block">CPU Limit</span>
          <span className="text-2xl font-black text-cyan-400 font-mono mt-1 block">
            {user.cpu_limit || 2} Cores
          </span>
        </GlassCard>

        <GlassCard className="p-4 text-center">
          <span className="text-slate-400 text-xs block">Disk Quota</span>
          <span className="text-2xl font-black text-emerald-400 font-mono mt-1 block">
            {user.disk_limit || '20G'}
          </span>
        </GlassCard>
      </div>

      {/* Owned Servers */}
      <GlassCard className="p-6">
        <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <Server className="w-5 h-5 text-brand-400" />
          Virtual Machines Owned ({servers.length})
        </h3>

        {servers.length === 0 ? (
          <p className="text-xs text-slate-500 py-4 text-center">This user has not deployed any virtual machines yet.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {servers.map((s) => (
              <Link
                key={s.id}
                to={`/servers/${s.id}/overview`}
                className="p-4 rounded-xl bg-black/40 border border-white/10 hover:border-brand-500/40 transition-all block group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-white group-hover:text-brand-300 font-mono">{s.name}</span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                    s.status === 'running' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-500/20 text-slate-400'
                  }`}>
                    {s.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 font-mono truncate">{s.image}</p>
                <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-xs text-slate-300 font-mono">
                  <span>Port: {s.port_ssh}</span>
                  <span>{s.memory_limit} • {s.cpu_limit}C</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
}

