import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Server,
  Cpu,
  HardDrive,
  Layers,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Terminal,
  ShieldAlert,
  Sparkles,
  Info,
  Key,
  Lock,
  UserCheck,
  Code,
  Plus,
  X,
  RotateCw,
  Check,
  Star,
  Zap,
  Clock
} from 'lucide-react';
import { api } from '../../utils/api';
import { useTheme } from '../../context/ThemeContext';
import GlassCard from '../../components/GlassCard';
import CustomResourcePicker from '../../components/CustomResourcePicker';
import AutoSuspendPicker from '../../components/AutoSuspendPicker';

export default function CreateServer() {
  const navigate = useNavigate();
  const { supportedImages } = useTheme();

  const defaultImages = [
    { id: 'nobitaa/ubuntu:22', name: 'Ubuntu 22.04 LTS (Jammy)', icon: 'ubuntu', desc: 'Canonical Ubuntu 22.04 LTS (BusterNodes optimized container image)' },
    { id: 'nobitaa/ubuntu:24', name: 'Ubuntu 24.04 LTS (Noble)', icon: 'ubuntu', desc: 'Canonical Ubuntu 24.04 LTS with modern kernel tools' },
    { id: 'nobitaa/debain:11', name: 'Debian 11 (Bullseye)', icon: 'debian', desc: 'Debian GNU/Linux 11 stable lightweight base' },
    { id: 'nobitaa/debain:12', name: 'Debian 12 (Bookworm)', icon: 'debian', desc: 'Debian GNU/Linux 12 modern general purpose' },
    { id: 'nobitaa/debain:13', name: 'Debian 13 (Trixie)', icon: 'debian', desc: 'Debian GNU/Linux 13 latest testing/trixie release' }
  ];

  const imageList = supportedImages?.length > 0 ? supportedImages : defaultImages;

  // Steps State
  const [selectedImage, setSelectedImage] = useState(supportedImages[0]?.id || 'nobitaa/ubuntu:22');
  const [isCustomImage, setIsCustomImage] = useState(false);
  const [customImage, setCustomImage] = useState('');

  const [name, setName] = useState('vm1');
  const [hostname, setHostname] = useState('vm1');
  const [port, setPort] = useState('');
  const [portInfo, setPortInfo] = useState(null);
  const [portChecking, setPortChecking] = useState(false);
  const [portAvailable, setPortAvailable] = useState(true);

  const [ram, setRam] = useState('1G');
  const [cpus, setCpus] = useState('1');
  const [diskSize, setDiskSize] = useState('10G');

  // VM Full Custom Auto-Suspend Engine (Timer / Calendar / Daily Schedule)
  const [autoSuspendType, setAutoSuspendType] = useState('hours');
  const [autoSuspendHours, setAutoSuspendHours] = useState('0');
  const [autoSuspendAt, setAutoSuspendAt] = useState('');
  const [autoSuspendTime, setAutoSuspendTime] = useState('23:00');

  // SSH Auth Settings (Default root:root vs Custom)
  const [useCustomSsh, setUseCustomSsh] = useState(false);
  const [sshUser, setSshUser] = useState('root');
  const [sshPassword, setSshPassword] = useState('root');

  // Custom Environment Variables
  const [customEnvList, setCustomEnvList] = useState([]);
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvVal, setNewEnvVal] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [quota, setQuota] = useState(null);
  const [plans, setPlans] = useState([]);
  const [selectedPlanId, setSelectedPlanId] = useState(null);

  const parseRamToMb = (val) => {
    const s = String(val || '1G').trim().toUpperCase();
    if (s.endsWith('M')) return parseInt(s, 10) || 1024;
    if (s.endsWith('G')) return Math.round((parseFloat(s) || 1) * 1024);
    const num = parseFloat(s);
    return isNaN(num) ? 1024 : Math.round(num >= 32 ? num : num * 1024);
  };

  const parseDiskToGb = (val) => {
    const s = String(val || '10G').trim().toUpperCase();
    if (s.endsWith('T')) return Math.round((parseFloat(s) || 1) * 1024);
    if (s.endsWith('G')) return parseInt(s, 10) || 10;
    const num = parseInt(s, 10);
    return isNaN(num) ? 10 : num;
  };

  const fetchNextPort = async () => {
    try {
      setPortChecking(true);
      const res = await api.get('/ports/next-free');
      if (res.success && res.nextPort) {
        setPort(String(res.nextPort));
        setPortInfo(res);
        setPortAvailable(true);
      }
    } catch (e) {
      console.error('Failed to auto-fetch next port:', e);
    } finally {
      setPortChecking(false);
    }
  };

  const fetchUserQuota = async () => {
    try {
      const res = await api.get('/servers/user/quota');
      if (res.success && res.quota) {
        setQuota(res.quota);
      }
    } catch (e) {
      console.error('Failed to fetch quota:', e);
    }
  };

  const fetchPlans = async () => {
    try {
      const res = await api.get('/servers/plans');
      if (res.success && res.plans?.length > 0) {
        setPlans(res.plans);
        const def = res.plans.find(p => p.is_default) || res.plans[0];
        if (def) {
          setSelectedPlanId(def.id);
          setRam(def.max_ram);
          setCpus(String(def.max_cpu));
          setDiskSize(def.max_disk);
        }
      }
    } catch (e) {
      console.error('Failed to fetch plans:', e);
    }
  };

  const handleSelectPlan = (p) => {
    setSelectedPlanId(p.id);
    setRam(p.max_ram);
    setCpus(String(p.max_cpu));
    setDiskSize(p.max_disk);
  };

  // Real-time bidirectional auto-sync between fine-tune sliders and plan presets
  useEffect(() => {
    if (plans.length > 0) {
      const match = plans.find(p =>
        parseRamToMb(p.max_ram) === parseRamToMb(ram) &&
        parseInt(p.max_cpu, 10) === parseInt(cpus, 10) &&
        parseDiskToGb(p.max_disk) === parseDiskToGb(diskSize)
      );
      setSelectedPlanId(match ? match.id : null);
    }
  }, [ram, cpus, diskSize, plans]);

  const checkCustomPort = async (portVal) => {
    const num = parseInt(portVal, 10);
    if (!num || isNaN(num) || num < 25501 || num > 25599) {
      setPortAvailable(false);
      return;
    }
    try {
      const res = await api.get(`/ports/check?port=${num}`);
      if (res.success) {
        setPortAvailable(res.available);
      }
    } catch (e) {
      setPortAvailable(true);
    }
  };

  useEffect(() => {
    fetchNextPort();
    fetchUserQuota();
    fetchPlans();
  }, []);

  const effectiveImage = isCustomImage ? customImage : selectedImage;
  const effectiveSshUser = useCustomSsh ? sshUser.trim() : 'root';
  const effectiveSshPass = useCustomSsh ? sshPassword.trim() : 'root';

  const addCustomEnv = () => {
    const k = newEnvKey.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    if (!k) return;
    if (['VM_NAME', 'HOSTNAME', 'RAM', 'CPUS', 'DISK_SIZE'].includes(k)) {
      alert(`"${k}" is already handled automatically as a launch variable.`);
      return;
    }
    if (customEnvList.some(item => item.key === k)) {
      alert(`Environment variable "${k}" already added.`);
      return;
    }
    setCustomEnvList([...customEnvList, { key: k, value: newEnvVal.trim() }]);
    setNewEnvKey('');
    setNewEnvVal('');
  };

  const removeCustomEnv = (indexToRemove) => {
    setCustomEnvList(customEnvList.filter((_, idx) => idx !== indexToRemove));
  };

  const customEnvFlags = customEnvList
    .map(item => `  -e ${item.key}="${item.value}" \\`)
    .join('\n');

  const generatedDockerCommand = `docker run -d --privileged \\
  -p ${port || '25501'}:22 \\
  -e VM_NAME=${name || 'vm1'} \\
  -e HOSTNAME=${hostname || name || 'vm1'} \\
  -e RAM=${ram} \\
  -e CPUS=${cpus} \\
  -e DISK_SIZE=${diskSize} \\
${customEnvFlags ? `${customEnvFlags}\n` : ''}  --name ${name || 'vm1'} \\
  ${effectiveImage || 'nobitaa/ubuntu:22'}`;

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');

    if (!effectiveImage) {
      return setError('Please select or specify a Docker image.');
    }

    if (!name || name.trim().length === 0) {
      return setError('VM Name is required.');
    }

    if (portAvailable === false) {
      return setError(`Selected Port ${port} is currently in use or out of range (25501-25599). Please click Auto-Scan or choose a free port.`);
    }

    setLoading(true);

    const customEnvObj = {};
    customEnvList.forEach(item => {
      if (item.key.trim()) {
        customEnvObj[item.key.trim()] = item.value;
      }
    });

    try {
      const res = await api.post('/servers', {
        name: name.trim().toLowerCase(),
        hostname: hostname.trim() || name.trim(),
        image: effectiveImage,
        port_ssh: port ? parseInt(port, 10) : undefined,
        memory_limit: ram,
        cpu_limit: cpus,
        disk_limit: diskSize,
        env_vars: customEnvObj,
        ssh_user: effectiveSshUser,
        ssh_password: effectiveSshPass,
        auto_suspend_type: autoSuspendType,
        auto_suspend_hours: parseInt(autoSuspendHours, 10) || 0,
        auto_suspend_at: autoSuspendType === 'datetime' ? autoSuspendAt : null,
        auto_suspend_time: autoSuspendType === 'daily_time' ? autoSuspendTime : ''
      });

      if (res.success && res.server) {
        navigate(`/servers/${res.server.id}/overview`);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <Server className="w-6 h-6 text-brand-400" />
          Deploy New Virtual Machine
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Launch a Docker VM instance with auto port allocation (25501-25599), environment variables, and privileged root access.
        </p>
      </div>

      {/* User Quota Limits Banner */}
      {quota && !quota.isAdmin && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900/20 via-brand-900/20 to-cyan-900/20 border border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">Your Resource Limits & Quota</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-brand-500/20 text-brand-300 border border-brand-500/30 font-bold">
                {quota.used.totalServersOwned} / {quota.limits.maxServers} VMs Used
              </span>
            </div>
            <p className="text-xs text-slate-400">
              You can allocate up to your remaining available quota for this new virtual machine.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 font-mono text-xs">
            <div className="px-3 py-1.5 rounded-xl bg-black/40 border border-purple-500/30 text-purple-300">
              <span className="text-[10px] text-slate-400 block font-sans">Available RAM:</span>
              <span className="font-bold text-white">{quota.available.ramStr}</span> <span className="text-[10px] text-slate-400">/ {quota.limits.ramStr}</span>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-black/40 border border-cyan-500/30 text-cyan-300">
              <span className="text-[10px] text-slate-400 block font-sans">Available CPU:</span>
              <span className="font-bold text-white">{quota.available.cpu} Core(s)</span> <span className="text-[10px] text-slate-400">/ {quota.limits.cpu}C</span>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-black/40 border border-emerald-500/30 text-emerald-300">
              <span className="text-[10px] text-slate-400 block font-sans">Available Disk:</span>
              <span className="font-bold text-white">{quota.available.diskStr}</span> <span className="text-[10px] text-slate-400">/ {quota.limits.diskStr}</span>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-3 animate-fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleCreate} className="space-y-6">
        {/* STEP 1: Image Selection */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">1</span>
              Select Operating System Image
            </h2>
            <span className="text-[11px] text-slate-400">Supported OS Templates</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {imageList.map((img) => {
              const isSelected = !isCustomImage && selectedImage === img.id;
              return (
                <div
                  key={img.id}
                  onClick={() => {
                    setSelectedImage(img.id);
                    setIsCustomImage(false);
                  }}
                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-brand-500/15 border-brand-500 shadow-glass-glow'
                      : 'bg-black/30 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold font-mono text-white">{img.id}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-brand-400" />}
                  </div>
                  <p className="text-xs font-semibold text-slate-200">{img.name}</p>
                  <p className="text-[10px] text-slate-400 mt-1">{img.desc || 'High performance container'}</p>
                </div>
              );
            })}
          </div>

          {/* Custom Docker Image Option */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <div
              onClick={() => setIsCustomImage(!isCustomImage)}
              className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-300 hover:text-white"
            >
              <input
                type="checkbox"
                checked={isCustomImage}
                onChange={() => {}}
                className="rounded text-brand-500"
              />
              <span>Or specify custom Docker Hub Image tag</span>
            </div>

            {isCustomImage && (
              <div className="mt-3">
                <input
                  type="text"
                  value={customImage}
                  onChange={(e) => setCustomImage(e.target.value)}
                  placeholder="e.g. archlinux:latest or alpine:3.18"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>
            )}
          </div>
        </GlassCard>

        {/* STEP 2: Name & Network with Auto Port Allocation */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">2</span>
              VM Name & Auto Port Allocation
            </h2>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" /> Auto Allocation Pool: 25501-25599
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">VM Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                placeholder="vm1"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Used for container name & $VM_NAME</span>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Hostname</label>
              <input
                type="text"
                value={hostname}
                onChange={(e) => setHostname(e.target.value)}
                placeholder="vm1"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Internal Linux VM hostname</span>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-slate-300">SSH Port (Auto-Allocated)</label>
                <button
                  type="button"
                  onClick={fetchNextPort}
                  className="text-[10px] text-brand-300 hover:text-brand-200 flex items-center gap-1 transition-colors"
                  title="Scan & allocate next free port"
                >
                  <RotateCw className={`w-3 h-3 ${portChecking ? 'animate-spin' : ''}`} />
                  <span>Auto-Scan</span>
                </button>
              </div>

              <div className="relative">
                <input
                  type="number"
                  value={port}
                  onChange={(e) => {
                    setPort(e.target.value);
                    checkCustomPort(e.target.value);
                  }}
                  placeholder="e.g. 25501"
                  min="25501"
                  max="25599"
                  className="w-full px-4 py-2.5 pr-20 rounded-xl bg-black/40 border border-white/10 text-brand-300 font-mono text-xs font-bold focus:outline-none focus:border-brand-500"
                />
                <div className="absolute right-2.5 top-2.5">
                  {portAvailable === true ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      <Check className="w-3 h-3" /> Free
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                      <AlertCircle className="w-3 h-3" /> In Use
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                <span>Range: 25501 - 25599</span>
                {portInfo && (
                  <span className="text-emerald-400 font-mono">
                    {portInfo.freeCount} free ports available
                  </span>
                )}
              </div>
            </div>
          </div>
        </GlassCard>

        {/* STEP 3: Plan Presets & Hardware Resource Allocation */}
        <GlassCard className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">3</span>
                Resource Plan Presets & Hardware Allocation
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Choose a pre-configured plan tier or customize exact hardware resources below.
              </p>
            </div>
            <span className="text-[11px] text-purple-300 font-mono flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-purple-400" /> 1-Click Plan Presets
            </span>
          </div>

          {/* Plan Presets Grid */}
          {plans.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                Available Plan Presets:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {plans.map((p) => {
                  const isSelected = selectedPlanId === p.id || (
                    ram.toUpperCase() === p.max_ram.toUpperCase() &&
                    String(cpus) === String(p.max_cpu) &&
                    diskSize.toUpperCase() === p.max_disk.toUpperCase()
                  );

                  const exceedsRam = quota && !quota.isAdmin && parseRamToMb(p.max_ram) > quota.available.ramMb;
                  const exceedsCpu = quota && !quota.isAdmin && p.max_cpu > quota.available.cpu;
                  const exceedsDisk = quota && !quota.isAdmin && parseDiskToGb(p.max_disk) > quota.available.diskGb;
                  const exceedsQuota = exceedsRam || exceedsCpu || exceedsDisk;

                  return (
                    <div
                      key={p.id}
                      onClick={() => handleSelectPlan(p)}
                      className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between space-y-3 relative ${
                        isSelected
                          ? 'bg-purple-900/25 border-purple-500 shadow-glass-glow ring-1 ring-purple-500/40'
                          : 'bg-black/35 border-white/10 hover:border-purple-500/40 hover:bg-black/50'
                      } ${exceedsQuota ? 'opacity-70' : ''}`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs font-bold text-white tracking-wide">{p.name}</span>
                            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-bold font-mono">
                              {p.price || '₹0 / Free'}
                            </span>
                            {p.is_default === 1 && (
                              <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[9px] font-bold uppercase flex items-center gap-0.5">
                                <Star className="w-2.5 h-2.5 fill-purple-400 text-purple-400" /> Default
                              </span>
                            )}
                          </div>
                          {isSelected ? (
                            <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                          ) : (
                            <div className="w-4 h-4 rounded-full border border-white/20 shrink-0" />
                          )}
                        </div>

                        <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-[11px]">
                          <div className="p-1.5 rounded-lg bg-black/40 border border-purple-500/20 text-purple-300">
                            <span className="text-[9px] text-slate-400 block font-sans">RAM</span>
                            <strong>{p.max_ram}</strong>
                          </div>
                          <div className="p-1.5 rounded-lg bg-black/40 border border-cyan-500/20 text-cyan-300">
                            <span className="text-[9px] text-slate-400 block font-sans">CPU</span>
                            <strong>{p.max_cpu}C</strong>
                          </div>
                          <div className="p-1.5 rounded-lg bg-black/40 border border-emerald-500/20 text-emerald-300">
                            <span className="text-[9px] text-slate-400 block font-sans">Disk</span>
                            <strong>{p.max_disk}</strong>
                          </div>
                        </div>
                      </div>

                      {exceedsQuota && (
                        <div className="text-[10px] text-amber-300/90 font-sans flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-400 shrink-0" />
                          <span>Exceeds your available quota</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Fine Tuning Sliders & Manual Inputs */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Fine-Tune Hardware Resources (Sliders & Custom Inputs):
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Current: {ram} RAM • {cpus} Core(s) • {diskSize} Disk
              </span>
            </div>
            <CustomResourcePicker
              ram={ram}
              setRam={setRam}
              cpus={cpus}
              setCpus={setCpus}
              diskSize={diskSize}
              setDiskSize={setDiskSize}
            />
          </div>
        </GlassCard>

        {/* STEP 4: SSH Authentication */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">4</span>
              SSH Credentials & Authentication
            </h2>
            <span className="text-[11px] text-brand-300 font-mono">
              {useCustomSsh ? 'Custom User/Pass' : 'Default (root:root)'}
            </span>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => {
                  setUseCustomSsh(false);
                  setSshUser('root');
                  setSshPassword('root');
                }}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  !useCustomSsh ? 'bg-brand-500/15 border-brand-500 shadow-glass-glow' : 'bg-black/30 border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-white">Default SSH Credentials</span>
                  {!useCustomSsh && <CheckCircle2 className="w-4 h-4 text-brand-400" />}
                </div>
                <div className="font-mono text-xs text-emerald-400 space-y-0.5">
                  <div>User: <strong className="text-white">root</strong></div>
                  <div>Password: <strong className="text-amber-300">root</strong></div>
                </div>
                <p className="text-[10px] text-slate-400 mt-2 font-mono">
                  ssh -p {port || '25501'} root@localhost
                </p>
              </div>

              <div
                onClick={() => setUseCustomSsh(true)}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  useCustomSsh ? 'bg-brand-500/15 border-brand-500 shadow-glass-glow' : 'bg-black/30 border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-white">Custom SSH Username & Password</span>
                  {useCustomSsh && <CheckCircle2 className="w-4 h-4 text-brand-400" />}
                </div>
                <p className="text-[11px] text-slate-400">
                  Configure custom login credentials for SSH remote access.
                </p>
              </div>
            </div>

            {useCustomSsh && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-black/40 border border-white/10 animate-fade-in">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Custom SSH User</label>
                  <input
                    type="text"
                    required
                    value={sshUser}
                    onChange={(e) => setSshUser(e.target.value)}
                    placeholder="e.g. ubuntu or admin"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Custom SSH Password</label>
                  <input
                    type="text"
                    required
                    value={sshPassword}
                    onChange={(e) => setSshPassword(e.target.value)}
                    placeholder="e.g. secretpassword"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                  />
                </div>
              </div>
            )}
          </div>
        </GlassCard>

        {/* STEP 5: Container Environment Variables */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">5</span>
              Container Environment Variables
            </h2>
            <span className="text-[11px] text-cyan-300 font-mono">
              Passed at launch (-e)
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-sans">
                Automatic System Launch Variables:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 font-mono text-xs">
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-slate-500 block">$VM_NAME</span>
                  <span className="text-emerald-300 font-bold truncate block">{name || 'vm1'}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-slate-500 block">$HOSTNAME</span>
                  <span className="text-emerald-300 font-bold truncate block">{hostname || name || 'vm1'}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-slate-500 block">$RAM</span>
                  <span className="text-purple-300 font-bold block">{ram}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-slate-500 block">$CPUS</span>
                  <span className="text-cyan-300 font-bold block">{cpus}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-slate-500 block">$DISK_SIZE</span>
                  <span className="text-emerald-300 font-bold block">{diskSize}</span>
                </div>
              </div>
            </div>

            {/* Custom Variables */}
            {customEnvList.length > 0 && (
              <div className="space-y-2 pt-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block font-sans">
                  Custom Added Variables:
                </span>
                {customEnvList.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 font-mono text-xs">
                    <div className="w-1/3 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-cyan-300 font-bold truncate">
                      ${item.key}
                    </div>
                    <div className="flex-1 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono text-xs truncate">
                      {item.value}
                    </div>
                    <button
                      type="button"
                      onClick={() => removeCustomEnv(idx)}
                      className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                      title="Remove"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add bar */}
            <div className="flex flex-col sm:flex-row items-center gap-2 p-3 rounded-2xl bg-black/30 border border-dashed border-white/15">
              <input
                type="text"
                value={newEnvKey}
                onChange={(e) => setNewEnvKey(e.target.value)}
                placeholder="KEY (e.g. APP_ENV)"
                className="w-full sm:w-1/3 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-cyan-300 font-mono text-xs uppercase focus:outline-none focus:border-cyan-500"
              />
              <input
                type="text"
                value={newEnvVal}
                onChange={(e) => setNewEnvVal(e.target.value)}
                placeholder="VALUE (e.g. production or 8080)"
                className="w-full sm:flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
              <button
                type="button"
                onClick={addCustomEnv}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-bold border border-cyan-500/30 flex items-center justify-center gap-1.5 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Variable</span>
              </button>
            </div>
          </div>
        </GlassCard>

        {/* STEP 6: VM Auto-Suspend & Power-Saving Engine (Timer / Calendar / Daily) */}
        <GlassCard className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10 mb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-brand-500 text-white text-xs flex items-center justify-center font-mono">6</span>
                Auto-Suspend & Sleep Automation Policy
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Automatically stop and suspend this VM container by continuous runtime timer, exact calendar date & time, or daily recurring schedule.
              </p>
            </div>
            <span className="text-[11px] text-amber-300 font-mono flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" /> Full Custom Auto-Sleep
            </span>
          </div>

          <AutoSuspendPicker
            suspendType={autoSuspendType}
            setSuspendType={setAutoSuspendType}
            suspendHours={autoSuspendHours}
            setSuspendHours={setAutoSuspendHours}
            suspendAt={autoSuspendAt}
            setSuspendAt={setAutoSuspendAt}
            suspendTime={autoSuspendTime}
            setSuspendTime={setAutoSuspendTime}
          />
        </GlassCard>

        {/* Live Docker Command Preview Box */}
        <GlassCard className="p-5 bg-black/60 border-white/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-brand-400" /> Docker Run Command:
            </span>
            <span className="text-[10px] text-brand-400 font-mono">--privileged mode</span>
          </div>
          <pre className="p-3.5 rounded-xl bg-[#090b10] text-emerald-400 text-xs font-mono overflow-x-auto leading-relaxed border border-white/5">
            {generatedDockerCommand}
          </pre>
        </GlassCard>

        {/* Submit */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="px-5 py-2.5 rounded-xl glass-panel text-slate-400 hover:text-white text-xs font-medium transition-colors"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={loading || portAvailable === false}
            className="px-6 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-brand-500/25 flex items-center gap-2 disabled:opacity-50 transition-all"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Deploying VM...</span>
              </>
            ) : (
              <>
                <span>Launch Virtual Machine</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
