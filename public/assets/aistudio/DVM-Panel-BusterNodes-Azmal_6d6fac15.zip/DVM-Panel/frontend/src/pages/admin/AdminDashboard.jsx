import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Shield,
  Activity,
  Server,
  Users,
  Cpu,
  Layers,
  HardDrive,
  CheckCircle2,
  AlertCircle,
  Plus,
  Settings,
  Terminal,
  Clock,
  RefreshCw,
  Wrench
} from 'lucide-react';
import { api } from '../../utils/api';
import GlassCard from '../../components/GlassCard';
import StatCard from '../../components/StatCard';

export default function AdminDashboard() {
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchOverview = async () => {
    try {
      const res = await api.get('/admin/overview');
      if (res.success) {
        setOverview(res);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOverview();
    const interval = setInterval(fetchOverview, 5000);
    return () => clearInterval(interval);
  }, []);

  const stats = overview?.stats;
  const docker = overview?.docker;
  const recentActivity = overview?.recentActivity || [];
  const recentLogins = overview?.recentLogins || [];

  const formatBytes = (bytes) => {
    if (!bytes) return '0 GB';
    const gb = bytes / (1024 * 1024 * 1024);
    return `${gb.toFixed(1)} GB`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Shield className="w-6 h-6 text-brand-400" />
            Admin System Monitoring
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time host node hardware metrics, Docker hypervisor status, and user activities.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchOverview}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Refresh Metrics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <Link
            to="/admin/servers/create"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create Server (Admin)</span>
          </Link>
        </div>
      </div>

      {loading && !overview ? (
        <div className="py-20 text-center text-slate-400 text-xs">
          <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          Gathering node hardware telemetry...
        </div>
      ) : (
        <>
          {/* Host Resources Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Host CPU Load"
              value={`${stats?.cpu?.load_percent || 0}%`}
              subtitle={`${stats?.cpu?.cores || 1} Cores (${stats?.cpu?.model?.substring(0, 20)}...)`}
              icon={Cpu}
              color="brand"
              progress={stats?.cpu?.load_percent || 0}
            />

            <StatCard
              title="Host RAM Memory"
              value={`${formatBytes(stats?.memory?.used_bytes)} / ${formatBytes(stats?.memory?.total_bytes)}`}
              subtitle={`${stats?.memory?.used_percent || 0}% Utilized`}
              icon={Layers}
              color="purple"
              progress={stats?.memory?.used_percent || 0}
            />

            <StatCard
              title="Host Disk Storage"
              value={`${formatBytes(stats?.disk?.used_bytes)} / ${formatBytes(stats?.disk?.total_bytes)}`}
              subtitle={`${stats?.disk?.used_percent || 0}% Disk Used`}
              icon={HardDrive}
              color="emerald"
              progress={stats?.disk?.used_percent || 0}
            />

            <StatCard
              title="Virtual Machines"
              value={`${stats?.overview?.running_servers || 0} / ${stats?.overview?.total_servers || 0}`}
              subtitle={`${stats?.overview?.total_users || 1} Registered Users`}
              icon={Server}
              color="cyan"
            />
          </div>

          {/* Docker & Node Health Info */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Docker Engine & Quick Controls */}
            <div className="lg:col-span-2 space-y-6">
              <GlassCard className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Activity className="w-5 h-5 text-brand-400" />
                    Docker Hypervisor Engine Status
                  </h3>
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                    docker?.ok ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${docker?.ok ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                    {docker?.ok ? 'Operational' : 'Engine Offline'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-slate-400 block font-sans">Docker Version</span>
                    <span className="text-slate-200 font-bold">{docker?.version || 'Docker API'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-slate-400 block font-sans">Host OS</span>
                    <span className="text-slate-200 font-bold">{stats?.os?.distro || 'Linux'}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-slate-400 block font-sans">Node Uptime</span>
                    <span className="text-slate-200 font-bold">{Math.round((stats?.os?.uptime_seconds || 0) / 3600)} Hours</span>
                  </div>
                  <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-[10px] text-slate-400 block font-sans">Kernel</span>
                    <span className="text-slate-200 font-bold truncate block">{stats?.os?.release?.substring(0, 12) || 'Linux'}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2.5 mt-4 pt-4 border-t border-white/10">
                  <Link
                    to="/admin/servers"
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
                  >
                    <Server className="w-4 h-4 text-brand-400" />
                    <span>Manage All Servers ({stats?.overview?.total_servers})</span>
                  </Link>

                  <Link
                    to="/admin/users"
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
                  >
                    <Users className="w-4 h-4 text-cyan-400" />
                    <span>User Directory ({stats?.overview?.total_users})</span>
                  </Link>

                  <Link
                    to="/admin/settings"
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
                  >
                    <Settings className="w-4 h-4 text-purple-400" />
                    <span>Branding & Appearance</span>
                  </Link>
                </div>
              </GlassCard>

              {/* System Audit Activity */}
              <GlassCard className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-teal-400" />
                    Recent System Actions
                  </h3>
                  <Link to="/admin/settings" className="text-xs text-brand-400 hover:underline">
                    View Full Logs
                  </Link>
                </div>

                {recentActivity.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">No system activity logged yet.</p>
                ) : (
                  <div className="space-y-2">
                    {recentActivity.slice(0, 5).map((act) => (
                      <div key={act.id} className="p-2.5 rounded-xl bg-black/30 border border-white/5 flex items-center justify-between text-xs font-sans">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-brand-500/10 text-brand-300 border border-brand-500/20">
                            {act.action}
                          </span>
                          <span className="text-slate-300 truncate max-w-sm">{act.details}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono shrink-0">
                          {new Date(act.created_at).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </GlassCard>
            </div>

            {/* Right Col: Recent User Logins */}
            <div>
              <GlassCard className="p-6 space-y-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-400" />
                  Recent User Logins
                </h3>

                {recentLogins.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">No login history recorded.</p>
                ) : (
                  <div className="space-y-2.5">
                    {recentLogins.slice(0, 6).map((log) => (
                      <div key={log.id} className="p-3 rounded-xl bg-black/40 border border-white/5 text-xs font-sans">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white">{log.username}</span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                            log.status === 'success' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                          }`}>
                            {log.status}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1 font-mono">
                          <span>IP: {log.ip_address || '127.0.0.1'}</span>
                          <span>{new Date(log.created_at).toLocaleTimeString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </GlassCard>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

