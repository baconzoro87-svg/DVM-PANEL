import React, { useState, useEffect } from 'react';
import {
  Settings,
  Image,
  Music,
  Sliders,
  Palette,
  Shield,
  Mail,
  Wrench,
  Key,
  Layers,
  Activity,
  Share2,
  Upload,
  Play,
  Pause,
  Volume2,
  Save,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ExternalLink,
  Trash2,
  Plus,
  Edit,
  Star,
  Clock,
  Zap
} from 'lucide-react';
import { api } from '../../utils/api';
import { useTheme } from '../../context/ThemeContext';
import GlassCard from '../../components/GlassCard';
import Modal from '../../components/Modal';
import WallpaperBrowser from '../../components/WallpaperBrowser';

export default function AdminSettings() {
  const {
    settings,
    updateSettingsLocally,
    fetchPublicSettings,
    wallpaperCategories = []
  } = useTheme();

  const [activeTab, setActiveTab] = useState('general');
  const [form, setForm] = useState({ ...settings });
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  // Keep form updated if settings load asynchronously
  useEffect(() => {
    if (settings && Object.keys(settings).length > 0) {
      setForm(prev => ({ ...settings, ...prev }));
    }
  }, [settings]);

  // Toolbox state
  const [dockerImages, setDockerImages] = useState([]);
  const [pruning, setPruning] = useState(false);
  const [pruneResult, setPruneResult] = useState('');

  // API Keys state
  const [apiKeys, setApiKeys] = useState([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [generatedKey, setGeneratedKey] = useState('');

  // Plans state
  const [plans, setPlans] = useState([]);

  // Audit activity state
  const [activityLogs, setActivityLogs] = useState([]);

  // Selected wallpaper category filter
  const [selectedWallpaperCategory, setSelectedWallpaperCategory] = useState('all');

  useEffect(() => {
    setForm({ ...settings });
  }, [settings]);

  useEffect(() => {
    if (activeTab === 'toolbox') {
      api.get('/admin/toolbox/images').then(res => res.success && setDockerImages(res.images || []));
    } else if (activeTab === 'api') {
      api.get('/admin/api-keys').then(res => res.success && setApiKeys(res.keys || []));
    } else if (activeTab === 'plans') {
      api.get('/admin/plans').then(res => res.success && setPlans(res.plans || []));
    } else if (activeTab === 'activity') {
      api.get('/admin/activity').then(res => res.success && setActivityLogs(res.logs || []));
    }
  }, [activeTab]);

  const handleChange = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }));
    updateSettingsLocally({ [key]: value });
  };

  const handleSave = async (e) => {
    if (e) e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const res = await api.put('/settings', form);
      if (res.success) {
        setSuccess('Panel settings saved successfully!');
        fetchPublicSettings();
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Upload Logo / Favicon / Wallpaper / Music file
  // Upload Logo / Favicon / Wallpaper / Music file
  const handleMediaUpload = async (field, file) => {
    if (!file) return;
    const formData = new FormData();
    formData.append(field, file);

    try {
      const res = await api.post('/settings/upload', formData);
      if (res.success) {
        setSuccess(`File uploaded successfully for ${field}!`);
        const updates = {};
        if (res.results?.logo) {
          updates.panel_logo = res.results.logo;
          updates.panel_logo_url = res.results.logo;
        }
        if (res.results?.favicon) {
          updates.panel_favicon_url = res.results.favicon;
        }
        if (res.results?.background) {
          updates.background_url = res.results.background;
          updates.background_type = res.results.backgroundType === 'video' ? 'video_url' : 'image_url';
        }
        if (res.results?.music) {
          updates.music_url = res.results.music;
          updates.music_type = 'upload';
          updates.music_title = res.results.musicTitle;
        }
        setForm(prev => ({ ...prev, ...updates }));
        updateSettingsLocally(updates);
        fetchPublicSettings();
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      alert(`Upload failed: ${err.message}`);
    }
  };

  // Select wallpaper from 4k presets
  const selectPresetWallpaper = (wp) => {
    handleChange('background_url', wp.url);
    handleChange('background_type', 'preset');
  };

  const handleDockerPrune = async () => {
    if (!confirm('This will remove all unused Docker containers and networks. Continue?')) return;
    setPruning(true);
    setPruneResult('');
    try {
      const res = await api.post('/admin/toolbox/prune', {});
      if (res.success) {
        setPruneResult(res.result?.output || 'Prune completed.');
        api.get('/admin/toolbox/images').then(r => r.success && setDockerImages(r.images || []));
      }
    } catch (err) {
      alert(`Prune error: ${err.message}`);
    } finally {
      setPruning(false);
    }
  };

  const handleCreateApiKey = async (e) => {
    e.preventDefault();
    if (!newKeyName) return;
    try {
      const res = await api.post('/admin/api-keys', { name: newKeyName });
      if (res.success) {
        setGeneratedKey(res.token);
        setNewKeyName('');
        api.get('/admin/api-keys').then(r => r.success && setApiKeys(r.keys || []));
      }
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDeleteApiKey = async (id) => {
    if (!confirm('Revoke this API Key?')) return;
    try {
      await api.delete(`/admin/api-keys/${id}`);
      setApiKeys(apiKeys.filter(k => k.id !== id));
    } catch (err) {
      alert(err.message);
    }
  };

  // Themes list
  const themePresets = [
    { id: 'dark-glass', name: 'Dark Glassmorphism (Default)', color: '#6366f1' },
    { id: 'cyberpunk', name: 'Cyberpunk Neon', color: '#ec4899' },
    { id: 'midnight-oled', name: 'Obsidian Midnight OLED', color: '#3b82f6' },
    { id: 'deep-purple', name: 'Deep Nebula Purple', color: '#a855f7' },
    { id: 'emerald-matrix', name: 'Emerald Matrix', color: '#10b981' },
    { id: 'sakura-pink', name: 'Sakura Blossom', color: '#f43f5e' },
    { id: 'sunset', name: 'Sunset Glow', color: '#f97316' },
    { id: 'arctic', name: 'Arctic Frost', color: '#06b6d4' }
  ];

  // Plans management state & handlers
  const [planModalOpen, setPlanModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [planForm, setPlanForm] = useState({
    name: '',
    price: '₹0 / Free',
    max_servers: 3,
    max_ram: '2G',
    max_cpu: 2,
    max_disk: '20G',
    is_default: false
  });
  const [planLoading, setPlanLoading] = useState(false);
  const [planError, setPlanError] = useState('');

  const fetchPlans = async () => {
    try {
      const res = await api.get('/admin/plans');
      if (res.success) setPlans(res.plans || []);
    } catch (e) {}
  };

  const openCreatePlan = () => {
    setEditingPlan(null);
    setPlanForm({
      name: '',
      price: '₹0 / Free',
      max_servers: 3,
      max_ram: '2G',
      max_cpu: 2,
      max_disk: '20G',
      is_default: false
    });
    setPlanError('');
    setPlanModalOpen(true);
  };

  const openEditPlan = (p) => {
    setEditingPlan(p);
    setPlanForm({
      name: p.name,
      price: p.price || '₹0 / Free',
      max_servers: p.max_servers,
      max_ram: p.max_ram,
      max_cpu: p.max_cpu,
      max_disk: p.max_disk,
      is_default: !!p.is_default
    });
    setPlanError('');
    setPlanModalOpen(true);
  };

  const handleSavePlan = async (e) => {
    e.preventDefault();
    if (!planForm.name.trim()) {
      return setPlanError('Plan name is required.');
    }
    setPlanLoading(true);
    setPlanError('');
    try {
      if (editingPlan) {
        await api.put(`/admin/plans/${editingPlan.id}`, planForm);
      } else {
        await api.post('/admin/plans', planForm);
      }
      setPlanModalOpen(false);
      fetchPlans();
    } catch (err) {
      setPlanError(err.message);
    } finally {
      setPlanLoading(false);
    }
  };

  const handleSetDefaultPlan = async (p) => {
    try {
      await api.post(`/admin/plans/${p.id}/set-default`, {});
      fetchPlans();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDeletePlan = async (p) => {
    if (!confirm(`Are you sure you want to delete quota plan "${p.name}"?`)) return;
    try {
      await api.delete(`/admin/plans/${p.id}`);
      fetchPlans();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Settings className="w-6 h-6 text-brand-400" />
            Panel Settings & Customization
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Customize branding, 4K wallpapers, background audio, glassmorphism transparency & blur bars, and system configs.
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-brand-500/25 disabled:opacity-50 transition-all self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save All Settings'}</span>
        </button>
      </div>

      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Tabs Navigation Bar */}
      <div className="glass-panel rounded-2xl p-1.5 border border-white/10 flex items-center gap-1 overflow-x-auto">
        {[
          { id: 'general', label: 'General & Appearance', icon: Sliders },
          { id: 'theme', label: 'Theme & Glass Style', icon: Palette },
          { id: 'social', label: 'Social Links', icon: Share2 },
          { id: 'security', label: 'Security & 2FA', icon: Shield },
          { id: 'email', label: 'Email (SMTP)', icon: Mail },
          { id: 'toolbox', label: 'Toolbox & Docker', icon: Wrench },
          { id: 'api', label: 'API Keys', icon: Key },
          { id: 'plans', label: 'Plans & Limits', icon: Layers },
          { id: 'activity', label: 'System Activity Logs', icon: Activity }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-brand-500 text-white shadow-md shadow-brand-500/25'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: GENERAL SETTINGS */}
      {activeTab === 'general' && (
        <div className="space-y-6">
          {/* Transparency & Blur Sliders */}
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-brand-400" />
              Transparency & Blur Bars (Live Real-Time Controls)
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Adjust the sliders below to see immediate live glassmorphism transparency and blur effects across the entire interface.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Transparency Bar */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    Transparent Bar: <code className="text-brand-300">-------|------</code>
                  </span>
                  <span className="text-xs font-mono font-bold text-brand-400">
                    {form.transparency || '75'}% Opacity
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={form.transparency || '75'}
                  onChange={(e) => handleChange('transparency', e.target.value)}
                  className="w-full h-2 bg-slate-700 rounded-lg cursor-pointer appearance-none"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>10% (Ultra Transparent)</span>
                  <span>100% (Solid Dark)</span>
                </div>
              </div>

              {/* Blur Bar */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    Blur Bar: <code className="text-brand-300">-------|----------</code>
                  </span>
                  <span className="text-xs font-mono font-bold text-brand-400">
                    {form.blur || '14'}px Blur
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={form.blur || '14'}
                  onChange={(e) => handleChange('blur', e.target.value)}
                  className="w-full h-2 bg-slate-700 rounded-lg cursor-pointer appearance-none"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>0px (Sharp Background)</span>
                  <span>30px (Heavy Frosted Glass)</span>
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Panel Branding & Logo */}
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Image className="w-5 h-5 text-emerald-400" />
              Panel Name, Logo & Favicon
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Panel Name & Logo */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Panel Name</label>
                  <input
                    type="text"
                    value={form.panel_name || ''}
                    onChange={(e) => handleChange('panel_name', e.target.value)}
                    placeholder="dpanel"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Panel Logo URL</label>
                  <input
                    type="text"
                    value={form.panel_logo_url || form.panel_logo || ''}
                    onChange={(e) => {
                      handleChange('panel_logo_url', e.target.value);
                      handleChange('panel_logo', e.target.value);
                    }}
                    placeholder="https://example.com/logo.png"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-medium text-slate-300">Upload Custom Logo Image</label>
                    {(form.panel_logo || form.panel_logo_url) && (
                      <button
                        type="button"
                        onClick={() => {
                          handleChange('panel_logo', '');
                          handleChange('panel_logo_url', '');
                        }}
                        className="text-[10px] text-rose-400 hover:underline font-mono"
                      >
                        Remove Logo
                      </button>
                    )}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleMediaUpload('logo', e.target.files?.[0])}
                    className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-white/10 file:text-white hover:file:bg-white/20 cursor-pointer"
                  />
                </div>
              </div>

              {/* Favicon & Live Preview */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Favicon Title / Tab Title</label>
                  <input
                    type="text"
                    value={form.panel_favicon_name || ''}
                    onChange={(e) => handleChange('panel_favicon_name', e.target.value)}
                    placeholder="dpanel"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Favicon Image URL</label>
                  <input
                    type="text"
                    value={form.panel_favicon_url || ''}
                    onChange={(e) => handleChange('panel_favicon_url', e.target.value)}
                    placeholder="https://example.com/favicon.ico or .png"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Upload Custom Favicon (.ico, .png, .svg)</label>
                  <input
                    type="file"
                    accept="image/*,.ico"
                    onChange={(e) => handleMediaUpload('favicon', e.target.files?.[0])}
                    className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-white/10 file:text-white hover:file:bg-white/20 cursor-pointer"
                  />
                </div>

                {/* Live Preview Box */}
                <div className="p-4 rounded-2xl bg-black/50 border border-white/10 flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-brand-500/20 border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                    {form.panel_logo || form.panel_logo_url ? (
                      <img src={form.panel_logo || form.panel_logo_url} alt="Logo" className="w-full h-full object-contain" />
                    ) : (
                      <span className="text-xs font-bold text-brand-400">LOGO</span>
                    )}
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-[10px] text-slate-400 block uppercase font-mono">Live Branding Preview</span>
                    <span className="text-sm font-bold text-white truncate block">{form.panel_name || 'dpanel'}</span>
                    {form.panel_favicon_url && (
                      <div className="flex items-center gap-1 text-[10px] text-purple-300 font-mono mt-0.5">
                        <img src={form.panel_favicon_url} alt="Favicon" className="w-3.5 h-3.5 object-contain" />
                        <span>Favicon configured</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Auto-Suspend VM Policy Settings */}
          <GlassCard className="p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-400" />
                  Auto-Suspend Virtual Machines (Resource & Cost Optimization)
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Automatically stop inactive/idle VMs running past continuous thresholds to prevent server overloading and OOM crashes.
                </p>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 font-mono">
                <Zap className="w-3 h-3 text-amber-400" /> Cron Worker
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-5">
              {/* Toggle: Enable Auto-Suspend */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-white">Auto-Suspend Policy</span>
                  <input
                    type="checkbox"
                    checked={form.auto_suspend_enabled === 'true'}
                    onChange={(e) => handleChange('auto_suspend_enabled', e.target.checked ? 'true' : 'false')}
                    className="w-4 h-4 rounded text-brand-600 bg-black/40 border-white/10 focus:ring-0 cursor-pointer"
                  />
                </label>
                <p className="text-[11px] text-slate-400">
                  {form.auto_suspend_enabled === 'true'
                    ? 'Active: VMs will automatically stop when exceeding maximum continuous runtime.'
                    : 'Disabled: VMs will run continuously until manually stopped by user or admin.'}
                </p>
              </div>

              {/* Inactivity / Runtime Threshold */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <label className="block text-xs font-bold text-white">Max Continuous Runtime</label>
                <select
                  value={form.auto_suspend_hours || '24'}
                  onChange={(e) => handleChange('auto_suspend_hours', e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-500 font-mono"
                >
                  <option value="6">6 Hours</option>
                  <option value="12">12 Hours</option>
                  <option value="24">24 Hours (1 Day - Recommended)</option>
                  <option value="48">48 Hours (2 Days)</option>
                  <option value="72">72 Hours (3 Days)</option>
                  <option value="168">168 Hours (7 Days / 1 Week)</option>
                  <option value="720">720 Hours (30 Days / 1 Month)</option>
                </select>
                <p className="text-[10px] text-slate-500">
                  Worker checks running containers every 5 minutes.
                </p>
              </div>

              {/* User Account Auto-Suspension Policy */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-cyan-400" /> Account Suspension Link
                </span>
                <p className="text-[11px] text-slate-400">
                  Whenever an admin suspends a user account in User Management, all their running VMs are <strong>instantly auto-stopped and suspended</strong>.
                </p>
              </div>
            </div>
          </GlassCard>

          {/* Panel Background (4kwallpapers.com Integration, Uploads, URL, Live Preview) */}
          <GlassCard className="p-6 space-y-5">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                Panel Background & 4K Wallpapers Engine
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Integrated browser powered by <strong>4kwallpapers.com</strong> featuring all categories, search, 4K download, favorites, image & video upload, and live pre-application preview.
              </p>
            </div>

            <WallpaperBrowser
              currentUrl={form.background_url}
              currentType={form.background_type}
              onApply={async (url, type, category) => {
                handleChange('background_url', url);
                handleChange('background_type', type);
                handleChange('background_category', category);
                updateSettingsLocally({
                  background_url: url,
                  background_type: type,
                  background_category: category
                });
                await api.post('/settings/wallpapers/apply', { url, type, category });
                fetchPublicSettings();
              }}
            />
          </GlassCard>

          {/* Panel Background Music */}
          <GlassCard className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Music className="w-5 h-5 text-purple-400" />
                  Background Audio & Music Player
                </h2>
                <p className="text-xs text-slate-400">Stream ambient lofi, synthwave, or custom audio across the web panel</p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.music_enabled === 'true' || form.music_enabled === true}
                  onChange={(e) => handleChange('music_enabled', e.target.checked ? 'true' : 'false')}
                  className="rounded text-brand-500"
                />
                <span className="text-xs font-bold text-white">Enable Music Widget</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Music Title</label>
                <input
                  type="text"
                  value={form.music_title || ''}
                  onChange={(e) => handleChange('music_title', e.target.value)}
                  placeholder="e.g. Lofi Chill Beats"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Music Audio URL (MP3/OGG)</label>
                <input
                  type="text"
                  value={form.music_url || ''}
                  onChange={(e) => handleChange('music_url', e.target.value)}
                  placeholder="https://.../music.mp3"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Or Upload MP3 / Audio File</label>
              <input
                type="file"
                accept="audio/*"
                onChange={(e) => handleMediaUpload('music', e.target.files?.[0])}
                className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-white/10 file:text-white hover:file:bg-white/20"
              />
            </div>
          </GlassCard>
        </div>
      )}

      {/* TAB 2: THEME & GLASS STYLE */}
      {activeTab === 'theme' && (
        <div className="space-y-6">
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Palette className="w-5 h-5 text-brand-400" />
              Theme Presets & Accent Colors
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-6">
              {themePresets.map(t => {
                const isSelected = form.theme === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => {
                      handleChange('theme', t.id);
                      handleChange('accent_color', t.color);
                    }}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                      isSelected ? 'bg-brand-500/15 border-brand-500 shadow-glass-glow' : 'bg-black/30 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 mb-2">
                      <span className="w-4 h-4 rounded-full" style={{ backgroundColor: t.color }} />
                      <span className="text-xs font-bold text-white">{t.name}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">{t.color}</span>
                  </div>
                );
              })}
            </div>

            {/* Custom Accent Color Picker */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-4">
              <input
                type="color"
                value={form.accent_color || '#6366f1'}
                onChange={(e) => handleChange('accent_color', e.target.value)}
                className="w-10 h-10 rounded-xl cursor-pointer bg-transparent border-0"
              />
              <div>
                <span className="text-xs font-bold text-slate-200">Custom Accent Color</span>
                <span className="text-[11px] text-slate-400 block font-mono">{form.accent_color || '#6366f1'}</span>
              </div>
            </div>
          </GlassCard>

          {/* Custom CSS */}
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-purple-400" />
              Custom CSS Overrides
            </h2>
            <p className="text-xs text-slate-400 mb-4">Inject raw CSS rules to customize buttons, fonts, or animations.</p>
            <textarea
              value={form.custom_css || ''}
              onChange={(e) => handleChange('custom_css', e.target.value)}
              rows="6"
              placeholder="/* Add custom CSS here */"
              className="w-full p-4 rounded-xl bg-black/50 border border-white/10 text-emerald-400 text-xs font-mono focus:outline-none focus:border-brand-500"
            />
          </GlassCard>
        </div>
      )}

      {/* TAB 3: SOCIAL LINKS */}
      {activeTab === 'social' && (
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
            <Share2 className="w-5 h-5 text-cyan-400" />
            Social & Community Links
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Discord Server URL</label>
              <input
                type="text"
                value={form.social_discord || ''}
                onChange={(e) => handleChange('social_discord', e.target.value)}
                placeholder="https://discord.gg/yourserver"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Telegram Group URL</label>
              <input
                type="text"
                value={form.social_telegram || ''}
                onChange={(e) => handleChange('social_telegram', e.target.value)}
                placeholder="https://t.me/yourchannel"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">GitHub Repository</label>
              <input
                type="text"
                value={form.social_github || ''}
                onChange={(e) => handleChange('social_github', e.target.value)}
                placeholder="https://github.com/your-org"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Official Website</label>
              <input
                type="text"
                value={form.social_website || ''}
                onChange={(e) => handleChange('social_website', e.target.value)}
                placeholder="https://dpanel.io"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>
        </GlassCard>
      )}

      {/* TAB 4: SECURITY & 2FA */}
      {activeTab === 'security' && (
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-rose-400" />
            Security & Authentication Policies
          </h2>

          <div className="space-y-4 divide-y divide-white/10">
            <div className="flex items-center justify-between pt-2">
              <div>
                <p className="text-xs font-bold text-white">Public User Registration</p>
                <p className="text-[11px] text-slate-400">Allow new visitors to register accounts from the registration page</p>
              </div>
              <input
                type="checkbox"
                checked={form.register_enabled === 'true' || form.register_enabled === true}
                onChange={(e) => handleChange('register_enabled', e.target.checked ? 'true' : 'false')}
                className="w-5 h-5 rounded text-brand-500"
              />
            </div>

            <div className="flex items-center justify-between pt-4">
              <div>
                <p className="text-xs font-bold text-white">Require Two-Factor Authentication (2FA)</p>
                <p className="text-[11px] text-slate-400">Force all users to configure TOTP 2FA before accessing servers</p>
              </div>
              <input
                type="checkbox"
                checked={form.require_2fa === 'true' || form.require_2fa === true}
                onChange={(e) => handleChange('require_2fa', e.target.checked ? 'true' : 'false')}
                className="w-5 h-5 rounded text-brand-500"
              />
            </div>

            <div className="pt-4">
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Session Timeout (Minutes)</label>
              <input
                type="number"
                value={form.session_timeout_minutes || '1440'}
                onChange={(e) => handleChange('session_timeout_minutes', e.target.value)}
                className="w-48 px-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>
        </GlassCard>
      )}

      {/* TAB 5: EMAIL (SMTP) */}
      {activeTab === 'email' && (
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
            <Mail className="w-5 h-5 text-amber-400" />
            SMTP Email Configuration
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SMTP Host</label>
              <input
                type="text"
                value={form.smtp_host || ''}
                onChange={(e) => handleChange('smtp_host', e.target.value)}
                placeholder="smtp.mailgun.org or smtp.gmail.com"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SMTP Port</label>
              <input
                type="number"
                value={form.smtp_port || '587'}
                onChange={(e) => handleChange('smtp_port', e.target.value)}
                placeholder="587"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SMTP Username</label>
              <input
                type="text"
                value={form.smtp_user || ''}
                onChange={(e) => handleChange('smtp_user', e.target.value)}
                placeholder="apikey or user@example.com"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SMTP Password</label>
              <input
                type="password"
                value={form.smtp_pass || ''}
                onChange={(e) => handleChange('smtp_pass', e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Sender Email Address</label>
              <input
                type="email"
                value={form.smtp_from || 'no-reply@dpanel.io'}
                onChange={(e) => handleChange('smtp_from', e.target.value)}
                placeholder="no-reply@dpanel.io"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>
        </GlassCard>
      )}

      {/* TAB 6: TOOLBOX & DOCKER */}
      {activeTab === 'toolbox' && (
        <div className="space-y-6">
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-amber-400" />
              Docker System Cleanup & Prune
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Reclaim host disk space by removing stopped containers, unused networks, and dangling image layers.
            </p>

            <button
              type="button"
              disabled={pruning}
              onClick={handleDockerPrune}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-md shadow-amber-500/20 disabled:opacity-50 transition-all"
            >
              {pruning ? 'Pruning System...' : 'Execute Docker Prune'}
            </button>

            {pruneResult && (
              <pre className="mt-4 p-4 rounded-xl bg-black/60 border border-white/10 text-emerald-400 font-mono text-xs overflow-x-auto whitespace-pre-wrap">
                {pruneResult}
              </pre>
            )}
          </GlassCard>

          {/* Local Docker Images */}
          <GlassCard className="p-6">
            <h3 className="text-sm font-bold text-white mb-3">Local Docker Images Cached on Host</h3>
            <div className="divide-y divide-white/5 font-mono text-xs">
              {dockerImages.map((img, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between">
                  <span className="text-white font-bold">{img.tag}</span>
                  <div className="flex items-center gap-4 text-slate-400 text-[11px]">
                    <span>{img.size}</span>
                    <span className="text-slate-500">{img.id}</span>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      )}

      {/* TAB 7: API KEYS */}
      {activeTab === 'api' && (
        <div className="space-y-6">
          <GlassCard className="p-6">
            <h2 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Key className="w-5 h-5 text-brand-400" />
              REST API Authentication Keys
            </h2>
            <p className="text-xs text-slate-400 mb-4">Generate API tokens for programmatic automation, Discord bots, and remote integrations.</p>

            <form onSubmit={handleCreateApiKey} className="flex gap-3">
              <input
                type="text"
                required
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                placeholder="Key Name (e.g. Discord Bot / CI Deployer)"
                className="flex-1 px-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shrink-0"
              >
                Generate Token
              </button>
            </form>

            {generatedKey && (
              <div className="mt-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs">
                <p className="text-emerald-300 font-bold mb-1">Your new API Key (Copy now, it won't be shown again):</p>
                <code className="p-2 rounded bg-black/60 text-emerald-400 font-mono block select-all break-all">{generatedKey}</code>
              </div>
            )}
          </GlassCard>

          <GlassCard className="p-0 overflow-hidden">
            <div className="divide-y divide-white/5 font-mono text-xs">
              {apiKeys.map(k => (
                <div key={k.id} className="p-4 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-white block">{k.name}</span>
                    <span className="text-[11px] text-slate-400">Prefix: {k.prefix}...</span>
                  </div>
                  <button
                    onClick={() => handleDeleteApiKey(k.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      )}

      {/* TAB 8: PLANS & LIMITS */}
      {activeTab === 'plans' && (
        <div className="space-y-6">
          <GlassCard className="p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-purple-400" />
                  User Quota Plans
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Create, customize, edit, and assign resource limit tiers (RAM, CPU Cores, Disk Storage, Max VMs) for your users.
                </p>
              </div>

              <button
                type="button"
                onClick={openCreatePlan}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-brand-500 to-purple-600 hover:from-brand-600 hover:to-purple-700 text-white text-xs font-bold shadow-lg shadow-purple-500/25 active:scale-95 transition-all shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Create Custom Plan</span>
              </button>
            </div>

            {plans.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl">
                <Layers className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <p className="text-sm font-semibold text-slate-300">No quota plans found</p>
                <p className="text-xs text-slate-500 mt-1">Create your first custom resource quota tier</p>
                <button
                  type="button"
                  onClick={openCreatePlan}
                  className="mt-4 px-4 py-2 rounded-xl bg-brand-500/20 hover:bg-brand-500/30 text-brand-300 text-xs font-bold border border-brand-500/30"
                >
                  Create Plan
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {plans.map(p => (
                  <div
                    key={p.id}
                    className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                      p.is_default
                        ? 'bg-gradient-to-b from-purple-950/40 to-black/40 border-purple-500/40 shadow-glass-glow ring-1 ring-purple-500/30'
                        : 'bg-black/40 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                              {p.name}
                            </h3>
                            <span className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold font-mono">
                              {p.price || '₹0 / Free'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">Plan ID: #{p.id}</span>
                        </div>
                        {p.is_default ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                            <Star className="w-3 h-3 fill-purple-400 text-purple-400" /> Default
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSetDefaultPlan(p)}
                            title="Set as Default Plan for new user registrations"
                            className="text-[10px] text-slate-400 hover:text-amber-300 hover:bg-amber-500/10 px-2 py-0.5 rounded border border-transparent hover:border-amber-500/20 transition-all flex items-center gap-1 font-mono"
                          >
                            <Star className="w-3 h-3" /> Set Default
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2.5 text-xs font-mono">
                        <div className="p-2.5 rounded-xl bg-black/50 border border-white/5">
                          <span className="text-[10px] text-slate-500 block font-sans">Max Servers</span>
                          <span className="text-white font-bold text-sm">{p.max_servers} VMs</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-black/50 border border-white/5">
                          <span className="text-[10px] text-slate-500 block font-sans">RAM Quota</span>
                          <span className="text-purple-300 font-bold text-sm">{p.max_ram}</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-black/50 border border-white/5">
                          <span className="text-[10px] text-slate-500 block font-sans">CPU Cores</span>
                          <span className="text-cyan-300 font-bold text-sm">{p.max_cpu} Core(s)</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-black/50 border border-white/5">
                          <span className="text-[10px] text-slate-500 block font-sans">Disk Storage</span>
                          <span className="text-emerald-300 font-bold text-sm">{p.max_disk}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => openEditPlan(p)}
                        className="px-3 py-1.5 rounded-xl bg-brand-500/15 hover:bg-brand-500/25 text-brand-300 text-xs font-bold border border-brand-500/30 flex items-center gap-1.5 transition-all"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeletePlan(p)}
                        className="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-xs font-bold border border-rose-500/30 flex items-center gap-1.5 transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>

          {/* Modal for Create & Edit Plan */}
          <Modal
            isOpen={planModalOpen}
            onClose={() => setPlanModalOpen(false)}
            title={editingPlan ? `Edit Quota Plan: ${editingPlan.name}` : 'Create Custom Quota Plan'}
          >
            <form onSubmit={handleSavePlan} className="space-y-4">
              {planError && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{planError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Plan Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Starter Free, Pro VPS, Enterprise"
                    value={planForm.name}
                    onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Price (INR / Custom String)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ₹0 / Free, ₹299 / mo, ₹999 / mo"
                    value={planForm.price}
                    onChange={(e) => setPlanForm({ ...planForm, price: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-emerald-500/30 text-emerald-300 text-xs font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Quick INR Price Presets */}
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Quick INR Price Chips:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {['₹0 / Free', '₹99 / mo', '₹199 / mo', '₹299 / mo', '₹499 / mo', '₹799 / mo', '₹999 / mo', '₹1,499 / mo', '₹1,999 / mo', '₹4,999 / mo'].map(pr => (
                    <button
                      key={pr}
                      type="button"
                      onClick={() => setPlanForm(prev => ({ ...prev, price: pr }))}
                      className={`px-2.5 py-1 text-[10px] rounded-lg border transition-all font-mono ${
                        planForm.price === pr
                          ? 'bg-emerald-500/30 border-emerald-500 text-emerald-200'
                          : 'bg-black/30 border-white/10 text-slate-300 hover:border-emerald-500/40 hover:text-emerald-300'
                      }`}
                    >
                      {pr}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quick Presets */}
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Quick Hardware Specs Presets:
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { name: 'Starter (1G/1C/10G)', price: '₹0 / Free', servers: 1, ram: '1G', cpu: 1, disk: '10G' },
                    { name: 'Standard (2G/2C/20G)', price: '₹199 / mo', servers: 3, ram: '2G', cpu: 2, disk: '20G' },
                    { name: 'Developer (4G/4C/50G)', price: '₹499 / mo', servers: 5, ram: '4G', cpu: 4, disk: '50G' },
                    { name: 'Pro (8G/6C/100G)', price: '₹999 / mo', servers: 8, ram: '8G', cpu: 6, disk: '100G' },
                    { name: 'Power (16G/8C/200G)', price: '₹1,999 / mo', servers: 10, ram: '16G', cpu: 8, disk: '200G' },
                    { name: 'Enterprise (32G/16C/500G)', price: '₹4,999 / mo', servers: 20, ram: '32G', cpu: 16, disk: '500G' }
                  ].map(preset => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => setPlanForm(prev => ({
                        ...prev,
                        price: preset.price,
                        max_servers: preset.servers,
                        max_ram: preset.ram,
                        max_cpu: preset.cpu,
                        max_disk: preset.disk
                      }))}
                      className="p-1.5 text-[10px] text-slate-300 hover:text-white rounded-lg bg-black/30 hover:bg-purple-500/20 border border-white/10 hover:border-purple-500/30 truncate transition-all text-center"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Max VMs Allowed</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={planForm.max_servers}
                    onChange={(e) => setPlanForm({ ...planForm, max_servers: parseInt(e.target.value, 10) || 1 })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Total RAM Quota</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 2G, 4G, 8G, 512M"
                    value={planForm.max_ram}
                    onChange={(e) => setPlanForm({ ...planForm, max_ram: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-purple-300 text-xs font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Total CPU Cores</label>
                  <input
                    type="number"
                    min="1"
                    max="64"
                    required
                    value={planForm.max_cpu}
                    onChange={(e) => setPlanForm({ ...planForm, max_cpu: parseInt(e.target.value, 10) || 1 })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-cyan-300 text-xs font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Total Disk SSD</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 20G, 50G, 100G, 1T"
                    value={planForm.max_disk}
                    onChange={(e) => setPlanForm({ ...planForm, max_disk: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-emerald-300 text-xs font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer p-3 rounded-xl bg-black/30 border border-white/10 hover:border-purple-500/30">
                  <input
                    type="checkbox"
                    checked={planForm.is_default}
                    onChange={(e) => setPlanForm({ ...planForm, is_default: e.target.checked })}
                    className="w-4 h-4 rounded text-purple-600 bg-black/40 border-white/10 focus:ring-0 cursor-pointer"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-white block">Default Plan for New Users</span>
                    <span className="text-[11px] text-slate-400">
                      Newly registered users will automatically receive this quota plan.
                    </span>
                  </div>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setPlanModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={planLoading}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-brand-500 to-purple-600 hover:from-brand-600 hover:to-purple-700 text-white text-xs font-bold shadow-md shadow-purple-500/20 disabled:opacity-50"
                >
                  {planLoading ? 'Saving...' : editingPlan ? 'Update Plan' : 'Create Plan'}
                </button>
              </div>
            </form>
          </Modal>
        </div>
      )}

      {/* TAB 9: ACTIVITY LOGS */}
      {activeTab === 'activity' && (
        <GlassCard className="p-0 overflow-hidden">
          <div className="divide-y divide-white/5 font-sans text-xs">
            {activityLogs.map(log => (
              <div key={log.id} className="p-4 flex items-center justify-between hover:bg-white/5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white font-mono">{log.action}</span>
                    {log.username && <span className="text-slate-400">by {log.username}</span>}
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">{log.details}</p>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">
                  {new Date(log.created_at).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>
      )}
    </div>
  );
}

