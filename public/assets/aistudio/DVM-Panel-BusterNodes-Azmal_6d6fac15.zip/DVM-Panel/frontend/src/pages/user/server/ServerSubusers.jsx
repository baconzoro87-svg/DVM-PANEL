import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Users,
  Plus,
  Trash2,
  Edit,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Mail,
  UserCheck
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';

const ALL_PERMISSIONS = [
  { id: 'console', label: 'Console Access', desc: 'Can view and send input to the interactive web terminal' },
  { id: 'control', label: 'Power Control', desc: 'Can start, stop, restart, and kill the virtual machine' },
  { id: 'files', label: 'File Manager', desc: 'Can view, edit, upload, and delete container files' },
  { id: 'backups', label: 'Backups Access', desc: 'Can create, download, and restore snapshot backups' },
  { id: 'schedules', label: 'Schedules Management', desc: 'Can view and create automated cron schedules' },
  { id: 'settings', label: 'Server Settings', desc: 'Can rename VM and adjust configurations' }
];

export default function ServerSubusers() {
  const { server } = useOutletContext();
  const [subusers, setSubusers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingSubuser, setEditingSubuser] = useState(null);

  const [email, setEmail] = useState('');
  const [selectedPermissions, setSelectedPermissions] = useState(['console', 'control']);
  const [error, setError] = useState('');

  const fetchSubusers = async () => {
    try {
      const res = await api.get(`/servers/${server.id}/subusers`);
      if (res.success) {
        setSubusers(res.subusers || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubusers();
  }, [server.id]);

  const togglePermission = (id) => {
    if (selectedPermissions.includes(id)) {
      setSelectedPermissions(selectedPermissions.filter(p => p !== id));
    } else {
      setSelectedPermissions([...selectedPermissions, id]);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editingSubuser) {
        await api.put(`/servers/${server.id}/subusers/${editingSubuser.id}`, {
          permissions: selectedPermissions
        });
      } else {
        await api.post(`/servers/${server.id}/subusers`, {
          email,
          permissions: selectedPermissions
        });
      }
      setModalOpen(false);
      setEditingSubuser(null);
      setEmail('');
      setSelectedPermissions(['console', 'control']);
      fetchSubusers();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (subId) => {
    if (!confirm('Remove this subuser? They will immediately lose access to this server.')) return;
    try {
      await api.delete(`/servers/${server.id}/subusers/${subId}`);
      fetchSubusers();
    } catch (err) {
      alert(err.message);
    }
  };

  const openEdit = (sub) => {
    let perms = [];
    try {
      perms = JSON.parse(sub.permissions);
    } catch {
      perms = ['console'];
    }
    setEditingSubuser(sub);
    setEmail(sub.email);
    setSelectedPermissions(perms);
    setModalOpen(true);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-pink-400" />
            Subusers & Access Delegation
          </h2>
          <p className="text-xs text-slate-400">
            Grant granular management permissions for this server to other registered members without sharing your credentials.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingSubuser(null);
            setEmail('');
            setSelectedPermissions(['console', 'control']);
            setModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subuser</span>
        </button>
      </div>

      {loading ? (
        <div className="py-12 text-center text-slate-400 text-xs">Loading subusers...</div>
      ) : subusers.length === 0 ? (
        <GlassCard className="py-12 text-center">
          <Users className="w-10 h-10 text-slate-500 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-white mb-1">No subusers added</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            Invite teammates or friends to help manage files, console, and power actions on this VM.
          </p>
          <button
            onClick={() => setModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
          >
            Add First Subuser
          </button>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {subusers.map((sub) => {
            let perms = [];
            try {
              perms = JSON.parse(sub.permissions);
            } catch {
              perms = [];
            }

            return (
              <GlassCard key={sub.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-pink-500/15 border border-pink-500/30 text-pink-400 flex items-center justify-center font-bold text-xs uppercase shrink-0">
                    {sub.username?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{sub.username}</span>
                      <span className="text-xs text-slate-400 font-normal">({sub.email})</span>
                    </h4>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {perms.map((p) => (
                        <span
                          key={p}
                          className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase bg-brand-500/15 border border-brand-500/30 text-brand-300"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => openEdit(sub)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                    title="Edit Permissions"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(sub.id)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                    title="Remove Subuser"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      {/* Add / Edit Subuser Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingSubuser ? `Edit Subuser (${editingSubuser.username})` : 'Add New Subuser'}
      >
        <form onSubmit={handleSave} className="space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {!editingSubuser && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">User Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@example.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-2">Granular Permissions</label>
            <div className="space-y-2">
              {ALL_PERMISSIONS.map((p) => {
                const checked = selectedPermissions.includes(p.id);
                return (
                  <div
                    key={p.id}
                    onClick={() => togglePermission(p.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                      checked ? 'bg-brand-500/15 border-brand-500/40 text-white' : 'bg-black/30 border-white/10 text-slate-400 hover:border-white/20'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => {}}
                      className="mt-0.5 rounded text-brand-500 focus:ring-0"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-200">{p.label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{p.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold"
            >
              {editingSubuser ? 'Update Permissions' : 'Send Invite & Grant Access'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

