import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  Plus,
  Edit,
  Trash2,
  Shield,
  UserX,
  UserCheck,
  Search,
  Key,
  Clock,
  History,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { api } from '../../utils/api';
import GlassCard from '../../components/GlassCard';
import Modal from '../../components/Modal';

export default function AdminUserManagement() {
  const [activeTab, setActiveTab] = useState('users'); // 'users' or 'history'
  const [users, setUsers] = useState([]);
  const [loginHistory, setLoginHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  // Form states
  const [formUsername, setFormUsername] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formRole, setFormRole] = useState('user');
  const [formRam, setFormRam] = useState('2G');
  const [formCpu, setFormCpu] = useState('2');
  const [formDisk, setFormDisk] = useState('20G');
  const [formMaxServers, setFormMaxServers] = useState('3');
  const [plans, setPlans] = useState([]);
  const [error, setError] = useState('');

  const fetchUsersAndHistory = async () => {
    setLoading(true);
    try {
      const [uRes, hRes, pRes] = await Promise.all([
        api.get('/admin/users'),
        api.get('/admin/login-history'),
        api.get('/admin/plans')
      ]);
      if (uRes.success) setUsers(uRes.users || []);
      if (hRes.success) setLoginHistory(hRes.history || []);
      if (pRes.success) setPlans(pRes.plans || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsersAndHistory();
  }, []);

  const handleCreateUser = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/admin/users', {
        username: formUsername,
        email: formEmail,
        password: formPassword,
        role: formRole,
        ram_limit: formRam,
        cpu_limit: formCpu,
        disk_limit: formDisk,
        max_servers: formMaxServers
      });
      setCreateModalOpen(false);
      resetForm();
      fetchUsersAndHistory();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleEditUser = async (e) => {
    e.preventDefault();
    if (!editingUser) return;
    setError('');
    try {
      await api.put(`/admin/users/${editingUser.id}`, {
        username: formUsername,
        email: formEmail,
        role: formRole,
        password: formPassword || undefined,
        ram_limit: formRam,
        cpu_limit: formCpu,
        disk_limit: formDisk,
        max_servers: formMaxServers
      });
      setEditModalOpen(false);
      setEditingUser(null);
      resetForm();
      fetchUsersAndHistory();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleToggleStatus = async (user) => {
    try {
      await api.post(`/admin/users/${user.id}/toggle-status`, {});
      fetchUsersAndHistory();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDeleteUser = async (user) => {
    if (!confirm(`Warning: Are you sure you want to permanently delete user "${user.username}" and all their associated VMs?`)) return;
    try {
      await api.delete(`/admin/users/${user.id}`);
      fetchUsersAndHistory();
    } catch (err) {
      alert(err.message);
    }
  };

  const openEdit = (user) => {
    setEditingUser(user);
    setFormUsername(user.username);
    setFormEmail(user.email);
    setFormPassword('');
    setFormRole(user.role);
    setFormRam(user.ram_limit || '2G');
    setFormCpu(String(user.cpu_limit || 2));
    setFormDisk(user.disk_limit || '20G');
    setFormMaxServers(String(user.max_servers || 3));
    setEditModalOpen(true);
  };

  const resetForm = () => {
    setFormUsername('');
    setFormEmail('');
    setFormPassword('');
    setFormRole('user');
    setFormRam('2G');
    setFormCpu('2');
    setFormDisk('20G');
    setFormMaxServers('3');
    setError('');
  };

  const filteredUsers = users.filter(u =>
    u.username?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.role?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Users className="w-6 h-6 text-brand-400" />
            User Account Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Create, edit, suspend, and view user profiles, quotas, and authentication history.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchUsersAndHistory}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              resetForm();
              setCreateModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create New User</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2">
        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'users' ? 'bg-brand-500 text-white shadow-md shadow-brand-500/25' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>User Directory ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'history' ? 'bg-brand-500 text-white shadow-md shadow-brand-500/25' : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-4 h-4 text-amber-400" />
          <span>Login Activity Logs</span>
        </button>
      </div>

      {activeTab === 'users' ? (
        <>
          {/* Search bar */}
          <div className="relative w-full max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users by name, email, role..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500"
            />
          </div>

          {/* Users Table */}
          <GlassCard className="p-0 overflow-hidden">
            {loading ? (
              <div className="py-16 text-center text-slate-400 text-xs">Loading user accounts...</div>
            ) : filteredUsers.length === 0 ? (
              <div className="py-16 text-center text-slate-500 text-xs">No users found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/40 text-slate-400 border-b border-white/10 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="px-6 py-3.5">User</th>
                      <th className="px-6 py-3.5">Role</th>
                      <th className="px-6 py-3.5">Status</th>
                      <th className="px-6 py-3.5">VMs Owned</th>
                      <th className="px-6 py-3.5">Resource Quotas</th>
                      <th className="px-6 py-3.5">Registered</th>
                      <th className="px-6 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredUsers.map((u) => {
                      const isSuspended = u.status === 'suspended';
                      const isAdmin = u.role === 'admin';

                      return (
                        <tr key={u.id} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-brand-500/20 border border-brand-500/30 flex items-center justify-center font-bold text-xs text-brand-300">
                                {u.username?.charAt(0).toUpperCase() || 'U'}
                              </div>
                              <div>
                                <Link to={`/admin/users/${u.id}`} className="font-bold text-white hover:text-brand-300 flex items-center gap-1.5">
                                  <span>{u.username}</span>
                                  <ExternalLink className="w-3 h-3 text-slate-500" />
                                </Link>
                                <span className="text-[11px] text-slate-400 block">{u.email}</span>
                              </div>
                            </div>
                          </td>

                          <td className="px-6 py-4">
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              isAdmin ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30' : 'bg-white/5 text-slate-300 border border-white/10'
                            }`}>
                              {u.role}
                            </span>
                          </td>

                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              isSuspended ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${isSuspended ? 'bg-rose-400' : 'bg-emerald-400'}`} />
                              {u.status}
                            </span>
                          </td>

                          <td className="px-6 py-4 font-mono font-bold text-slate-200">
                            {u.server_count || 0} / {u.max_servers || 3}
                          </td>

                          <td className="px-6 py-4 text-slate-300 font-mono text-[11px]">
                            {u.cpu_limit}C • {u.ram_limit} • {u.disk_limit}
                          </td>

                          <td className="px-6 py-4 text-slate-400 text-[11px]">
                            {new Date(u.created_at).toLocaleDateString()}
                          </td>

                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => openEdit(u)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white"
                                title="Edit User"
                              >
                                <Edit className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => handleToggleStatus(u)}
                                className={`p-1.5 rounded-lg transition-colors ${
                                  isSuspended ? 'bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25' : 'bg-amber-500/15 text-amber-300 hover:bg-amber-500/25'
                                }`}
                                title={isSuspended ? 'Unsuspend Account' : 'Suspend Account'}
                              >
                                {isSuspended ? <UserCheck className="w-4 h-4" /> : <UserX className="w-4 h-4" />}
                              </button>

                              <button
                                onClick={() => handleDeleteUser(u)}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-rose-400"
                                title="Delete User"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </GlassCard>
        </>
      ) : (
        /* Login History Audit Tab */
        <GlassCard className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/40 text-slate-400 border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-6 py-3.5">Username</th>
                  <th className="px-6 py-3.5">IP Address</th>
                  <th className="px-6 py-3.5">User Agent / Browser</th>
                  <th className="px-6 py-3.5">Status</th>
                  <th className="px-6 py-3.5">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {loginHistory.map((h) => (
                  <tr key={h.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-3.5 font-bold text-white">{h.username}</td>
                    <td className="px-6 py-3.5 text-brand-300">{h.ip_address || '127.0.0.1'}</td>
                    <td className="px-6 py-3.5 text-slate-400 font-sans text-[11px] truncate max-w-xs">
                      {h.user_agent || 'Unknown'}
                    </td>
                    <td className="px-6 py-3.5 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        h.status === 'success' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {h.status}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-slate-400 text-[11px]">
                      {new Date(h.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      )}

      {/* Create / Edit User Modal */}
      <Modal
        isOpen={createModalOpen || editModalOpen}
        onClose={() => {
          setCreateModalOpen(false);
          setEditModalOpen(false);
        }}
        title={editModalOpen ? `Edit User: ${editingUser?.username}` : 'Create New User'}
      >
        <form onSubmit={editModalOpen ? handleEditUser : handleCreateUser} className="space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Username</label>
              <input
                type="text"
                required
                value={formUsername}
                onChange={(e) => setFormUsername(e.target.value)}
                placeholder="johndoe"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Email</label>
              <input
                type="email"
                required
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                placeholder="john@example.com"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Password {editModalOpen && '(Leave blank to keep unchanged)'}
              </label>
              <input
                type="password"
                required={!editModalOpen}
                minLength="6"
                value={formPassword}
                onChange={(e) => setFormPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Role</label>
              <select
                value={formRole}
                onChange={(e) => setFormRole(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              >
                <option value="user" className="bg-dark-900">User (Standard Access)</option>
                <option value="admin" className="bg-dark-900">Admin (Full Administrative Access)</option>
              </select>
            </div>
          </div>

          <div className="pt-2 border-t border-white/10 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Resource Limits & Quota</span>
              {plans.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-purple-300 font-medium">Apply Plan Preset:</span>
                  <select
                    onChange={(e) => {
                      const p = plans.find(x => x.id === parseInt(e.target.value, 10));
                      if (p) {
                        setFormRam(p.max_ram);
                        setFormCpu(String(p.max_cpu));
                        setFormDisk(p.max_disk);
                        setFormMaxServers(String(p.max_servers));
                      }
                    }}
                    defaultValue=""
                    className="px-2.5 py-1 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-200 text-xs font-mono focus:outline-none"
                  >
                    <option value="" disabled className="bg-dark-900">Choose Plan...</option>
                    {plans.map(p => (
                      <option key={p.id} value={p.id} className="bg-dark-900">
                        {p.name} ({p.max_ram} RAM, {p.max_cpu}C, {p.max_disk}) {p.is_default ? '★' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Max VMs</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={formMaxServers}
                  onChange={(e) => setFormMaxServers(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">RAM Limit</label>
                <input
                  type="text"
                  value={formRam}
                  onChange={(e) => setFormRam(e.target.value)}
                  placeholder="2G"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">CPU Cores</label>
                <input
                  type="number"
                  min="1"
                  max="32"
                  value={formCpu}
                  onChange={(e) => setFormCpu(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Disk / SSD</label>
                <input
                  type="text"
                  value={formDisk}
                  onChange={(e) => setFormDisk(e.target.value)}
                  placeholder="20G"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={() => {
                setCreateModalOpen(false);
                setEditModalOpen(false);
              }}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold"
            >
              {editModalOpen ? 'Save User Changes' : 'Create User'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

