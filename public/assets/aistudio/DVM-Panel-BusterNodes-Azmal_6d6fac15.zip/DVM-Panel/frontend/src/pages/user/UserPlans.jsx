import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Layers,
  Server,
  Cpu,
  HardDrive,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Shield,
  Star,
  Zap,
  LifeBuoy,
  RefreshCw,
  Clock,
  Gauge
} from 'lucide-react';
import { api } from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import GlassCard from '../../components/GlassCard';

export default function UserPlans() {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();

  const [plans, setPlans] = useState([]);
  const [quota, setQuota] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [pRes, qRes] = await Promise.all([
        api.get('/servers/plans'),
        api.get('/servers/user/quota')
      ]);
      if (pRes.success) setPlans(pRes.plans || []);
      if (qRes.success) setQuota(qRes.quota);
    } catch (err) {
      console.error('Failed to load plans:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDeployWithPlan = (p) => {
    navigate('/servers/create');
  };

  // Helper percentage calculator
  const getPercent = (used, total) => {
    if (!total || total === 0) return 0;
    return Math.min(100, Math.round((used / total) * 100));
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Layers className="w-6 h-6 text-purple-400" />
            Quota Plans & Resource Packages
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            View available hosting plan tiers, monitor your allocated resource limits, and upgrade your capacity.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchData}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold border border-white/10 flex items-center gap-2 transition-all active:scale-95"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => navigate('/servers/create')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-brand-500 to-purple-600 hover:from-brand-600 hover:to-purple-700 active:scale-95 text-white text-xs font-bold shadow-lg shadow-purple-500/25 transition-all"
          >
            <Server className="w-4 h-4" />
            <span>Deploy VM</span>
          </button>
        </div>
      </div>

      {/* Current Active Quota Card */}
      {quota && (
        <GlassCard className="p-6 relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Gauge className="w-4 h-4 text-brand-400" />
                  Your Active Resource Quota
                </span>
                {quota.isAdmin ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-[10px] font-bold uppercase">
                    Admin (Unlimited)
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold uppercase">
                    Active Plan
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Real-time usage and capacity across all your deployed virtual machine containers.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 font-mono text-xs text-slate-300">
                Total VMs: <strong className="text-white">{quota.used.totalServersOwned}</strong> / {quota.limits.maxServers} Max
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
            {/* 1. VMs Used */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Server className="w-4 h-4 text-brand-400" /> Virtual Machines
                </span>
                <span className="text-xs font-mono font-bold text-white">
                  {quota.used.totalServersOwned} / {quota.limits.maxServers}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-brand-500 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(quota.used.totalServersOwned, quota.limits.maxServers)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Available:</span>
                <span className="text-emerald-400 font-bold">{quota.available.servers} VMs free</span>
              </div>
            </div>

            {/* 2. RAM Memory */}
            <div className="p-4 rounded-2xl bg-black/40 border border-purple-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-400" /> RAM Memory
                </span>
                <span className="text-xs font-mono font-bold text-purple-300">
                  {quota.used.ramStr} / {quota.limits.ramStr}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(quota.used.ramMb, quota.limits.ramMb)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Available:</span>
                <span className="text-purple-300 font-bold">{quota.available.ramStr} free</span>
              </div>
            </div>

            {/* 3. CPU Cores */}
            <div className="p-4 rounded-2xl bg-black/40 border border-cyan-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-cyan-400" /> CPU Cores
                </span>
                <span className="text-xs font-mono font-bold text-cyan-300">
                  {quota.used.cpu} / {quota.limits.cpu} Cores
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-cyan-500 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(quota.used.cpu, quota.limits.cpu)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Available:</span>
                <span className="text-cyan-300 font-bold">{quota.available.cpu} Core(s) free</span>
              </div>
            </div>

            {/* 4. SSD Storage */}
            <div className="p-4 rounded-2xl bg-black/40 border border-emerald-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-emerald-400" /> Disk Storage
                </span>
                <span className="text-xs font-mono font-bold text-emerald-300">
                  {quota.used.diskStr} / {quota.limits.diskStr}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                  style={{ width: `${getPercent(quota.used.diskGb, quota.limits.diskGb)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Available:</span>
                <span className="text-emerald-300 font-bold">{quota.available.diskStr} free</span>
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Available Plans Catalog */}
      <div className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            Available Quota Packages & Tiers
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Select a plan to launch new servers or request a package upgrade.
          </p>
        </div>

        {plans.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl">
            <Layers className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <p className="text-sm font-semibold text-slate-300">No public plans available</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {plans.map((p) => {
              const isDefault = p.is_default === 1;

              return (
                <GlassCard
                  key={p.id}
                  className={`p-6 flex flex-col justify-between space-y-5 transition-all duration-300 relative ${
                    isDefault
                      ? 'border-purple-500/50 bg-gradient-to-b from-purple-950/30 to-black/40 shadow-glass-glow'
                      : 'hover:border-white/20'
                  }`}
                >
                  {isDefault && (
                    <div className="absolute -top-3 right-5 px-3 py-0.5 rounded-full bg-gradient-to-r from-brand-500 to-purple-600 text-white text-[10px] font-bold uppercase tracking-wider shadow-md shadow-purple-500/30 flex items-center gap-1">
                      <Star className="w-3 h-3 fill-white" /> Popular Tier
                    </div>
                  )}

                  <div>
                    <div className="flex items-start justify-between gap-2 mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-white tracking-tight">{p.name}</h3>
                        <p className="text-xs text-slate-400 mt-0.5">High Performance QEMU Container Instance</p>
                      </div>
                      <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold font-mono shrink-0 shadow-sm shadow-emerald-500/20">
                        {p.price || '₹0 / Free'}
                      </span>
                    </div>

                    <div className="space-y-2.5 font-mono text-xs">
                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-slate-400 font-sans flex items-center gap-1.5">
                          <Server className="w-3.5 h-3.5 text-brand-400" /> Max VMs
                        </span>
                        <span className="text-white font-bold">{p.max_servers} Containers</span>
                      </div>

                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-slate-400 font-sans flex items-center gap-1.5">
                          <Layers className="w-3.5 h-3.5 text-purple-400" /> RAM Memory
                        </span>
                        <span className="text-purple-300 font-bold">{p.max_ram}</span>
                      </div>

                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-slate-400 font-sans flex items-center gap-1.5">
                          <Cpu className="w-3.5 h-3.5 text-cyan-400" /> CPU Limit
                        </span>
                        <span className="text-cyan-300 font-bold">{p.max_cpu} Core(s)</span>
                      </div>

                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-slate-400 font-sans flex items-center gap-1.5">
                          <HardDrive className="w-3.5 h-3.5 text-emerald-400" /> SSD Storage
                        </span>
                        <span className="text-emerald-300 font-bold">{p.max_disk}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 space-y-2">
                    <button
                      onClick={() => handleDeployWithPlan(p)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/20 transition-all"
                    >
                      <span>Deploy VM with this Tier</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>

      {/* Upgrade Help Banner */}
      <GlassCard className="p-6 bg-gradient-to-r from-purple-900/20 via-brand-900/20 to-cyan-900/20 border border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <LifeBuoy className="w-4 h-4 text-amber-400" />
              Need higher RAM, CPU, or Storage Quotas?
            </h3>
            <p className="text-xs text-slate-300">
              Open a support ticket or contact an administrator to upgrade your account quota tier instantly.
            </p>
          </div>

          <button
            onClick={() => navigate('/tickets')}
            className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold border border-white/15 transition-all shrink-0 flex items-center gap-2"
          >
            <LifeBuoy className="w-3.5 h-3.5" />
            <span>Open Support Ticket</span>
          </button>
        </div>
      </GlassCard>
    </div>
  );
}

