import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Server,
  Plus,
  Play,
  Square,
  RotateCw,
  Trash2,
  Users,
  Search,
  ExternalLink,
  RefreshCw,
  Terminal,
  ArrowRightLeft,
  Sparkles,
  ShieldCheck,
  Radio,
  Clock,
  PauseCircle,
  PlayCircle,
  ShieldAlert
} from 'lucide-react';
import { api } from '../../utils/api';
import GlassCard from '../../components/GlassCard';
import Modal from '../../components/Modal';
import AutoSuspendPicker, { formatDisplay12 } from '../../components/AutoSuspendPicker';

export default function AdminServerManagement() {
  const [servers, setServers] = useState([]);
  const [users, setUsers] = useState([]);
  const [portInfo, setPortInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [targetServerForTransfer, setTargetServerForTransfer] = useState(null);
  const [newOwnerId, setNewOwnerId] = useState('');

  // Auto-Suspend Modal state
  const [suspendModalOpen, setSuspendModalOpen] = useState(false);
  const [targetServerForSuspend, setTargetServerForSuspend] = useState(null);
  const [selectedSuspendType, setSelectedSuspendType] = useState('hours');
  const [selectedSuspendHours, setSelectedSuspendHours] = useState('0');
  const [selectedSuspendAt, setSelectedSuspendAt] = useState('');
  const [selectedSuspendTime, setSelectedSuspendTime] = useState('23:00');
  const [savingSuspend, setSavingSuspend] = useState(false);

  const fetchAll = async () => {
    try {
      const [srvRes, usrRes, portRes] = await Promise.all([
        api.get('/admin/servers'),
        api.get('/admin/users'),
        api.get('/ports/next-free').catch(() => null)
      ]);
      if (srvRes?.success) setServers(srvRes.servers || []);
      if (usrRes?.success) setUsers(usrRes.users || []);
      if (portRes?.success) setPortInfo(portRes);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const handleToggleSuspend = async (server) => {
    try {
      if (server.is_suspended || server.status === 'suspended') {
        await api.post(`/admin/servers/${server.id}/unsuspend`, {});
      } else {
        await api.post(`/admin/servers/${server.id}/suspend`, {
          reason: 'Suspended by Administrator from Global Server Management'
        });
      }
      fetchAll();
    } catch (err) {
      alert(`Suspend toggle failed: ${err.message}`);
    }
  };

  const handleOpenSuspendModal = (server) => {
    setTargetServerForSuspend(server);
    setSelectedSuspendType(server.auto_suspend_type || 'hours');
    setSelectedSuspendHours(String(server.auto_suspend_hours || '0'));
    setSelectedSuspendAt(server.auto_suspend_at || '');
    setSelectedSuspendTime(server.auto_suspend_time || '23:00');
    setSuspendModalOpen(true);
  };

  const handleSaveSuspendPolicy = async (e) => {
    e.preventDefault();
    if (!targetServerForSuspend) return;
    setSavingSuspend(true);
    try {
      await api.put(`/servers/${targetServerForSuspend.id}`, {
        auto_suspend_type: selectedSuspendType,
        auto_suspend_hours: parseInt(selectedSuspendHours, 10) || 0,
        auto_suspend_at: selectedSuspendType === 'datetime' ? selectedSuspendAt : null,
        auto_suspend_time: selectedSuspendType === 'daily_time' ? selectedSuspendTime : ''
      });
      setSuspendModalOpen(false);
      setTargetServerForSuspend(null);
      fetchAll();
    } catch (err) {
      alert(`Failed to save auto-suspend policy: ${err.message}`);
    } finally {
      setSavingSuspend(false);
    }
  };

  const handlePower = async (serverId, action) => {
    try {
      await api.post(`/servers/${serverId}/power`, { action });
      fetchAll();
    } catch (err) {
      alert(`Power action failed: ${err.message}`);
    }
  };

  const handleDelete = async (serverId, serverName) => {
    if (!confirm(`Warning: Are you sure you want to forcibly delete VM "${serverName}"?`)) return;
    try {
      await api.delete(`/servers/${serverId}`);
      fetchAll();
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleTransferOwner = async (e) => {
    e.preventDefault();
    if (!targetServerForTransfer || !newOwnerId) return;

    try {
      await api.put(`/admin/servers/${targetServerForTransfer.id}/owner`, {
        newUserId: parseInt(newOwnerId, 10)
      });
      setTransferModalOpen(false);
      setTargetServerForTransfer(null);
      fetchAll();
    } catch (err) {
      alert(`Transfer failed: ${err.message}`);
    }
  };

  const filteredServers = servers.filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.owner_username?.toLowerCase().includes(search.toLowerCase()) ||
    s.image?.toLowerCase().includes(search.toLowerCase()) ||
    String(s.port_ssh).includes(search)
  );

  const usedPercent = portInfo ? Math.round((portInfo.usedCount / portInfo.total) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Server className="w-6 h-6 text-brand-400" />
            Global Server Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Oversee and administer all virtual machines and port allocations across all platform users.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchAll}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Refresh All"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <Link
            to="/admin/servers/create"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create Server</span>
          </Link>
        </div>
      </div>

      {/* Auto Port Pool Overview Widget */}
      {portInfo && (
        <GlassCard className="p-4 bg-gradient-to-r from-brand-900/30 via-black/40 to-cyan-900/20 border-white/10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  Auto Port Allocation Pool (25501 – 25599)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Next auto-assigned port: <strong className="text-emerald-400 font-mono">{portInfo.nextPort}</strong> • Available: <strong className="text-white font-mono">{portInfo.freeCount}</strong> / {portInfo.total}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-48 bg-black/50 rounded-full h-2.5 border border-white/10 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-brand-500 to-cyan-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(usedPercent, 4)}%` }}
                />
              </div>
              <span className="text-xs font-mono text-slate-300 font-bold shrink-0">
                {portInfo.usedCount} Used ({usedPercent}%)
              </span>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Filter Bar */}
      <div className="flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by server name, owner, port, image..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500"
          />
        </div>
        <span className="text-xs text-slate-400 font-mono">
          Total Servers: <strong className="text-white">{filteredServers.length}</strong>
        </span>
      </div>

      {/* Servers Table */}
      <GlassCard className="p-0 overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-slate-400 text-xs">Loading all servers...</div>
        ) : filteredServers.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">No servers found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/40 text-slate-400 border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-5 py-3.5">Server</th>
                  <th className="px-5 py-3.5">Owner</th>
                  <th className="px-5 py-3.5">Port (SSH)</th>
                  <th className="px-5 py-3.5">Specs</th>
                  <th className="px-5 py-3.5">Auto-Suspend</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {filteredServers.map((s) => {
                  const isSuspended = !!s.is_suspended || s.status === 'suspended';
                  const isRunning = s.status === 'running';
                  const autoSuspendHours = parseInt(s.auto_suspend_hours, 10) || 0;

                  return (
                    <tr key={s.id} className={`hover:bg-white/5 transition-colors ${isSuspended ? 'bg-amber-950/10' : ''}`}>
                      <td className="px-5 py-4 font-bold text-white font-mono">
                        <Link to={`/servers/${s.id}/overview`} className="hover:text-brand-300 flex items-center gap-2">
                          <Server className="w-4 h-4 text-brand-400 shrink-0" />
                          <div>
                            <span className="block">{s.name}</span>
                            <span className="text-[10px] text-slate-500 font-sans font-normal truncate block max-w-[120px]">
                              {s.image}
                            </span>
                          </div>
                        </Link>
                      </td>
                      <td className="px-5 py-4 text-slate-300 font-sans">
                        <span className="font-semibold text-white">{s.owner_username}</span>
                        <span className="text-[10px] text-slate-500 block">{s.owner_email}</span>
                      </td>
                      <td className="px-5 py-4">
                        <span className="px-2 py-1 rounded bg-black/50 border border-white/10 text-brand-300 font-bold">
                          {s.port_ssh}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-slate-300 text-[11px]">
                        {s.cpu_limit}C • {s.memory_limit} • {s.disk_limit}
                      </td>

                      {/* Auto-Suspend Column */}
                      <td className="px-5 py-4 font-sans">
                        <button
                          type="button"
                          onClick={() => handleOpenSuspendModal(s)}
                          className={`px-2.5 py-1 rounded-xl border text-[11px] font-mono flex items-center gap-1.5 transition-all ${
                            s.auto_suspend_type === 'datetime' && s.auto_suspend_at
                              ? 'bg-purple-500/15 text-purple-300 border-purple-500/30 hover:bg-purple-500/25'
                              : s.auto_suspend_type === 'daily_time' && s.auto_suspend_time
                              ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/25'
                              : autoSuspendHours > 0
                              ? 'bg-amber-500/15 text-amber-300 border-amber-500/30 hover:bg-amber-500/25'
                              : 'bg-black/30 text-slate-400 border-white/10 hover:text-white hover:border-white/20'
                          }`}
                          title="Configure Auto-Suspend Policy (Timer / Calendar / Daily)"
                        >
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>
                            {s.auto_suspend_type === 'datetime' && s.auto_suspend_at
                              ? `📅 ${new Date(s.auto_suspend_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} ${new Date(s.auto_suspend_at).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', hour12: true })}`
                              : s.auto_suspend_type === 'daily_time' && s.auto_suspend_time
                              ? `⏰ ${formatDisplay12(s.auto_suspend_time)} Daily`
                              : autoSuspendHours > 0
                              ? `${autoSuspendHours}h Sleep`
                              : 'Always On'}
                          </span>
                        </button>
                      </td>

                      {/* Status Column */}
                      <td className="px-5 py-4">
                        {isSuspended ? (
                          <span
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40"
                            title={s.suspend_reason || 'Suspended'}
                          >
                            <ShieldAlert className="w-3 h-3 text-rose-400" />
                            Suspended
                          </span>
                        ) : (
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              isRunning
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-slate-500/20 text-slate-400 border border-slate-500/30'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                            {s.status}
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5 font-sans">
                          {/* Suspend / Unsuspend Quick Button */}
                          <button
                            onClick={() => handleToggleSuspend(s)}
                            className={`p-1.5 rounded-lg border transition-all ${
                              isSuspended
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30'
                                : 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
                            }`}
                            title={isSuspended ? 'Unsuspend this VM' : 'Suspend this VM (Admin Override)'}
                          >
                            {isSuspended ? (
                              <PlayCircle className="w-3.5 h-3.5" />
                            ) : (
                              <PauseCircle className="w-3.5 h-3.5" />
                            )}
                          </button>

                          {isRunning ? (
                            <>
                              <button
                                onClick={() => handlePower(s.id, 'restart')}
                                className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 transition-colors"
                                title="Restart VM"
                              >
                                <RotateCw className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handlePower(s.id, 'stop')}
                                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 transition-colors"
                                title="Stop VM"
                              >
                                <Square className="w-3.5 h-3.5 fill-current" />
                              </button>
                            </>
                          ) : !isSuspended ? (
                            <button
                              onClick={() => handlePower(s.id, 'start')}
                              className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 transition-colors"
                              title="Start VM"
                            >
                              <Play className="w-3.5 h-3.5 fill-current" />
                            </button>
                          ) : null}

                          <button
                            onClick={() => {
                              setTargetServerForTransfer(s);
                              setNewOwnerId(String(s.user_id));
                              setTransferModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
                            title="Transfer Ownership"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                          </button>

                          <Link
                            to={`/servers/${s.id}/console`}
                            className="p-1.5 rounded-lg bg-brand-500/10 hover:bg-brand-500/20 text-brand-300 transition-colors"
                            title="Open Console"
                          >
                            <Terminal className="w-3.5 h-3.5" />
                          </Link>

                          <button
                            onClick={() => handleDelete(s.id, s.name)}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                            title="Delete Server"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {/* Auto-Suspend VM Policy Modal */}
      <Modal
        isOpen={suspendModalOpen}
        onClose={() => setSuspendModalOpen(false)}
        title={`Full Custom Auto-Suspend Policy: ${targetServerForSuspend?.name}`}
      >
        <form onSubmit={handleSaveSuspendPolicy} className="space-y-4 font-sans text-xs">
          <p className="text-slate-400">
            Configure how and when this virtual machine container will automatically stop and sleep to optimize server resources and save memory.
          </p>

          <AutoSuspendPicker
            suspendType={selectedSuspendType}
            setSuspendType={setSelectedSuspendType}
            suspendHours={selectedSuspendHours}
            setSuspendHours={setSelectedSuspendHours}
            suspendAt={selectedSuspendAt}
            setSuspendAt={setSelectedSuspendAt}
            suspendTime={selectedSuspendTime}
            setSuspendTime={setSelectedSuspendTime}
          />

          <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={() => setSuspendModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={savingSuspend}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-brand-500 to-purple-600 hover:from-brand-600 hover:to-purple-700 text-white text-xs font-bold shadow-md disabled:opacity-50"
            >
              {savingSuspend ? 'Saving...' : 'Save Policy'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Transfer Ownership Modal */}
      <Modal
        isOpen={transferModalOpen}
        onClose={() => setTransferModalOpen(false)}
        title={`Transfer Ownership: ${targetServerForTransfer?.name}`}
      >
        <form onSubmit={handleTransferOwner} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Select New Owner
            </label>
            <select
              value={newOwnerId}
              onChange={(e) => setNewOwnerId(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.username} ({u.email})
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setTransferModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shadow-md"
            >
              Confirm Transfer
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
