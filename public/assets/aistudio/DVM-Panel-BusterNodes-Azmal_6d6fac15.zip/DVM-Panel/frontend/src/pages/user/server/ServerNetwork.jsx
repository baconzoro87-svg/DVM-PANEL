import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Wifi,
  Network,
  Globe,
  Radio,
  ArrowDown,
  ArrowUp,
  Plus,
  Trash2,
  Copy,
  Check,
  RotateCw,
  Sparkles,
  Server,
  ShieldCheck,
  Activity,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';

export default function ServerNetwork() {
  const { server, fetchServerDetails } = useOutletContext();

  const [networkData, setNetworkData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copiedPort, setCopiedPort] = useState(null);

  // Add Port Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [containerPort, setContainerPort] = useState('');
  const [hostPort, setHostPort] = useState('');
  const [protocol, setProtocol] = useState('TCP');
  const [useAutoHostPort, setUseAutoHostPort] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [actionSuccess, setActionSuccess] = useState('');
  const [actionError, setActionError] = useState('');

  // Auto port recommendation
  const [nextFreePort, setNextFreePort] = useState(null);

  const fetchNetwork = async () => {
    try {
      const [netRes, portRes] = await Promise.all([
        api.get(`/servers/${server.id}/network`),
        api.get('/ports/next-free').catch(() => null)
      ]);
      if (netRes.success) setNetworkData(netRes);
      if (portRes?.success) setNextFreePort(portRes.nextPort);
    } catch (err) {
      console.error('Failed to fetch network telemetry:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNetwork();
    const interval = setInterval(fetchNetwork, 3000);
    return () => clearInterval(interval);
  }, [server.id]);

  const copyText = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopiedPort(key);
    setTimeout(() => setCopiedPort(null), 2000);
  };

  const handleAddPort = async (e) => {
    e.preventDefault();
    if (!containerPort) return;
    setSubmitting(true);
    setActionError('');
    setActionSuccess('');

    try {
      const res = await api.post(`/servers/${server.id}/network/ports`, {
        containerPort: parseInt(containerPort, 10),
        hostPort: useAutoHostPort ? undefined : parseInt(hostPort, 10),
        protocol
      });

      if (res.success) {
        setActionSuccess(res.message);
        setAddModalOpen(false);
        setContainerPort('');
        setHostPort('');
        fetchNetwork();
        fetchServerDetails();
        setTimeout(() => setActionSuccess(''), 4000);
      }
    } catch (err) {
      setActionError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeletePort = async (index) => {
    if (!confirm('Are you sure you want to remove this port forwarding rule?')) return;
    try {
      const res = await api.delete(`/servers/${server.id}/network/ports/${index}`);
      if (res.success) {
        fetchNetwork();
        fetchServerDetails();
      }
    } catch (err) {
      alert(`Failed to remove port: ${err.message}`);
    }
  };

  const net = networkData?.network || {};
  const currentStats = networkData?.currentStats || {};
  const additionalPorts = networkData?.server?.additional_ports || [];
  const isRunning = server.status === 'running';

  return (
    <div className="space-y-6">
      {/* Top Notification */}
      {actionSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 animate-fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Network className="w-5 h-5 text-brand-400" />
            Network Topology & Port Mappings
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time interface telemetry, inbound/outbound bandwidth speeds, and port allocations.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-brand-500/25 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Port Forwarding</span>
          </button>
        </div>
      </div>

      {/* Network Interface Specs Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Virtual Bridge IP */}
        <GlassCard className="p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider font-sans">Internal Guest IP</span>
            <Globe className="w-4 h-4 text-brand-400" />
          </div>
          <div className="flex items-center justify-between pt-1">
            <span className="text-base font-bold text-white font-mono">{net.ipAddress || '172.17.0.2'}</span>
            <button
              onClick={() => copyText(net.ipAddress || '172.17.0.2', 'ip')}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5"
            >
              {copiedPort === 'ip' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </GlassCard>

        {/* Gateway */}
        <GlassCard className="p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider font-sans">Default Gateway</span>
            <Radio className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-center justify-between pt-1">
            <span className="text-base font-bold text-slate-200 font-mono">{net.gateway || '172.17.0.1'}</span>
            <button
              onClick={() => copyText(net.gateway || '172.17.0.1', 'gw')}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/5"
            >
              {copiedPort === 'gw' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </GlassCard>

        {/* MAC Address */}
        <GlassCard className="p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider font-sans">Hardware MAC</span>
            <Server className="w-4 h-4 text-purple-400" />
          </div>
          <div className="pt-1">
            <span className="text-xs font-bold text-purple-300 font-mono truncate block">
              {net.macAddress || 'N/A'}
            </span>
          </div>
        </GlassCard>

        {/* Total Bandwidth */}
        <GlassCard className="p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider font-sans">Total Data Transfer</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="pt-1">
            <span className="text-base font-bold text-emerald-400 font-mono">
              {net.totalTransfer || '0 B'}
            </span>
          </div>
        </GlassCard>
      </div>

      {/* Live RX / TX Real-Time Meters */}
      <GlassCard className="p-6 space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Wifi className="w-4 h-4 text-cyan-400" /> Live Bandwidth Rate (Real-Time Throughput)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Download RX */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <ArrowDown className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-300 block">Download Speed (RX)</span>
                <span className="text-[10px] text-slate-500 font-mono">Total Received: {net.totalRx || '0 B'}</span>
              </div>
            </div>
            <span className="text-lg font-extrabold text-emerald-400 font-mono">
              {net.rxSpeed || '0 B/s'}
            </span>
          </div>

          {/* Upload TX */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <ArrowUp className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-300 block">Upload Speed (TX)</span>
                <span className="text-[10px] text-slate-500 font-mono">Total Sent: {net.totalTx || '0 B'}</span>
              </div>
            </div>
            <span className="text-lg font-extrabold text-cyan-400 font-mono">
              {net.txSpeed || '0 B/s'}
            </span>
          </div>
        </div>
      </GlassCard>

      {/* Port Allocations Table */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Radio className="w-4 h-4 text-brand-400" /> Active Port Mappings & Allocations
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Host port forwards routing traffic into this container VM.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Total Allocated: <strong className="text-white">{1 + additionalPorts.length}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-black/40 text-slate-400 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="px-4 py-3">Purpose</th>
                <th className="px-4 py-3">Protocol</th>
                <th className="px-4 py-3">Host Port (External)</th>
                <th className="px-4 py-3">VM Port (Internal)</th>
                <th className="px-4 py-3">Connection String</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {/* Primary SSH Port (Permanent) */}
              <tr className="hover:bg-white/5 transition-colors">
                <td className="px-4 py-3.5 font-sans font-bold text-brand-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-brand-400" />
                  Primary SSH Console
                </td>
                <td className="px-4 py-3.5 text-slate-300">TCP</td>
                <td className="px-4 py-3.5 font-bold text-white text-sm">{server.port_ssh}</td>
                <td className="px-4 py-3.5 text-slate-400">22</td>
                <td className="px-4 py-3.5 text-emerald-400 font-bold">
                  ssh -p {server.port_ssh} root@localhost
                </td>
                <td className="px-4 py-3.5 text-right">
                  <button
                    onClick={() => copyText(`ssh -p ${server.port_ssh} root@localhost`, 'ssh')}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 font-sans text-[11px] inline-flex items-center gap-1"
                  >
                    {copiedPort === 'ssh' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPort === 'ssh' ? 'Copied' : 'Copy'}</span>
                  </button>
                </td>
              </tr>

              {/* Additional Mappings */}
              {additionalPorts.map((p, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3.5 font-sans text-slate-300 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    Additional Service #{idx + 1}
                  </td>
                  <td className="px-4 py-3.5 text-slate-300">{p.protocol || 'TCP'}</td>
                  <td className="px-4 py-3.5 font-bold text-cyan-300 text-sm">{p.host}</td>
                  <td className="px-4 py-3.5 text-slate-400">{p.container}</td>
                  <td className="px-4 py-3.5 text-slate-300">
                    localhost:{p.host} ➔ :{p.container}
                  </td>
                  <td className="px-4 py-3.5 text-right">
                    <button
                      onClick={() => handleDeletePort(idx)}
                      className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                      title="Remove Port Mapping"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Add Port Forwarding Modal */}
      <Modal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        title="Add Port Forwarding Rule"
      >
        <form onSubmit={handleAddPort} className="space-y-4">
          <div className="p-3 rounded-xl bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs">
            💡 Map a host external port to a service port inside the VM (e.g. web server on port 80 or 8080).
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Container Internal Port (Inside VM)
            </label>
            <input
              type="number"
              required
              value={containerPort}
              onChange={(e) => setContainerPort(e.target.value)}
              placeholder="e.g. 80, 3000, 8080, 25565"
              min="1"
              max="65535"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-slate-300">
                Host External Port
              </label>
              <div
                onClick={() => setUseAutoHostPort(!useAutoHostPort)}
                className="flex items-center gap-1.5 text-xs text-brand-400 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={useAutoHostPort}
                  onChange={() => {}}
                  className="rounded text-brand-500"
                />
                <span>Auto-Allocate (Next: {nextFreePort || '25501-25599'})</span>
              </div>
            </div>

            {!useAutoHostPort ? (
              <input
                type="number"
                required={!useAutoHostPort}
                value={hostPort}
                onChange={(e) => setHostPort(e.target.value)}
                placeholder="e.g. 25505"
                min="25501"
                max="25599"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            ) : (
              <div className="p-2.5 rounded-xl bg-black/50 border border-white/10 text-emerald-400 text-xs font-mono flex items-center justify-between">
                <span>Auto Host Port: <strong>{nextFreePort || '25501+'}</strong></span>
                <span className="text-[10px] text-slate-500">From Pool 25501-25599</span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Protocol
            </label>
            <select
              value={protocol}
              onChange={(e) => setProtocol(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            >
              <option value="TCP">TCP</option>
              <option value="UDP">UDP</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setAddModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shadow-md disabled:opacity-50"
            >
              {submitting ? 'Allocating...' : 'Allocate Port'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

