import React, { useState, useEffect } from 'react';
import { useParams, NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import {
  Server,
  Play,
  Square,
  RotateCw,
  Zap,
  Activity,
  Terminal as TermIcon,
  FolderTree,
  Archive,
  Calendar,
  Sliders,
  Users,
  Settings,
  Clock,
  ArrowLeft,
  Copy,
  Check,
  RefreshCw,
  BarChart2,
  Network as NetIcon
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';

export default function ServerLayout() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [server, setServer] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [copied, setCopied] = useState(false);

  const fetchServerDetails = async () => {
    try {
      const res = await api.get(`/servers/${id}`);
      if (res.success) {
        setServer(res.server);
        setStats(res.stats);
      }
    } catch (err) {
      console.error('Error loading server:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchServerDetails();
    const interval = setInterval(fetchServerDetails, 4000);
    return () => clearInterval(interval);
  }, [id]);

  const handlePower = async (action) => {
    setActionLoading(action);
    try {
      const res = await api.post(`/servers/${id}/power`, { action });
      if (res.success) {
        await fetchServerDetails();
      }
    } catch (err) {
      alert(`Power action failed: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const copySsh = () => {
    if (!server) return;
    const host = window.location.hostname || 'localhost';
    const cmd = `ssh root@${host} -p ${server.port_ssh}`;
    navigator.clipboard.writeText(cmd);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading && !server) {
    return (
      <div className="py-24 text-center text-slate-400">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-xs">Loading virtual machine configuration...</p>
      </div>
    );
  }

  if (!server) {
    return (
      <GlassCard className="py-16 text-center">
        <p className="text-sm font-semibold text-rose-400 mb-4">Server not found or access denied.</p>
        <Link to="/" className="px-4 py-2 rounded-xl bg-brand-500 text-white text-xs font-semibold">
          Return to Dashboard
        </Link>
      </GlassCard>
    );
  }

  const isSuspended = server.is_suspended || server.status === 'suspended';
  const isRunning = !isSuspended && server.status === 'running';

  const tabClass = ({ isActive }) =>
    `flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
      isActive
        ? 'bg-brand-500 text-white shadow-md shadow-brand-500/25'
        : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
    }`;

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Status Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <Link to="/" className="hover:text-white flex items-center gap-1">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Servers
            </Link>
            <span>/</span>
            <span className="text-slate-200 font-mono">{server.name}</span>
          </div>

          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-black text-white tracking-tight font-mono">{server.name}</h1>
            {isSuspended ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40">
                <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
                Suspended
              </span>
            ) : (
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                  isRunning
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-slate-500/20 text-slate-400 border border-slate-500/30'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                {server.status || 'stopped'}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5 font-mono">{server.image}</p>
        </div>

        {/* SSH and Power Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* SSH Quick Copy Box */}
          <button
            onClick={copySsh}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-black/50 border border-white/10 hover:border-brand-500/40 text-xs font-mono text-slate-300 transition-all"
            title="Click to copy SSH connect command"
          >
            <span>Port: <strong className="text-brand-400">{server.port_ssh}</strong></span>
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
          </button>

          {/* Power Actions */}
          {isSuspended ? (
            <div className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-500/15 text-rose-300 text-xs font-bold border border-rose-500/30 shadow-inner">
              <span>🔒 VM Suspended (Power Locked)</span>
            </div>
          ) : isRunning ? (
            <>
              <button
                disabled={!!actionLoading}
                onClick={() => handlePower('restart')}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-semibold border border-amber-500/30 transition-all"
              >
                <RotateCw className={`w-3.5 h-3.5 ${actionLoading === 'restart' ? 'animate-spin' : ''}`} />
                <span>Restart</span>
              </button>
              <button
                disabled={!!actionLoading}
                onClick={() => handlePower('stop')}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-semibold border border-rose-500/30 transition-all"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop</span>
              </button>
              <button
                disabled={!!actionLoading}
                onClick={() => handlePower('kill')}
                className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 transition-all"
                title="Force Kill Container"
              >
                <Zap className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <button
              disabled={!!actionLoading}
              onClick={() => handlePower('start')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-emerald-500/25 transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start Server</span>
            </button>
          )}
        </div>
      </div>

      {/* Suspended Alert Banner */}
      {isSuspended && (
        <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 flex items-center justify-between gap-3 text-xs text-rose-200 shadow-lg">
          <div>
            <strong className="text-white text-sm block">⚠️ Virtual Machine is currently Suspended</strong>
            <span className="text-rose-300">{server.suspend_reason || 'This server was auto-suspended by policy or an administrator.'} All power actions, console, and SSH connections are disabled until an administrator unsuspends this VM.</span>
          </div>
        </div>
      )}

      {/* VM Sub-Navigation Tabs */}
      <div className="glass-panel rounded-2xl p-1.5 border border-white/10 flex items-center gap-1 overflow-x-auto">
        <NavLink to={`/servers/${id}/overview`} className={tabClass}>
          <Activity className="w-4 h-4 text-brand-400" />
          <span>Overview</span>
        </NavLink>
        <NavLink to={`/servers/${id}/console`} className={tabClass}>
          <TermIcon className="w-4 h-4 text-emerald-400" />
          <span>Console</span>
        </NavLink>
        <NavLink to={`/servers/${id}/analytics`} className={tabClass}>
          <BarChart2 className="w-4 h-4 text-purple-400" />
          <span>Analytics</span>
        </NavLink>
        <NavLink to={`/servers/${id}/network`} className={tabClass}>
          <NetIcon className="w-4 h-4 text-cyan-400" />
          <span>Network</span>
        </NavLink>
        <NavLink to={`/servers/${id}/files`} className={tabClass}>
          <FolderTree className="w-4 h-4 text-amber-400" />
          <span>File Manager</span>
        </NavLink>
        <NavLink to={`/servers/${id}/backups`} className={tabClass}>
          <Archive className="w-4 h-4 text-purple-400" />
          <span>Backups</span>
        </NavLink>
        <NavLink to={`/servers/${id}/schedules`} className={tabClass}>
          <Calendar className="w-4 h-4 text-cyan-400" />
          <span>Schedules</span>
        </NavLink>
        <NavLink to={`/servers/${id}/startup`} className={tabClass}>
          <Sliders className="w-4 h-4 text-indigo-400" />
          <span>Startup</span>
        </NavLink>
        <NavLink to={`/servers/${id}/subusers`} className={tabClass}>
          <Users className="w-4 h-4 text-pink-400" />
          <span>Subusers</span>
        </NavLink>
        <NavLink to={`/servers/${id}/settings`} className={tabClass}>
          <Settings className="w-4 h-4 text-rose-400" />
          <span>Settings</span>
        </NavLink>
        <NavLink to={`/servers/${id}/activity`} className={tabClass}>
          <Clock className="w-4 h-4 text-teal-400" />
          <span>Activity</span>
        </NavLink>
      </div>

      {/* Tab Child Content */}
      <Outlet context={{ server, stats, fetchServerDetails }} />
    </div>
  );
}

