import React from 'react';
import { BookOpen, Terminal, Server, Key, Shield, Layers, HelpCircle, HardDrive } from 'lucide-react';
import GlassCard from '../../components/GlassCard';

export default function AdminDocs() {
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <BookOpen className="w-6 h-6 text-teal-400" />
          dpanel Documentation & Administrator Manual
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Technical specifications, ports architecture, Linux container templates, and CLI command reference.
        </p>
      </div>

      {/* Network & Ports Architecture */}
      <GlassCard className="p-6 space-y-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Server className="w-5 h-5 text-brand-400" />
          Network & Ports Architecture
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          <code>dpanel</code> runs on dual ports to isolate the client interface from WebSocket streaming and backend Docker operations:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs pt-2">
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-slate-400 text-[10px] block font-sans">Web UI Port</span>
            <span className="text-lg font-bold text-brand-400">3001</span>
            <p className="text-[11px] text-slate-400 mt-1 font-sans">Frontend SPA application</p>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-slate-400 text-[10px] block font-sans">API & WebSocket Port</span>
            <span className="text-lg font-bold text-emerald-400">3002</span>
            <p className="text-[11px] text-slate-400 mt-1 font-sans">REST API & Terminal streams</p>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-slate-400 text-[10px] block font-sans">VM Port Allocation Pool</span>
            <span className="text-lg font-bold text-purple-400">25501 – 25599</span>
            <p className="text-[11px] text-slate-400 mt-1 font-sans">Assigned to container port 22 (SSH)</p>
          </div>
        </div>
      </GlassCard>

      {/* Default Docker Images */}
      <GlassCard className="p-6 space-y-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-amber-400" />
          Supported Linux Container Images
        </h2>
        <p className="text-xs text-slate-300">
          The panel comes with built-in support for official high-performance Linux distribution images on Docker Hub:
        </p>
        <div className="divide-y divide-white/10 font-mono text-xs">
          <div className="py-2.5 flex justify-between items-center">
            <span className="text-emerald-400 font-bold">nobitaa/ubuntu:22</span>
            <span className="text-slate-400 font-sans">Ubuntu 22.04 LTS (Jammy Jellyfish)</span>
          </div>
          <div className="py-2.5 flex justify-between items-center">
            <span className="text-emerald-400 font-bold">nobitaa/ubuntu:24</span>
            <span className="text-slate-400 font-sans">Ubuntu 24.04 LTS (Noble Numbat)</span>
          </div>
          <div className="py-2.5 flex justify-between items-center">
            <span className="text-cyan-400 font-bold">nobitaa/debain:11</span>
            <span className="text-slate-400 font-sans">Debian GNU/Linux 11 (Bullseye)</span>
          </div>
          <div className="py-2.5 flex justify-between items-center">
            <span className="text-cyan-400 font-bold">nobitaa/debain:12</span>
            <span className="text-slate-400 font-sans">Debian GNU/Linux 12 (Bookworm)</span>
          </div>
          <div className="py-2.5 flex justify-between items-center">
            <span className="text-cyan-400 font-bold">nobitaa/debain:13</span>
            <span className="text-slate-400 font-sans">Debian GNU/Linux 13 (Trixie)</span>
          </div>
        </div>
      </GlassCard>

      {/* Docker Command Execution Model */}
      <GlassCard className="p-6 space-y-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Terminal className="w-5 h-5 text-purple-400" />
          Docker Run Execution Specification
        </h2>
        <p className="text-xs text-slate-300">
          Every virtual machine container is launched with hardware resource throttling and privileged capabilities:
        </p>
        <pre className="p-4 rounded-xl bg-black/60 text-emerald-400 font-mono text-xs border border-white/10 overflow-x-auto leading-relaxed">
{`docker run -d --privileged \\
  -p $port:22 \\
  -e VM_NAME=$VM_NAME \\
  -e HOSTNAME=$HOSTNAME \\
  -e RAM=$RAM \\
  -e CPUS=$CPUS \\
  -e DISK_SIZE=$DISK_SIZE \\
  --name $VM_NAME \\
  $IMAGE`}
        </pre>
      </GlassCard>

      {/* CLI & Production Runner Commands */}
      <GlassCard className="p-6 space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Shield className="w-5 h-5 text-rose-400" />
          CLI Commands & PM2 Deployment
        </h2>

        <div className="space-y-3 text-xs">
          <div>
            <span className="text-slate-200 font-bold block mb-1">Create Admin or User via Terminal:</span>
            <code className="p-2.5 rounded-lg bg-black/50 text-brand-300 font-mono block select-all">
              npm run createuser
            </code>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Or non-interactively with flags: <code>npm run createuser -- --username admin --email admin@dpanel.io --password mypass --role admin</code>
            </span>
          </div>

          <div>
            <span className="text-slate-200 font-bold block mb-1">Build Production Assets:</span>
            <code className="p-2.5 rounded-lg bg-black/50 text-brand-300 font-mono block select-all">
              npm run build
            </code>
          </div>

          <div>
            <span className="text-slate-200 font-bold block mb-1">Run Production (Both Ports 3001 & 3002):</span>
            <code className="p-2.5 rounded-lg bg-black/50 text-brand-300 font-mono block select-all">
              npm run start
            </code>
          </div>

          <div>
            <span className="text-slate-200 font-bold block mb-1">Run with PM2 Process Manager:</span>
            <code className="p-2.5 rounded-lg bg-black/50 text-brand-300 font-mono block select-all">
              pm2 start ecosystem.config.js
            </code>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}

