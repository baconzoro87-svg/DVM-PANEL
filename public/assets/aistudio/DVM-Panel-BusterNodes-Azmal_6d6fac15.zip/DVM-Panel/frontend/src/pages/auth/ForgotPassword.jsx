import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Server, Mail, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { api } from '../../utils/api';
import BackgroundPlayer from '../../components/BackgroundPlayer';
import GlassCard from '../../components/GlassCard';

export default function ForgotPassword() {
  const { settings, effectiveLogo } = useTheme();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      const res = await api.post('/auth/forgot-password', { email });
      if (res.success) {
        setMessage(res.message);
        if (res.resetToken) setResetToken(res.resetToken);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <BackgroundPlayer />
      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center mb-3">
            {effectiveLogo ? (
              <img src={effectiveLogo} alt="Logo" className="w-16 h-16 object-contain rounded-2xl shadow-xl border border-white/10" />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-400 flex items-center justify-center text-white shadow-xl shadow-brand-500/25 border border-white/10">
                <Server className="w-8 h-8" />
              </div>
            )}
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">{settings.panel_name || 'DVM Panel'}</h1>
          <p className="text-xs text-slate-400 mt-1">Recover account access</p>
          <p className="text-[10px] text-rose-300/70 mt-2 tracking-widest uppercase">BusterNodes · Made by Azmal</p>
        </div>

        <GlassCard className="p-8 shadow-2xl border-white/15">
          <h2 className="text-lg font-semibold text-white mb-1">Forgot Password</h2>
          <p className="text-xs text-slate-400 mb-6">Enter your registered email address to receive password reset instructions.</p>

          {message && (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs mb-5 space-y-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{message}</span>
              </div>
              {resetToken && (
                <div className="pt-2 border-t border-emerald-500/20">
                  <p className="text-[11px] text-slate-300">Quick Reset Link (No SMTP required):</p>
                  <Link to={`/reset-password?token=${resetToken}`} className="text-brand-400 underline font-mono text-[10px] break-all">
                    Click here to reset your password now
                  </Link>
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs mb-5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-[0.98] text-white text-xs font-semibold shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2 disabled:opacity-50 transition-all"
            >
              {loading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <span>Send Reset Link</span>}
            </button>
          </form>

          <p className="text-center text-xs text-slate-400 mt-6">
            Remember your password?{' '}
            <Link to="/login" className="text-brand-400 hover:text-brand-300 font-medium transition-colors">
              Sign In
            </Link>
          </p>
        </GlassCard>
      </div>
    </div>
  );
}

