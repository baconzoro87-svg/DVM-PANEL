import React, { useState, useEffect } from 'react';
import { useOutletContext, useNavigate } from 'react-router-dom';
import {
  Settings,
  Save,
  RotateCw,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Layers,
  HardDrive,
  Key,
  Lock,
  Eye,
  EyeOff,
  Copy,
  Check,
  Code,
  Plus,
  X,
  Clock
} from 'lucide-react';
import { api } from '../../../utils/api';
import { useAuth } from '../../../context/AuthContext';
import { useTheme } from '../../../context/ThemeContext';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';
import CustomResourcePicker from '../../../components/CustomResourcePicker';
import AutoSuspendPicker from '../../../components/AutoSuspendPicker';

export default function ServerSettings() {
  const { server, fetchServerDetails } = useOutletContext();
  const { isAdmin } = useAuth();
  const { supportedImages } = useTheme();
  const navigate = useNavigate();

  const [name, setName] = useState(server.name || '');
  const [hostname, setHostname] = useState(server.hostname || '');
  const [ram, setRam] = useState(server.memory_limit || '1G');
  const [cpus, setCpus] = useState(server.cpu_limit || '1');
  const [diskSize, setDiskSize] = useState(server.disk_limit || '10G');

  // Full Custom Auto-Suspend Engine (Timer / Calendar / Daily Schedule)
  const [autoSuspendType, setAutoSuspendType] = useState(server.auto_suspend_type || 'hours');
  const [autoSuspendHours, setAutoSuspendHours] = useState(String(server.auto_suspend_hours || '0'));
  const [autoSuspendAt, setAutoSuspendAt] = useState(server.auto_suspend_at || '');
  const [autoSuspendTime, setAutoSuspendTime] = useState(server.auto_suspend_time || '23:00');

  // SSH Credentials
  const [sshUser, setSshUser] = useState(server.ssh_user || 'root');
  const [sshPassword, setSshPassword] = useState(server.ssh_password || 'root');
  const [showPassword, setShowPassword] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  // Custom Environment Variables
  const [customEnvList, setCustomEnvList] = useState([]);
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvVal, setNewEnvVal] = useState('');

  const [reinstallImage, setReinstallImage] = useState(server.image || 'nobitaa/ubuntu:22');
  const [reinstallModalOpen, setReinstallModalOpen] = useState(false);
  const [reinstalling, setReinstalling] = useState(false);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteConfirmName, setDeleteConfirmName] = useState('');
  const [deleting, setDeleting] = useState(false);

  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [quota, setQuota] = useState(null);

  const fetchQuota = async () => {
    try {
      const res = await api.get(`/servers/user/quota?excludeServerId=${server.id}`);
      if (res.success && res.quota) {
        setQuota(res.quota);
      }
    } catch (e) {}
  };

  useEffect(() => {
    fetchQuota();
  }, [server.id]);

  useEffect(() => {
    // Parse existing custom env vars
    try {
      let parsed = {};
      if (typeof server.env_vars === 'string') {
        parsed = JSON.parse(server.env_vars || '{}');
      } else if (typeof server.env_vars === 'object' && server.env_vars !== null) {
        parsed = server.env_vars;
      }
      const systemKeys = ['VM_NAME', 'HOSTNAME', 'RAM', 'CPUS', 'DISK_SIZE'];
      const customPairs = Object.entries(parsed)
        .filter(([k]) => !systemKeys.includes(k))
        .map(([key, value]) => ({ key, value: String(value) }));
      setCustomEnvList(customPairs);
    } catch (e) {
      setCustomEnvList([]);
    }
  }, [server.env_vars]);

  const defaultImages = [
    { id: 'nobitaa/ubuntu:22', name: 'Ubuntu 22.04 LTS' },
    { id: 'nobitaa/ubuntu:24', name: 'Ubuntu 24.04 LTS' },
    { id: 'nobitaa/debain:11', name: 'Debian 11' },
    { id: 'nobitaa/debain:12', name: 'Debian 12' },
    { id: 'nobitaa/debain:13', name: 'Debian 13' }
  ];

  const imageList = supportedImages?.length > 0 ? supportedImages : defaultImages;
  const sshCmd = `ssh -p ${server.port_ssh} ${sshUser}@localhost`;

  const copySshCmd = () => {
    navigator.clipboard.writeText(sshCmd);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const addCustomEnv = () => {
    const k = newEnvKey.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    if (!k) return;
    if (customEnvList.some(item => item.key === k)) {
      alert(`Environment variable "${k}" already exists.`);
      return;
    }
    setCustomEnvList([...customEnvList, { key: k, value: newEnvVal.trim() }]);
    setNewEnvKey('');
    setNewEnvVal('');
  };

  const removeCustomEnv = (indexToRemove) => {
    setCustomEnvList(customEnvList.filter((_, idx) => idx !== indexToRemove));
  };

  const updateCustomEnvVal = (index, newVal) => {
    const updated = [...customEnvList];
    updated[index].value = newVal;
    setCustomEnvList(updated);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    // Prepare complete merged env_vars object
    const finalEnv = {
      VM_NAME: name.trim().toLowerCase(),
      HOSTNAME: hostname.trim() || name.trim().toLowerCase(),
      RAM: String(ram).toUpperCase(),
      CPUS: String(cpus),
      DISK_SIZE: String(diskSize).toUpperCase()
    };

    customEnvList.forEach(item => {
      if (item.key.trim()) {
        finalEnv[item.key.trim()] = item.value;
      }
    });

    const payload = {
      name: name.trim().toLowerCase(),
      hostname: hostname.trim() || name.trim().toLowerCase(),
      memory_limit: ram,
      cpu_limit: cpus,
      disk_limit: diskSize,
      env_vars: finalEnv,
      ssh_user: sshUser.trim() || 'root',
      ssh_password: sshPassword.trim() || 'root',
      auto_suspend_type: autoSuspendType,
      auto_suspend_hours: parseInt(autoSuspendHours, 10) || 0,
      auto_suspend_at: autoSuspendType === 'datetime' ? autoSuspendAt : null,
      auto_suspend_time: autoSuspendType === 'daily_time' ? autoSuspendTime : ''
    };

    try {
      const res = await api.put(`/servers/${server.id}`, payload);
      if (res.success) {
        setSuccess('Server settings & resource limits updated successfully.');
        fetchServerDetails();
        fetchQuota();
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleReinstall = async (e) => {
    e.preventDefault();
    setReinstalling(true);
    try {
      const res = await api.post(`/servers/${server.id}/reinstall`, { image: reinstallImage });
      if (res.success) {
        setReinstallModalOpen(false);
        alert('Operating system reinstalled successfully.');
        fetchServerDetails();
      }
    } catch (err) {
      alert(`Reinstallation failed: ${err.message}`);
    } finally {
      setReinstalling(false);
    }
  };

  const handleDelete = async (e) => {
    e.preventDefault();
    if (deleteConfirmName !== server.name) {
      return alert('Server name confirmation does not match.');
    }

    setDeleting(true);
    try {
      const res = await api.delete(`/servers/${server.id}`);
      if (res.success) {
        navigate('/');
      }
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* General Settings */}
      <form onSubmit={handleUpdate} className="space-y-6">
        <GlassCard className="p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-brand-400" />
                  VM Details & Resource Limits
                </h2>
                {quota && !quota.isAdmin && (
                  <span className="px-2 py-0.5 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-300 text-[10px] font-bold uppercase tracking-wider">
                    Quota Enforced
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Update naming and hardware limits for this container within your allocated resource quota
              </p>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/25 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>

          {/* User Quota Banner */}
          {quota && !quota.isAdmin && (
            <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="font-bold block text-white">Your Available Resource Limits:</span>
                <span className="text-[11px] text-purple-300/80">
                  You can assign up to your maximum remaining quota to this VM.
                </span>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="px-2 py-1 rounded-lg bg-black/40 border border-purple-500/30 text-purple-300">
                  Max RAM: <strong className="text-white">{quota.available.ramStr}</strong>
                </span>
                <span className="px-2 py-1 rounded-lg bg-black/40 border border-cyan-500/30 text-cyan-300">
                  Max CPU: <strong className="text-white">{quota.available.cpu}C</strong>
                </span>
                <span className="px-2 py-1 rounded-lg bg-black/40 border border-emerald-500/30 text-emerald-300">
                  Max Disk: <strong className="text-white">{quota.available.diskStr}</strong>
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Server Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Hostname</label>
              <input
                type="text"
                value={hostname}
                onChange={(e) => setHostname(e.target.value)}
                placeholder="e.g. vm1"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-white/10">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-3 font-sans">
              Custom Resource Limits:
            </span>
            <CustomResourcePicker
              ram={ram}
              setRam={setRam}
              cpus={cpus}
              setCpus={setCpus}
              diskSize={diskSize}
              setDiskSize={setDiskSize}
            />
          </div>
        </GlassCard>

        {/* Auto-Suspend & Sleep Automation Policy */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-400" />
                VM Auto-Suspend & Sleep Automation Policy
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Configure auto-sleep policy to stop this virtual machine container by runtime timer, calendar date & time, or daily schedule.
              </p>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/25 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Policy'}</span>
            </button>
          </div>

          <AutoSuspendPicker
            suspendType={autoSuspendType}
            setSuspendType={setAutoSuspendType}
            suspendHours={autoSuspendHours}
            setSuspendHours={setAutoSuspendHours}
            suspendAt={autoSuspendAt}
            setSuspendAt={setAutoSuspendAt}
            suspendTime={autoSuspendTime}
            setSuspendTime={setAutoSuspendTime}
          />
        </GlassCard>

        {/* Container Environment Variables Section */}
        <GlassCard className="p-6 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Code className="w-5 h-5 text-cyan-400" />
                Container Environment Variables
              </h2>
              <p className="text-xs text-slate-400">
                Variables passed to the container at launch (<code className="text-brand-300">$VM_NAME</code>, <code className="text-brand-300">$HOSTNAME</code>, <code className="text-brand-300">$RAM</code>, <code className="text-brand-300">$CPUS</code>, <code className="text-brand-300">$DISK_SIZE</code>)
              </p>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/25 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Env Vars'}</span>
            </button>
          </div>

          {/* Automatic Launch Variables */}
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-sans">
              Automatic Launch Variables (Synced with VM Specs):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5 font-mono text-xs">
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$VM_NAME</span>
                <span className="text-emerald-300 font-bold">{name || server.name}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$HOSTNAME</span>
                <span className="text-emerald-300 font-bold">{hostname || name || server.name}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$RAM</span>
                <span className="text-purple-300 font-bold">{ram}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$CPUS</span>
                <span className="text-cyan-300 font-bold">{cpus}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$DISK_SIZE</span>
                <span className="text-emerald-300 font-bold">{diskSize}</span>
              </div>
            </div>
          </div>

          {/* Custom Environment Variables Key-Value Editor */}
          <div className="pt-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-sans">
              Custom Container Environment Variables:
            </span>

            {customEnvList.length > 0 ? (
              <div className="space-y-2 mb-3">
                {customEnvList.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 font-mono text-xs">
                    <div className="w-1/3 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-cyan-300 font-bold truncate">
                      ${item.key}
                    </div>
                    <input
                      type="text"
                      value={item.value}
                      onChange={(e) => updateCustomEnvVal(idx, e.target.value)}
                      placeholder="Value"
                      className="flex-1 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-brand-500"
                    />
                    <button
                      type="button"
                      onClick={() => removeCustomEnv(idx)}
                      className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                      title="Remove Variable"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic mb-3">No custom environment variables added yet.</p>
            )}

            {/* Add New Variable Input Bar */}
            <div className="flex flex-col sm:flex-row items-center gap-2 p-3 rounded-2xl bg-black/30 border border-dashed border-white/15">
              <input
                type="text"
                value={newEnvKey}
                onChange={(e) => setNewEnvKey(e.target.value)}
                placeholder="VARIABLE_NAME (e.g. PORT)"
                className="w-full sm:w-1/3 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-cyan-300 font-mono text-xs uppercase focus:outline-none focus:border-cyan-500"
              />
              <input
                type="text"
                value={newEnvVal}
                onChange={(e) => setNewEnvVal(e.target.value)}
                placeholder="VARIABLE_VALUE (e.g. 8080 or production)"
                className="w-full sm:flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
              <button
                type="button"
                onClick={addCustomEnv}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-bold border border-cyan-500/30 flex items-center justify-center gap-1.5 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Variable</span>
              </button>
            </div>
          </div>
        </GlassCard>

        {/* SSH Credentials */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-400" />
                SSH Authentication & Access Credentials
              </h2>
              <p className="text-xs text-slate-400">
                Default is <code>root:root</code>. You can configure custom user/pass below.
              </p>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/25 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Update SSH'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SSH User</label>
              <input
                type="text"
                required
                value={sshUser}
                onChange={(e) => setSshUser(e.target.value)}
                placeholder="root"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Default: root</span>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SSH Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={sshPassword}
                  onChange={(e) => setSshPassword(e.target.value)}
                  placeholder="root"
                  className="w-full px-4 py-2.5 pr-10 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">Default: root</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-black/50 border border-white/10 flex items-center justify-between gap-3 text-xs font-mono">
            <div className="overflow-hidden">
              <span className="text-[10px] text-slate-400 font-sans block">SSH Connection Command:</span>
              <code className="text-emerald-400 font-bold truncate block">{sshCmd}</code>
            </div>
            <button
              type="button"
              onClick={copySshCmd}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-sans shrink-0"
            >
              {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </GlassCard>
      </form>

      {/* Reinstall OS */}
      <GlassCard className="p-6 border-amber-500/20 bg-amber-500/5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-amber-300 flex items-center gap-2">
              <RotateCw className="w-5 h-5" />
              Reinstall Operating System
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Wipe the container and cleanly redeploy a fresh base image. All data inside the current container filesystem will be reset.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setReinstallModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold border border-amber-500/30 transition-all shrink-0"
          >
            Reinstall OS
          </button>
        </div>
      </GlassCard>

      {/* Danger Zone: Delete Server */}
      <GlassCard className="p-6 border-rose-500/20 bg-rose-500/5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-rose-400 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Delete Virtual Machine
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Permanently destroy this Docker VM, port allocation, and container resources. This action is irreversible.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setDeleteConfirmName('');
              setDeleteModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-rose-500/25 transition-all shrink-0"
          >
            Delete Server
          </button>
        </div>
      </GlassCard>

      {/* Reinstall Modal */}
      <Modal
        isOpen={reinstallModalOpen}
        onClose={() => setReinstallModalOpen(false)}
        title="Reinstall Operating System Image"
      >
        <form onSubmit={handleReinstall} className="space-y-4">
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
            ⚠️ Warning: Reinstalling will wipe all current container state and reboot with a fresh OS image.
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Select OS Image Template
            </label>
            <select
              value={reinstallImage}
              onChange={(e) => setReinstallImage(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            >
              {imageList.map((img) => (
                <option key={img.id} value={img.id}>
                  {img.id} ({img.name})
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setReinstallModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={reinstalling}
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-black text-xs font-bold shadow-md"
            >
              {reinstalling ? 'Reinstalling...' : 'Confirm Reinstall'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Modal */}
      <Modal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        title={`Delete VM "${server.name}"`}
      >
        <form onSubmit={handleDelete} className="space-y-4">
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            ⚠️ This will destroy container <strong>{server.name}</strong> and free SSH port <strong>{server.port_ssh}</strong>.
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Type <strong className="text-white font-mono">{server.name}</strong> to confirm:
            </label>
            <input
              type="text"
              required
              value={deleteConfirmName}
              onChange={(e) => setDeleteConfirmName(e.target.value)}
              placeholder={server.name}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setDeleteModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={deleting || deleteConfirmName !== server.name}
              className="px-5 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white text-xs font-bold shadow-md"
            >
              {deleting ? 'Deleting...' : 'Permanently Delete'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
