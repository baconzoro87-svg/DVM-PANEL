import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { Terminal as TermIcon, Shield, Radio, Key, Info } from 'lucide-react';
import Terminal from '../../../components/Terminal';
import GlassCard from '../../../components/GlassCard';

export default function ServerConsole() {
  const { server } = useOutletContext();

  const port = server.port_ssh || 25501;
  const user = server.ssh_user || 'root';
  const pass = server.ssh_password || 'root';

  const isSuspended = server.is_suspended || server.status === 'suspended';

  if (isSuspended) {
    return (
      <GlassCard className="py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
          <Shield className="w-8 h-8" />
        </div>
        <div className="max-w-md mx-auto space-y-1.5">
          <h3 className="text-lg font-extrabold text-white">Terminal & Console Locked</h3>
          <p className="text-xs text-rose-300">
            This virtual machine is currently <strong>SUSPENDED</strong> ({server.suspend_reason || 'By Policy/Admin'}).
          </p>
          <p className="text-[11px] text-slate-400">
            Interactive SSH shell and live logs are disabled while the VM is suspended. An administrator must unsuspend this VM before console access is restored.
          </p>
        </div>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <TermIcon className="w-5 h-5 text-brand-400" />
            Live Real VM Terminal & Kernel Logs
          </h2>
          <p className="text-xs text-slate-400">
            Interactive native SSH PTY shell and real-time live system logs for virtual machine <code>{server.name}</code>.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded-xl bg-black/40 border border-white/10 text-brand-300">
            SSH Port: <strong>{port}</strong>
          </span>
          <span className="px-2.5 py-1 rounded-xl bg-black/40 border border-white/10 text-emerald-300">
            User: <strong>{user}</strong>
          </span>
        </div>
      </div>

      {/* Upgraded Terminal Component with Live Logs & SSH */}
      <Terminal
        serverId={server.id}
        serverName={server.name}
        portSsh={port}
        sshUser={user}
        sshPassword={pass}
      />

      {/* SSH Connection Help Card */}
      <GlassCard className="p-4 bg-black/40 border-white/10">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-400 shrink-0 mt-0.5">
            <Key className="w-4 h-4" />
          </div>
          <div className="space-y-1 text-xs">
            <h4 className="font-bold text-white">Direct Terminal SSH Access</h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              You can connect from your local computer terminal using:
            </p>
            <div className="p-2.5 rounded-xl bg-black/60 font-mono text-[11px] text-emerald-300 border border-white/10 select-all space-y-1">
              <div>ssh -p {port} {user}@localhost</div>
              <div className="text-slate-400 text-[10px]"># Password: <strong className="text-amber-300">{pass}</strong></div>
            </div>
            <p className="text-[10px] text-slate-500">
              * Note: Default SSH credentials are <code>root:root</code>. You can customize the username and password anytime in the <strong>Settings</strong> tab.
            </p>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
