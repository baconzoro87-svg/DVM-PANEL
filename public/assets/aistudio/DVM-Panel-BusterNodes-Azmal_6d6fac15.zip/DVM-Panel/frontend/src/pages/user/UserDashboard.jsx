import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Server,
  Plus,
  Play,
  Square,
  RotateCw,
  Terminal,
  Cpu,
  HardDrive,
  Activity,
  Layers,
  Search,
  Grid,
  List,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { api } from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import GlassCard from '../../components/GlassCard';

export default function UserDashboard() {
  const { user } = useAuth();
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [actionLoading, setActionLoading] = useState({});
  const [copiedPort, setCopiedPort] = useState(null);

  const fetchServers = async () => {
    try {
      const res = await api.get('/servers');
      if (res.success) {
        setServers(res.servers || []);
      }
    } catch (err) {
      console.error('Error fetching servers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchServers();
    const interval = setInterval(fetchServers, 5000);
    return () => clearInterval(interval);
  }, []);

  const handlePowerAction = async (e, serverId, action) => {
    e.preventDefault();
    e.stopPropagation();
    setActionLoading(prev => ({ ...prev, [serverId]: action }));
    try {
      await api.post(`/servers/${serverId}/power`, { action });
      await fetchServers();
    } catch (err) {
      alert(`Power action failed: ${err.message}`);
    } finally {
      setActionLoading(prev => ({ ...prev, [serverId]: null }));
    }
  };

  const copySshCommand = (e, server) => {
    e.preventDefault();
    e.stopPropagation();
    const host = window.location.hostname || 'localhost';
    const cmd = `ssh root@${host} -p ${server.port_ssh}`;
    navigator.clipboard.writeText(cmd);
    setCopiedPort(server.id);
    setTimeout(() => setCopiedPort(null), 2000);
  };

  const filteredServers = servers.filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.image?.toLowerCase().includes(search.toLowerCase()) ||
    String(s.port_ssh).includes(search)
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Server className="w-6 h-6 text-brand-400" />
            Virtual Machines
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage, control, and deploy Docker-based virtual server instances.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchServers}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            title="Refresh Status"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <Link
            to="/servers/create"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create New VM</span>
          </Link>
        </div>
      </div>

      {/* Filter & View Mode Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search VMs by name, image, or port..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500 transition-all"
          />
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <span className="text-xs text-slate-400">
            Total: <strong className="text-white">{filteredServers.length}</strong>
          </span>
          <div className="flex items-center p-1 rounded-xl bg-black/40 border border-white/10">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${viewMode === 'grid' ? 'bg-brand-500 text-white' : 'text-slate-400 hover:text-white'}`}
              title="Card Grid View"
            >
              <Grid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${viewMode === 'list' ? 'bg-brand-500 text-white' : 'text-slate-400 hover:text-white'}`}
              title="List View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Server Grid / List */}
      {loading ? (
        <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center">
          <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs">Loading virtual machines...</p>
        </div>
      ) : filteredServers.length === 0 ? (
        <GlassCard className="py-16 text-center">
          <div className="w-14 h-14 rounded-2xl bg-brand-500/10 border border-brand-500/20 text-brand-400 flex items-center justify-center mx-auto mb-4">
            <Server className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white mb-1">No Virtual Machines Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
            {search ? 'No servers match your search criteria.' : 'You do not have any virtual machines deployed yet. Launch your first VM in seconds!'}
          </p>
          <Link
            to="/servers/create"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-lg shadow-brand-500/25"
          >
            <Plus className="w-4 h-4" />
            <span>Deploy VM Now</span>
          </Link>
        </GlassCard>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredServers.map((server) => {
            const isSuspended = server.is_suspended || server.status === 'suspended';
            const isRunning = !isSuspended && server.status === 'running';
            const isActing = actionLoading[server.id];

            return (
              <Link
                key={server.id}
                to={`/servers/${server.id}/overview`}
                className="group block"
              >
                <GlassCard className="h-full flex flex-col justify-between p-5 hover:border-brand-500/50 hover:shadow-lg hover:shadow-brand-500/10 transition-all">
                  <div>
                    {/* Title & Status */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center text-brand-400 group-hover:scale-105 transition-transform">
                          <Server className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-sm font-bold text-white group-hover:text-brand-300 transition-colors font-mono">
                            {server.name}
                          </h3>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {server.image}
                          </span>
                        </div>
                      </div>

                      {isSuspended ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          <ShieldAlert className="w-3 h-3 text-rose-400" />
                          Suspended
                        </span>
                      ) : (
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            isRunning
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                          {server.status || 'stopped'}
                        </span>
                      )}
                    </div>

                    {/* Specs Pills */}
                    <div className="grid grid-cols-3 gap-2 my-4">
                      <div className="p-2 rounded-xl bg-black/30 border border-white/5 text-center">
                        <span className="text-[10px] text-slate-400 block">CPU</span>
                        <span className="text-xs font-bold text-white font-mono">{server.cpu_limit || 1} Core</span>
                      </div>
                      <div className="p-2 rounded-xl bg-black/30 border border-white/5 text-center">
                        <span className="text-[10px] text-slate-400 block">RAM</span>
                        <span className="text-xs font-bold text-white font-mono">{server.memory_limit || '1G'}</span>
                      </div>
                      <div className="p-2 rounded-xl bg-black/30 border border-white/5 text-center">
                        <span className="text-[10px] text-slate-400 block">SSD</span>
                        <span className="text-xs font-bold text-white font-mono">{server.disk_limit || '10G'}</span>
                      </div>
                    </div>

                    {/* SSH Connection Box */}
                    <div
                      onClick={(e) => copySshCommand(e, server)}
                      className="p-2.5 rounded-xl bg-black/50 border border-white/10 flex items-center justify-between text-xs font-mono text-slate-300 hover:border-brand-500/50 hover:bg-black/70 transition-all cursor-pointer group/ssh"
                      title="Click to copy SSH connect command"
                    >
                      <span className="truncate text-[11px] text-slate-400">
                        Port: <strong className="text-brand-300">{server.port_ssh}</strong> (SSH)
                      </span>
                      <span className="flex items-center gap-1 text-[10px] text-brand-400 font-sans group-hover/ssh:underline">
                        {copiedPort === server.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" /> SSH Cmd
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Power Action Buttons */}
                  <div className="flex items-center justify-between pt-4 mt-4 border-t border-white/10">
                    <div className="flex items-center gap-1.5">
                      {isSuspended ? (
                        <span className="px-3 py-1 rounded-xl bg-rose-500/10 text-rose-300 text-[11px] font-bold border border-rose-500/20">
                          🔒 Suspended (Locked)
                        </span>
                      ) : isRunning ? (
                        <>
                          <button
                            disabled={isActing}
                            onClick={(e) => handlePowerAction(e, server.id, 'restart')}
                            className="p-2 rounded-xl bg-white/5 hover:bg-amber-500/20 text-amber-300 hover:text-amber-200 border border-white/10 transition-colors"
                            title="Restart VM"
                          >
                            <RotateCw className={`w-3.5 h-3.5 ${isActing === 'restart' ? 'animate-spin' : ''}`} />
                          </button>
                          <button
                            disabled={isActing}
                            onClick={(e) => handlePowerAction(e, server.id, 'stop')}
                            className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 border border-white/10 transition-colors"
                            title="Stop VM"
                          >
                            <Square className="w-3.5 h-3.5 fill-current" />
                          </button>
                        </>
                      ) : (
                        <button
                          disabled={isActing}
                          onClick={(e) => handlePowerAction(e, server.id, 'start')}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-semibold border border-emerald-500/30 transition-colors"
                          title="Start VM"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Start</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-xs text-slate-400 group-hover:text-brand-300 font-medium">
                      <span>Manage</span>
                      <Terminal className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </GlassCard>
              </Link>
            );
          })}
        </div>
      ) : (
        /* List View */
        <GlassCard className="p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/40 text-slate-400 border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-6 py-3.5">VM Name</th>
                  <th className="px-6 py-3.5">Image</th>
                  <th className="px-6 py-3.5">Port (SSH)</th>
                  <th className="px-6 py-3.5">Resources</th>
                  <th className="px-6 py-3.5">Status</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredServers.map((server) => {
                  const isSuspended = server.is_suspended || server.status === 'suspended';
                  const isRunning = !isSuspended && server.status === 'running';
                  return (
                    <tr key={server.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4 font-bold text-white">
                        <Link to={`/servers/${server.id}/overview`} className="hover:text-brand-300 flex items-center gap-2">
                          <Server className="w-4 h-4 text-brand-400" />
                          {server.name}
                        </Link>
                      </td>
                      <td className="px-6 py-4 text-slate-300 font-mono text-[11px]">{server.image}</td>
                      <td className="px-6 py-4 text-brand-300 font-mono font-semibold">{server.port_ssh}</td>
                      <td className="px-6 py-4 text-slate-300">
                        {server.cpu_limit} Core • {server.memory_limit} • {server.disk_limit}
                      </td>
                      <td className="px-6 py-4">
                        {isSuspended ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30">
                            <ShieldAlert className="w-3 h-3 text-rose-400" />
                            Suspended
                          </span>
                        ) : (
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${isRunning ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-500/20 text-slate-400'}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-emerald-400' : 'bg-slate-400'}`} />
                            {server.status || 'stopped'}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {isSuspended ? (
                            <span className="text-[11px] font-bold text-rose-400 font-mono">
                              🔒 Locked
                            </span>
                          ) : (
                            <>
                              <Link
                                to={`/servers/${server.id}/console`}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                                title="Open Terminal Console"
                              >
                                <Terminal className="w-4 h-4" />
                              </Link>
                              {isRunning ? (
                                <button
                                  onClick={(e) => handlePowerAction(e, server.id, 'stop')}
                                  className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                                  title="Stop"
                                >
                                  <Square className="w-4 h-4 fill-current" />
                                </button>
                              ) : (
                                <button
                                  onClick={(e) => handlePowerAction(e, server.id, 'start')}
                                  className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 transition-colors"
                                  title="Start"
                                >
                                  <Play className="w-4 h-4 fill-current" />
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </GlassCard>
      )}
    </div>
  );
}

