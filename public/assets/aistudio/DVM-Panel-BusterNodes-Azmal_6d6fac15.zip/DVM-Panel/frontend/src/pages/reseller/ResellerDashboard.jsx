import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Crown,
  Users,
  Server,
  Activity,
  TrendingUp,
  PlusCircle,
  ArrowRight,
  UserPlus,
  Shield,
  RefreshCw,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { api } from '../../utils/api';
import GlassCard from '../../components/GlassCard';
import StatCard from '../../components/StatCard';

export default function ResellerDashboard() {
  const [overview, setOverview] = useState(null);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [overviewRes, clientsRes] = await Promise.all([
        api.get('/reseller/overview'),
        api.get('/reseller/clients')
      ]);
      if (overviewRes.success) setOverview(overviewRes.overview);
      if (clientsRes.success) setClients(clientsRes.clients);
    } catch (err) {
      console.error('Reseller dashboard error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  if (loading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <RefreshCw className="w-6 h-6 text-amber-400 animate-spin" />
      </div>
    );
  }

  const stats = overview || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400" />
            Reseller Control Panel
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage your client accounts, deploy VMs, and monitor resource allocation across your portfolio.
          </p>
        </div>

        <Link
          to="/reseller/clients"
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-amber-500/25 transition-all"
        >
          <UserPlus className="w-4 h-4" />
          <span>Create New Client</span>
        </Link>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Clients"
          value={stats.totalClients || 0}
          subtitle="Active client accounts"
          icon={Users}
          color="amber"
        />
        <StatCard
          title="Total Servers"
          value={stats.totalServers || 0}
          subtitle="VMs across all clients"
          icon={Server}
          color="brand"
        />
        <StatCard
          title="Running VMs"
          value={stats.runningServers || 0}
          subtitle="Currently active"
          icon={CheckCircle2}
          color="emerald"
        />
        <StatCard
          title="Stopped VMs"
          value={stats.stoppedServers || 0}
          subtitle="Currently offline"
          icon={XCircle}
          color="rose"
        />
      </div>

      {/* Reseller Resource Allocation */}
      <GlassCard className="p-6 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Shield className="w-4 h-4 text-amber-400" />
          Your Reseller Resource Allocation
        </h3>
        <p className="text-xs text-slate-400">
          Resources assigned to you by the administrator. Distribute these across your client accounts.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-center">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-sans block">Max Servers</span>
            <span className="text-lg font-extrabold text-white font-mono">{stats.reseller?.max_servers || 10}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-center">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-sans block">RAM Limit</span>
            <span className="text-lg font-extrabold text-purple-300 font-mono">{stats.reseller?.ram_limit || '8G'}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-center">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-sans block">CPU Cores</span>
            <span className="text-lg font-extrabold text-cyan-300 font-mono">{stats.reseller?.cpu_limit || 4}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-center">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-sans block">Disk Storage</span>
            <span className="text-lg font-extrabold text-emerald-300 font-mono">{stats.reseller?.disk_limit || '80G'}</span>
          </div>
        </div>
      </GlassCard>

      {/* Quick Actions + Recent Clients */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <GlassCard className="p-6 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Activity className="w-4 h-4 text-brand-400" />
            Quick Actions
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Link to="/reseller/clients" className="group">
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 hover:border-amber-500/50 flex items-center gap-3 transition-all">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-amber-300">Client Accounts</h4>
                  <p className="text-[10px] text-slate-400">Manage & create</p>
                </div>
              </div>
            </Link>

            <Link to="/reseller/servers" className="group">
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 hover:border-brand-500/50 flex items-center gap-3 transition-all">
                <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 text-brand-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-brand-300">Client Servers</h4>
                  <p className="text-[10px] text-slate-400">View all VMs</p>
                </div>
              </div>
            </Link>
          </div>
        </GlassCard>

        {/* Recent Clients */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              Recent Clients
            </h3>
            <Link to="/reseller/clients" className="text-[11px] text-brand-400 hover:text-brand-300 font-medium flex items-center gap-1">
              View All <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {clients.length === 0 ? (
            <div className="p-6 text-center text-slate-400 space-y-2">
              <Users className="w-8 h-8 mx-auto opacity-40" />
              <p className="text-xs font-bold text-white">No clients yet</p>
              <p className="text-[11px]">Create your first client account to start managing their VMs.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-52 overflow-y-auto">
              {clients.slice(0, 5).map((client) => (
                <div
                  key={client.client_user_id}
                  className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5 hover:border-white/15 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                      {(client.username || '?')[0].toUpperCase()}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">{client.username}</span>
                      <span className="text-[10px] text-slate-500 font-mono">{client.email}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-400">{client.server_count || 0} VMs</span>
                    <span className={`w-2 h-2 rounded-full ${client.status === 'active' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
}

