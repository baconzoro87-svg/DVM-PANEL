import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Server, Lock, User, KeyRound, AlertCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import BackgroundPlayer from '../../components/BackgroundPlayer';
import MusicWidget from '../../components/MusicWidget';
import GlassCard from '../../components/GlassCard';

export default function Login() {
  const { login, verify2FALogin } = useAuth();
  const { settings, effectiveLogo } = useTheme();
  const navigate = useNavigate();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [pendingUserId, setPendingUserId] = useState(null);
  const [require2FA, setRequire2FA] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (require2FA) {
        await verify2FALogin(pendingUserId, twoFactorCode);
        navigate('/');
      } else {
        const result = await login(identifier, password);
        if (result.require2FA) {
          setRequire2FA(true);
          setPendingUserId(result.userId);
        } else {
          navigate('/');
        }
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <BackgroundPlayer />
      <MusicWidget />

      <div className="w-full max-w-md animate-fade-in">
        {/* Logo / Branding Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center mb-3">
            {effectiveLogo ? (
              <img src={effectiveLogo} alt="Logo" className="w-16 h-16 object-contain rounded-2xl shadow-xl border border-white/10" />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-400 flex items-center justify-center text-white shadow-xl shadow-brand-500/25 border border-white/10">
                <Server className="w-8 h-8" />
              </div>
            )}
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">{settings.panel_name || 'DVM Panel'}</h1>
          <p className="text-xs text-slate-400 mt-1">Docker Virtual Machine Management Web Panel</p>
          <p className="text-[10px] text-rose-300/70 mt-2 tracking-widest uppercase">BusterNodes · Made by Azmal</p>
        </div>

        <GlassCard className="p-8 shadow-2xl border-white/15">
          <h2 className="text-lg font-semibold text-white mb-1">
            {require2FA ? 'Two-Factor Authentication' : 'Sign In to your account'}
          </h2>
          <p className="text-xs text-slate-400 mb-6">
            {require2FA ? 'Enter the 6-digit code from your Authenticator app' : 'Enter your credentials to manage your servers'}
          </p>

          {error && (
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs mb-5 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!require2FA ? (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Username or Email</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="admin or user@example.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-medium text-slate-300">Password</label>
                    <Link to="/forgot-password" className="text-[11px] text-brand-400 hover:text-brand-300 transition-colors">
                      Forgot?
                    </Link>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                    />
                  </div>
                </div>
              </>
            ) : (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">6-Digit 2FA Code</label>
                <div className="relative">
                  <ShieldCheck className="w-4 h-4 text-brand-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    maxLength="6"
                    autoFocus
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="123456"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-center tracking-widest text-lg font-mono placeholder-slate-600 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-[0.98] text-white text-xs font-semibold shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2 disabled:opacity-50 transition-all"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>{require2FA ? 'Verify Code' : 'Sign In'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {settings.register_enabled === 'true' && !require2FA && (
            <p className="text-center text-xs text-slate-400 mt-6">
              Don't have an account?{' '}
              <Link to="/register" className="text-brand-400 hover:text-brand-300 font-medium transition-colors">
                Sign Up
              </Link>
            </p>
          )}

          {require2FA && (
            <button
              onClick={() => {
                setRequire2FA(false);
                setTwoFactorCode('');
              }}
              className="w-full text-center text-xs text-slate-400 hover:text-slate-200 mt-4 transition-colors"
            >
              Back to login
            </button>
          )}
        </GlassCard>
      </div>
    </div>
  );
}

