import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  Plus,
  Send,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  Shield,
  User,
  ArrowLeft
} from 'lucide-react';
import { api } from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import GlassCard from '../../components/GlassCard';
import Modal from '../../components/Modal';

export default function Tickets() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketMessages, setTicketMessages] = useState([]);
  const [messageText, setMessageText] = useState('');
  const [sending, setSending] = useState(false);

  // New ticket modal
  const [modalOpen, setModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [initialMessage, setInitialMessage] = useState('');
  const [priority, setPriority] = useState('medium');

  const fetchTickets = async () => {
    try {
      const res = await api.get('/tickets');
      if (res.success) {
        setTickets(res.tickets || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const openTicketDetails = async (ticket) => {
    setSelectedTicket(ticket);
    try {
      const res = await api.get(`/tickets/${ticket.id}`);
      if (res.success) {
        setTicketMessages(res.messages || []);
      }
    } catch (err) {
      alert(err.message);
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!messageText.trim() || !selectedTicket) return;
    setSending(true);
    try {
      const res = await api.post(`/tickets/${selectedTicket.id}/messages`, {
        message: messageText.trim()
      });
      if (res.success) {
        setTicketMessages(prev => [...prev, res.message]);
        setMessageText('');
        fetchTickets();
      }
    } catch (err) {
      alert(err.message);
    } finally {
      setSending(false);
    }
  };

  const handleCreateTicket = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/tickets', {
        title,
        message: initialMessage,
        priority
      });
      if (res.success) {
        setModalOpen(false);
        setTitle('');
        setInitialMessage('');
        fetchTickets();
        openTicketDetails(res.ticket);
      }
    } catch (err) {
      alert(`Error creating ticket: ${err.message}`);
    }
  };

  const handleStatusChange = async (newStatus) => {
    if (!selectedTicket) return;
    try {
      const res = await api.put(`/tickets/${selectedTicket.id}/status`, { status: newStatus });
      if (res.success) {
        setSelectedTicket(res.ticket);
        fetchTickets();
      }
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <LifeBuoy className="w-6 h-6 text-emerald-400" />
            Support Ticket Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Open inquiries, report technical issues, or request assistance from administrators.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Open New Ticket</span>
        </button>
      </div>

      {selectedTicket ? (
        /* Conversation Thread View */
        <GlassCard className="p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
            <div>
              <button
                onClick={() => setSelectedTicket(null)}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 mb-1"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Tickets
              </button>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>#{selectedTicket.id} - {selectedTicket.title}</span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                  selectedTicket.status === 'open' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-500/20 text-slate-400'
                }`}>
                  {selectedTicket.status}
                </span>
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedTicket.status}
                onChange={(e) => handleStatusChange(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-semibold focus:outline-none focus:border-brand-500"
              >
                <option value="open" className="bg-dark-900">Open</option>
                <option value="in_progress" className="bg-dark-900">In Progress</option>
                <option value="resolved" className="bg-dark-900">Resolved</option>
                <option value="closed" className="bg-dark-900">Closed</option>
              </select>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="space-y-3.5 max-h-[500px] overflow-y-auto p-2">
            {ticketMessages.map((msg) => {
              const isMe = msg.user_id === user?.id;
              const isAdminMsg = msg.role === 'admin';

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 max-w-2xl ${isMe ? 'ml-auto flex-row-reverse' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    isAdminMsg ? 'bg-brand-500/20 text-brand-300 border border-brand-500/30' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  }`}>
                    {isAdminMsg ? <Shield className="w-4 h-4" /> : msg.username?.charAt(0).toUpperCase()}
                  </div>

                  <div className={`p-3.5 rounded-2xl text-xs space-y-1 ${
                    isMe
                      ? 'bg-brand-600 text-white rounded-tr-none'
                      : 'bg-black/60 border border-white/10 text-slate-200 rounded-tl-none'
                  }`}>
                    <div className="flex items-center justify-between gap-4 text-[10px] opacity-75 mb-1 font-mono">
                      <span className="font-bold font-sans">{msg.username} {isAdminMsg && '(Staff)'}</span>
                      <span>{new Date(msg.created_at).toLocaleTimeString()}</span>
                    </div>
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.message}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Reply Form */}
          <form onSubmit={handleSendMessage} className="flex gap-2 pt-3 border-t border-white/10">
            <input
              type="text"
              required
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Type your reply message..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            />
            <button
              type="submit"
              disabled={sending}
              className="px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold flex items-center gap-1.5 disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </GlassCard>
      ) : (
        /* Tickets List */
        <GlassCard className="p-0 overflow-hidden">
          {loading ? (
            <div className="py-16 text-center text-slate-400 text-xs">Loading tickets...</div>
          ) : tickets.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              No support tickets found. Click "Open New Ticket" if you need help.
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {tickets.map((t) => (
                <div
                  key={t.id}
                  onClick={() => openTicketDetails(t)}
                  className="p-4 flex items-center justify-between hover:bg-white/5 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-brand-300 font-mono font-bold">#{t.id}</span>
                        <h3 className="text-sm font-bold text-white hover:text-brand-300">{t.title}</h3>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                        <span>Status: <strong className="text-slate-200 capitalize">{t.status}</strong></span>
                        <span>•</span>
                        <span>Priority: <strong className="text-slate-200 capitalize">{t.priority}</strong></span>
                        <span>•</span>
                        <span>{t.message_count || 1} messages</span>
                      </div>
                    </div>
                  </div>

                  <span className="text-slate-400 text-[11px] font-mono">
                    {new Date(t.updated_at || t.created_at).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      )}

      {/* Open Ticket Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Open Support Ticket"
      >
        <form onSubmit={handleCreateTicket} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Subject / Title</label>
            <input
              type="text"
              required
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Issue with SSH connection port"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Priority</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            >
              <option value="low" className="bg-dark-900">Low</option>
              <option value="medium" className="bg-dark-900">Medium</option>
              <option value="high" className="bg-dark-900">High</option>
              <option value="urgent" className="bg-dark-900">Urgent</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Initial Message / Problem Description</label>
            <textarea
              required
              rows="4"
              value={initialMessage}
              onChange={(e) => setInitialMessage(e.target.value)}
              placeholder="Describe your issue with details..."
              className="w-full p-3 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500 resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold"
            >
              Submit Ticket
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

