import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Activity,
  Cpu,
  Layers,
  HardDrive,
  Wifi,
  ArrowDown,
  ArrowUp,
  Clock,
  Zap,
  RefreshCw,
  BarChart2,
  TrendingUp,
  Server,
  ShieldCheck
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';

export default function ServerAnalytics() {
  const { server } = useOutletContext();

  const [analytics, setAnalytics] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('60s');

  const fetchAnalytics = async () => {
    try {
      const res = await api.get(`/servers/${server.id}/analytics`);
      if (res.success) {
        setAnalytics(res);
        setHistory(res.history || []);
      }
    } catch (err) {
      console.error('Failed to fetch analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 2000);
    return () => clearInterval(interval);
  }, [server.id]);

  const current = analytics?.current || {};
  const network = analytics?.network || {};
  const isRunning = analytics?.status === 'running' || server.status === 'running';

  // Format uptime string
  const formatUptime = (seconds) => {
    if (!seconds || seconds <= 0) return 'Stopped';
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  };

  // Helper to render smooth SVG Sparkline chart
  const renderSparkline = (data, dataKey, colorClass, strokeColor, maxVal = 100, unit = '%') => {
    if (!data || data.length < 2) {
      return (
        <div className="h-32 flex items-center justify-center text-xs text-slate-500 font-mono">
          Collecting telemetry data points...
        </div>
      );
    }

    const width = 500;
    const height = 120;
    const padding = 10;

    const values = data.map((d) => d[dataKey] || 0);
    const effectiveMax = Math.max(maxVal, ...values, 1);

    const points = values.map((val, idx) => {
      const x = padding + (idx / (values.length - 1)) * (width - 2 * padding);
      const y = height - padding - (val / effectiveMax) * (height - 2 * padding);
      return `${x},${y}`;
    });

    const pathD = `M ${points.join(' L ')}`;
    const areaD = `M ${points.join(' L ')} L ${width - padding},${height} L ${padding},${height} Z`;

    const latestVal = values[values.length - 1];

    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-mono text-slate-400">Current: <strong className="text-white">{latestVal} {unit}</strong></span>
          <span className="font-mono text-slate-500 text-[10px]">Peak: {Math.max(...values)} {unit}</span>
        </div>

        <div className="relative w-full h-32 rounded-xl bg-black/40 border border-white/5 overflow-hidden p-2">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible" preserveAspectRatio="none">
            <defs>
              <linearGradient id={`grad-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={strokeColor} stopOpacity="0.35" />
                <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Grid horizontal lines */}
            <line x1="0" y1={height * 0.25} x2={width} y2={height * 0.25} stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />
            <line x1="0" y1={height * 0.5} x2={width} y2={height * 0.5} stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />
            <line x1="0" y1={height * 0.75} x2={width} y2={height * 0.75} stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3" />

            {/* Area Fill */}
            <path d={areaD} fill={`url(#grad-${dataKey})`} />

            {/* Line Stroke */}
            <path
              d={pathD}
              fill="none"
              stroke={strokeColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Activity className="w-5 h-5 text-brand-400" />
            Live VM Performance & Analytics
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time telemetry, resource metrics, bandwidth streaming, and guest process activity.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 flex items-center gap-2 text-xs font-mono">
            <span className={`w-2 h-2 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
            <span className="text-slate-300 capitalize">{analytics?.status || server.status}</span>
          </div>

          <button
            onClick={fetchAnalytics}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Refresh Snapshot"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* KPI Top Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CPU */}
        <GlassCard className="p-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">CPU Usage</span>
            <div className="w-7 h-7 rounded-lg bg-brand-500/20 text-brand-400 flex items-center justify-center">
              <Cpu className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white font-mono">{current.cpu_percent || 0}%</span>
            <span className="text-[10px] text-slate-400 font-mono">/ {server.cpu_limit || 1} Cores</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-1.5 mt-3 overflow-hidden">
            <div
              className="bg-brand-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.min(current.cpu_percent || 0, 100)}%` }}
            />
          </div>
        </GlassCard>

        {/* RAM */}
        <GlassCard className="p-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Memory Usage</span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white font-mono">{current.memory?.used_str || '0 B'}</span>
            <span className="text-[10px] text-slate-400 font-mono">/ {current.memory?.limit_str || server.memory_limit}</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-1.5 mt-3 overflow-hidden">
            <div
              className="bg-purple-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${Math.min(current.memory?.percent || 0, 100)}%` }}
            />
          </div>
        </GlassCard>

        {/* Network Bandwidth Speed */}
        <GlassCard className="p-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Network RX / TX</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Wifi className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-center gap-3">
            <div className="flex items-center gap-1 font-mono text-xs text-emerald-400 font-bold">
              <ArrowDown className="w-3.5 h-3.5" />
              <span>{network.rxSpeed || '0 B/s'}</span>
            </div>
            <div className="flex items-center gap-1 font-mono text-xs text-cyan-400 font-bold">
              <ArrowUp className="w-3.5 h-3.5" />
              <span>{network.txSpeed || '0 B/s'}</span>
            </div>
          </div>
          <p className="text-[10px] text-slate-500 font-mono mt-2 truncate">
            Total: {network.totalTransfer || '0 B'}
          </p>
        </GlassCard>

        {/* Uptime & Processes */}
        <GlassCard className="p-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-sans">Uptime & PIDs</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-base font-extrabold text-emerald-400 font-mono block">
              {formatUptime(current.uptime_seconds)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Active Processes: <strong className="text-white">{current.pids || 0} PIDs</strong>
            </span>
          </div>
        </GlassCard>
      </div>

      {/* Real-time Time Series Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* CPU Chart */}
        <GlassCard className="p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-brand-400" /> Real-Time CPU Load
            </h3>
            <span className="text-[10px] font-mono text-slate-500">History: Last 60s (2s interval)</span>
          </div>
          {renderSparkline(history, 'cpu', 'text-brand-400', '#6366f1', 100, '%')}
        </GlassCard>

        {/* Memory Chart */}
        <GlassCard className="p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" /> Memory Utilization
            </h3>
            <span className="text-[10px] font-mono text-slate-500">History: Last 60s</span>
          </div>
          {renderSparkline(history, 'memoryPercent', 'text-purple-400', '#a855f7', 100, '%')}
        </GlassCard>

        {/* Network RX Speed Chart */}
        <GlassCard className="p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ArrowDown className="w-4 h-4 text-emerald-400" /> Inbound Download Speed (RX)
            </h3>
            <span className="text-[10px] font-mono text-slate-500">KB/s Rate</span>
          </div>
          {renderSparkline(history, 'rxSpeedKb', 'text-emerald-400', '#10b981', 50, 'KB/s')}
        </GlassCard>

        {/* Network TX Speed Chart */}
        <GlassCard className="p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ArrowUp className="w-4 h-4 text-cyan-400" /> Outbound Upload Speed (TX)
            </h3>
            <span className="text-[10px] font-mono text-slate-500">KB/s Rate</span>
          </div>
          {renderSparkline(history, 'txSpeedKb', 'text-cyan-400', '#06b6d4', 50, 'KB/s')}
        </GlassCard>
      </div>

      {/* Disk I/O and System Details */}
      <GlassCard className="p-5 space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-amber-400" /> Disk I/O & Container Runtime Stats
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-500 block">Disk Read Operations</span>
            <span className="text-white font-bold text-sm">{current.disk_io?.read_str || '0 B'}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-500 block">Disk Write Operations</span>
            <span className="text-white font-bold text-sm">{current.disk_io?.write_str || '0 B'}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-500 block">Network Inbound (Total RX)</span>
            <span className="text-emerald-400 font-bold text-sm">{network.totalRx || '0 B'}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10">
            <span className="text-[10px] text-slate-500 block">Network Outbound (Total TX)</span>
            <span className="text-cyan-400 font-bold text-sm">{network.totalTx || '0 B'}</span>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}

