import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Sliders,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertCircle,
  Code2,
  Terminal
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';

export default function ServerStartup() {
  const { server, fetchServerDetails } = useOutletContext();

  const [startupCmd, setStartupCmd] = useState(server.startup_cmd || '');
  const [envPairs, setEnvPairs] = useState(() => {
    try {
      const parsed = JSON.parse(server.env_vars || '{}');
      return Object.entries(parsed).map(([key, value]) => ({ key, value }));
    } catch {
      return [];
    }
  });

  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const addEnvPair = () => {
    setEnvPairs([...envPairs, { key: '', value: '' }]);
  };

  const removeEnvPair = (index) => {
    setEnvPairs(envPairs.filter((_, i) => i !== index));
  };

  const updateEnvPair = (index, field, val) => {
    const updated = [...envPairs];
    updated[index][field] = val;
    setEnvPairs(updated);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    const envObj = {};
    for (const pair of envPairs) {
      if (pair.key.trim()) {
        envObj[pair.key.trim()] = pair.value;
      }
    }

    try {
      const res = await api.put(`/servers/${server.id}`, {
        startup_cmd: startupCmd,
        env_vars: envObj
      });

      if (res.success) {
        setSuccess('Startup configuration saved successfully!');
        fetchServerDetails();
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-400" />
            Startup & Environment Configuration
          </h2>
          <p className="text-xs text-slate-400">
            Define container environment variables and custom startup entrypoints.
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-brand-500/25 disabled:opacity-50 transition-all"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save Configuration'}</span>
        </button>
      </div>

      {success && (
        <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Startup Command */}
      <GlassCard className="p-6">
        <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-brand-400" />
          Custom Startup Command Override
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Optionally specify a custom command to execute on container initialization. Leave empty to use default.
        </p>

        <div className="relative">
          <input
            type="text"
            value={startupCmd}
            onChange={(e) => setStartupCmd(e.target.value)}
            placeholder="e.g. bash -c '/root/start.sh' (Optional)"
            className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono placeholder-slate-500 focus:outline-none focus:border-brand-500"
          />
        </div>
      </GlassCard>

      {/* Environment Variables */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Code2 className="w-4 h-4 text-purple-400" />
              Container Environment Variables
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Variables passed to the container at launch (<code>$VM_NAME</code>, <code>$HOSTNAME</code>, <code>$RAM</code>, <code>$CPUS</code>, etc.)
            </p>
          </div>

          <button
            type="button"
            onClick={addEnvPair}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Variable</span>
          </button>
        </div>

        {envPairs.length === 0 ? (
          <div className="py-8 text-center text-slate-500 text-xs">
            No custom environment variables defined. Click "Add Variable" to create one.
          </div>
        ) : (
          <div className="space-y-2.5">
            {envPairs.map((pair, index) => (
              <div key={index} className="flex items-center gap-3">
                <input
                  type="text"
                  value={pair.key}
                  onChange={(e) => updateEnvPair(index, 'key', e.target.value)}
                  placeholder="KEY (e.g. APP_PORT)"
                  className="w-1/3 px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono uppercase placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
                <input
                  type="text"
                  value={pair.value}
                  onChange={(e) => updateEnvPair(index, 'value', e.target.value)}
                  placeholder="VALUE (e.g. 8080 or true)"
                  className="flex-1 px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
                <button
                  type="button"
                  onClick={() => removeEnvPair(index)}
                  className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </form>
  );
}

