import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Archive,
  Plus,
  Download,
  RotateCcw,
  Trash2,
  AlertCircle,
  CheckCircle2,
  Clock,
  HardDrive
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';

export default function ServerBackups() {
  const { server } = useOutletContext();
  const [backups, setBackups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [backupName, setBackupName] = useState('');
  const [creating, setCreating] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [actionMessage, setActionMessage] = useState('');
  const [error, setError] = useState('');

  const fetchBackups = async () => {
    try {
      const res = await api.get(`/servers/${server.id}/backups`);
      if (res.success) {
        setBackups(res.backups || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, [server.id]);

  const handleCreateBackup = async (e) => {
    e.preventDefault();
    setCreating(true);
    setError('');
    setActionMessage('Creating full container snapshot backup... This may take a moment.');

    try {
      const res = await api.post(`/servers/${server.id}/backups`, { name: backupName });
      if (res.success) {
        setCreateModalOpen(false);
        setBackupName('');
        setActionMessage('Backup snapshot created successfully!');
        fetchBackups();
        setTimeout(() => setActionMessage(''), 3000);
      }
    } catch (err) {
      setError(err.message);
      setActionMessage('');
    } finally {
      setCreating(false);
    }
  };

  const handleRestore = async (backupId, name) => {
    if (!confirm(`Warning: Restoring backup "${name}" will overwrite the current VM container filesystem state. Proceed?`)) return;
    setRestoring(true);
    setActionMessage(`Restoring VM from backup "${name}"...`);

    try {
      const res = await api.post(`/servers/${server.id}/backups/${backupId}/restore`, {});
      if (res.success) {
        setActionMessage('VM restored successfully!');
        setTimeout(() => setActionMessage(''), 3000);
      }
    } catch (err) {
      alert(`Restore failed: ${err.message}`);
      setActionMessage('');
    } finally {
      setRestoring(false);
    }
  };

  const handleDelete = async (backupId) => {
    if (!confirm('Are you sure you want to delete this backup file?')) return;
    try {
      await api.delete(`/servers/${server.id}/backups/${backupId}`);
      fetchBackups();
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleDownload = (backupId) => {
    const token = localStorage.getItem('dpanel_token');
    window.open(`/api/servers/${server.id}/backups/${backupId}/download?token=${token}`, '_blank');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Archive className="w-5 h-5 text-purple-400" />
            VM Snapshot Backups
          </h2>
          <p className="text-xs text-slate-400">
            Create complete filesystem archives to restore or export your virtual machine state at any time.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          disabled={creating || restoring}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 disabled:opacity-50 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Create Snapshot</span>
        </button>
      </div>

      {actionMessage && (
        <div className="p-3.5 rounded-xl bg-brand-500/20 border border-brand-500/40 text-brand-300 text-xs flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div className="py-16 text-center text-slate-400 text-xs">Loading backups...</div>
      ) : backups.length === 0 ? (
        <GlassCard className="py-12 text-center">
          <Archive className="w-10 h-10 text-slate-500 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-white mb-1">No backups created yet</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            Take snapshot backups before major upgrades or software changes so you can revert anytime.
          </p>
          <button
            onClick={() => setCreateModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
          >
            Create First Backup
          </button>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {backups.map((b) => (
            <GlassCard key={b.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 text-purple-400 flex items-center justify-center shrink-0">
                  <HardDrive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{b.name}</h4>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                    <span>Size: <strong className="text-slate-200">{(b.size_bytes / (1024 * 1024)).toFixed(2)} MB</strong></span>
                    <span>•</span>
                    <span className="flex items-center gap-1 font-sans">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {new Date(b.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  onClick={() => handleDownload(b.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10 transition-colors"
                  title="Download .tar.gz backup archive"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download</span>
                </button>

                <button
                  disabled={restoring}
                  onClick={() => handleRestore(b.id, b.name)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-amber-500/20 text-amber-300 text-xs font-semibold border border-white/10 transition-colors"
                  title="Restore VM to this state"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore</span>
                </button>

                <button
                  onClick={() => handleDelete(b.id)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                  title="Delete backup file"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {/* Create Backup Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => !creating && setCreateModalOpen(false)}
        title="Create VM Snapshot Backup"
      >
        <form onSubmit={handleCreateBackup} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Backup Name / Label</label>
            <input
              type="text"
              required
              autoFocus
              value={backupName}
              onChange={(e) => setBackupName(e.target.value)}
              placeholder="e.g. Pre-installation Backup"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500"
            />
          </div>

          <p className="text-[11px] text-slate-400">
            A compressed <code>.tar.gz</code> archive of the root container filesystem will be created in the backups storage.
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              disabled={creating}
              onClick={() => setCreateModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={creating}
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold disabled:opacity-50"
            >
              {creating ? 'Creating Snapshot...' : 'Start Backup'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

