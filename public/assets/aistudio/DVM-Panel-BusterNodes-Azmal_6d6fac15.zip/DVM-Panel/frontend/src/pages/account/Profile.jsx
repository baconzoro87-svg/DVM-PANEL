import React, { useState, useEffect } from 'react';
import {
  User,
  Shield,
  Key,
  QrCode,
  Lock,
  Clock,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Save,
  ShieldAlert,
  ShieldCheck
} from 'lucide-react';
import { api } from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import GlassCard from '../../components/GlassCard';
import Modal from '../../components/Modal';

export default function Profile() {
  const { user, refreshUser } = useAuth();

  const [username, setUsername] = useState(user?.username || '');
  const [email, setEmail] = useState(user?.email || '');

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // 2FA states
  const [twoFactorModalOpen, setTwoFactorModalOpen] = useState(false);
  const [disable2FAModalOpen, setDisable2FAModalOpen] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [twoFactorSecret, setTwoFactorSecret] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [disablePassword, setDisablePassword] = useState('');

  const [activityData, setActivityData] = useState({ loginHistory: [], activities: [] });

  const [profileSaving, setProfileSaving] = useState(false);
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (user) {
      setUsername(user.username);
      setEmail(user.email);
    }
    api.get('/users/activity').then(res => {
      if (res.success) {
        setActivityData({ loginHistory: res.loginHistory || [], activities: res.activities || [] });
      }
    });
  }, [user]);

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setProfileSaving(true);
    setError('');
    setProfileSuccess('');
    try {
      const res = await api.put('/users/profile', { username, email });
      if (res.success) {
        setProfileSuccess('Profile details updated.');
        refreshUser();
        setTimeout(() => setProfileSuccess(''), 3000);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setProfileSaving(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      return setError('New passwords do not match.');
    }
    setPasswordSaving(true);
    setError('');
    setPasswordSuccess('');
    try {
      const res = await api.put('/users/password', { currentPassword, newPassword });
      if (res.success) {
        setPasswordSuccess('Password changed successfully.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => setPasswordSuccess(''), 3000);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setPasswordSaving(false);
    }
  };

  const handleStart2FA = async () => {
    try {
      const res = await api.post('/users/2fa/setup', {});
      if (res.success) {
        setQrCodeUrl(res.qrCodeUrl);
        setTwoFactorSecret(res.secret);
        setVerifyCode('');
        setTwoFactorModalOpen(true);
      }
    } catch (err) {
      alert(`2FA setup error: ${err.message}`);
    }
  };

  const handleConfirm2FA = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/users/2fa/enable', { code: verifyCode });
      if (res.success) {
        setTwoFactorModalOpen(false);
        refreshUser();
        alert('Two-Factor Authentication enabled successfully!');
      }
    } catch (err) {
      alert(`Verification failed: ${err.message}`);
    }
  };

  const handleDisable2FA = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/users/2fa/disable', { password: disablePassword });
      if (res.success) {
        setDisable2FAModalOpen(false);
        setDisablePassword('');
        refreshUser();
        alert('Two-Factor Authentication disabled.');
      }
    } catch (err) {
      alert(`Failed to disable: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <User className="w-6 h-6 text-brand-400" />
          Account Profile & Security
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Manage your personal details, credentials, and Two-Factor Authentication.
        </p>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Account Info & 2FA Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Details Form */}
        <GlassCard className="p-6">
          <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-brand-400" />
            Personal Details
          </h2>

          {profileSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{profileSuccess}</span>
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Username</label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <button
              type="submit"
              disabled={profileSaving}
              className="px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-500/25 disabled:opacity-50"
            >
              {profileSaving ? 'Saving...' : 'Save Profile'}
            </button>
          </form>
        </GlassCard>

        {/* 2FA Card */}
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Two-Factor Authentication (2FA)
          </h2>
          <p className="text-xs text-slate-400">
            Add an extra layer of security to your account using Time-based One-Time Passwords (TOTP) from Google Authenticator, Authy, or 1Password.
          </p>

          <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${user?.two_factor_enabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-500/20 text-slate-400'}`}>
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">
                  Status: {user?.two_factor_enabled ? 'Enabled' : 'Disabled'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {user?.two_factor_enabled ? 'Your account is protected by 2FA.' : '2FA is currently not active.'}
                </p>
              </div>
            </div>

            {user?.two_factor_enabled ? (
              <button
                type="button"
                onClick={() => setDisable2FAModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold border border-rose-500/30"
              >
                Disable
              </button>
            ) : (
              <button
                type="button"
                onClick={handleStart2FA}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold shadow-md shadow-emerald-500/25"
              >
                Enable 2FA
              </button>
            )}
          </div>
        </GlassCard>
      </div>

      {/* Password Change */}
      <GlassCard className="p-6">
        <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-amber-400" />
          Change Account Password
        </h2>

        {passwordSuccess && (
          <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{passwordSuccess}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-4 max-w-lg">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Current Password</label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">New Password</label>
              <input
                type="password"
                required
                minLength="6"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="•••••••• (min 6 chars)"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Confirm New Password</label>
              <input
                type="password"
                required
                minLength="6"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={passwordSaving}
            className="px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold disabled:opacity-50"
          >
            {passwordSaving ? 'Updating...' : 'Update Password'}
          </button>
        </form>
      </GlassCard>

      {/* Login History */}
      <GlassCard className="p-6">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-teal-400" />
          Recent Account Login History
        </h3>
        <div className="divide-y divide-white/5 font-mono text-xs">
          {activityData.loginHistory.slice(0, 5).map((log) => (
            <div key={log.id} className="py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${log.status === 'success' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                <span className="text-white">IP: {log.ip_address || '127.0.0.1'}</span>
                <span className="text-slate-500 text-[10px]">({log.user_agent?.substring(0, 30)}...)</span>
              </div>
              <span className="text-slate-400 text-[11px] font-sans">
                {new Date(log.created_at).toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* 2FA Setup Modal */}
      <Modal
        isOpen={twoFactorModalOpen}
        onClose={() => setTwoFactorModalOpen(false)}
        title="Setup Two-Factor Authentication"
      >
        <form onSubmit={handleConfirm2FA} className="space-y-4 text-center">
          <p className="text-xs text-slate-300">
            Scan the QR code with your Authenticator app (Google Authenticator, Microsoft Authenticator, or Authy):
          </p>

          {qrCodeUrl && (
            <div className="p-3 bg-white rounded-2xl inline-block mx-auto shadow-xl">
              <img src={qrCodeUrl} alt="2FA QR Code" className="w-48 h-48" />
            </div>
          )}

          <div className="p-3 rounded-xl bg-black/50 border border-white/10 text-xs font-mono text-slate-300">
            <span className="text-[10px] text-slate-500 block uppercase">Manual Setup Key</span>
            <span className="text-brand-300 font-bold select-all">{twoFactorSecret}</span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 text-left">Enter 6-Digit Code from App</label>
            <input
              type="text"
              required
              maxLength="6"
              autoFocus
              value={verifyCode}
              onChange={(e) => setVerifyCode(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="123456"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-center text-lg font-mono tracking-widest focus:outline-none focus:border-brand-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setTwoFactorModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold"
            >
              Verify & Enable
            </button>
          </div>
        </form>
      </Modal>

      {/* Disable 2FA Modal */}
      <Modal
        isOpen={disable2FAModalOpen}
        onClose={() => setDisable2FAModalOpen(false)}
        title="Disable Two-Factor Authentication"
      >
        <form onSubmit={handleDisable2FA} className="space-y-4">
          <p className="text-xs text-slate-300">
            Enter your current account password to confirm disabling Two-Factor Authentication:
          </p>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Password</label>
            <input
              type="password"
              required
              autoFocus
              value={disablePassword}
              onChange={(e) => setDisablePassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setDisable2FAModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold"
            >
              Confirm Disable 2FA
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

