import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Server,
  Plus,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Users,
  Terminal,
  Cpu,
  Layers,
  HardDrive,
  Key,
  Code,
  X,
  RotateCw,
  Sparkles,
  Check,
  Clock
} from 'lucide-react';
import { api } from '../../utils/api';
import { useTheme } from '../../context/ThemeContext';
import GlassCard from '../../components/GlassCard';
import CustomResourcePicker from '../../components/CustomResourcePicker';
import AutoSuspendPicker from '../../components/AutoSuspendPicker';

export default function AdminCreateServer() {
  const navigate = useNavigate();
  const { supportedImages } = useTheme();

  const [users, setUsers] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [name, setName] = useState('');
  const [hostname, setHostname] = useState('');
  const [image, setImage] = useState('nobitaa/ubuntu:22');
  const [customImage, setCustomImage] = useState('');
  const [port, setPort] = useState('');
  const [portInfo, setPortInfo] = useState(null);
  const [portChecking, setPortChecking] = useState(false);
  const [portAvailable, setPortAvailable] = useState(true);

  // Hardware resources
  const [ram, setRam] = useState('1G');
  const [cpus, setCpus] = useState('1');
  const [diskSize, setDiskSize] = useState('10G');

  // Full Custom Auto-Suspend Engine
  const [autoSuspendType, setAutoSuspendType] = useState('hours');
  const [autoSuspendHours, setAutoSuspendHours] = useState('0');
  const [autoSuspendAt, setAutoSuspendAt] = useState('');
  const [autoSuspendTime, setAutoSuspendTime] = useState('23:00');

  // SSH Credentials
  const [sshUser, setSshUser] = useState('root');
  const [sshPassword, setSshPassword] = useState('root');

  // Custom Environment Variables
  const [customEnvList, setCustomEnvList] = useState([]);
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvVal, setNewEnvVal] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchNextPort = async () => {
    try {
      setPortChecking(true);
      const res = await api.get('/ports/next-free');
      if (res.success && res.nextPort) {
        setPort(String(res.nextPort));
        setPortInfo(res);
        setPortAvailable(true);
      }
    } catch (e) {
      console.error('Failed to fetch next port:', e);
    } finally {
      setPortChecking(false);
    }
  };

  const checkCustomPort = async (portVal) => {
    const num = parseInt(portVal, 10);
    if (!num || isNaN(num) || num < 25501 || num > 25599) {
      setPortAvailable(false);
      return;
    }
    try {
      const res = await api.get(`/ports/check?port=${num}`);
      if (res.success) {
        setPortAvailable(res.available);
      }
    } catch (e) {
      setPortAvailable(true);
    }
  };

  useEffect(() => {
    api.get('/admin/users').then((res) => {
      if (res.success && res.users) {
        setUsers(res.users);
        if (res.users.length > 0) setSelectedUserId(String(res.users[0].id));
      }
    });
    fetchNextPort();
  }, []);

  const effectiveImage = customImage.trim() || image;

  const addCustomEnv = () => {
    const k = newEnvKey.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    if (!k) return;
    if (['VM_NAME', 'HOSTNAME', 'RAM', 'CPUS', 'DISK_SIZE'].includes(k)) {
      alert(`"${k}" is already handled automatically as a launch variable.`);
      return;
    }
    if (customEnvList.some(item => item.key === k)) {
      alert(`Environment variable "${k}" already added.`);
      return;
    }
    setCustomEnvList([...customEnvList, { key: k, value: newEnvVal.trim() }]);
    setNewEnvKey('');
    setNewEnvVal('');
  };

  const removeCustomEnv = (indexToRemove) => {
    setCustomEnvList(customEnvList.filter((_, idx) => idx !== indexToRemove));
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) return setError('Server name is required.');
    if (!effectiveImage) return setError('Image is required.');
    if (portAvailable === false) {
      return setError(`Selected port ${port} is currently in use or invalid. Please click Auto-Scan.`);
    }

    setLoading(true);

    const customEnvObj = {};
    customEnvList.forEach(item => {
      if (item.key.trim()) {
        customEnvObj[item.key.trim()] = item.value;
      }
    });

    try {
      const res = await api.post('/admin/servers', {
        name: name.trim().toLowerCase(),
        hostname: hostname.trim() || name.trim(),
        image: effectiveImage,
        port_ssh: port ? parseInt(port, 10) : undefined,
        memory_limit: ram,
        cpu_limit: cpus,
        disk_limit: diskSize,
        user_id: selectedUserId ? parseInt(selectedUserId, 10) : undefined,
        env_vars: customEnvObj,
        ssh_user: sshUser.trim() || 'root',
        ssh_password: sshPassword.trim() || 'root',
        auto_suspend_type: autoSuspendType,
        auto_suspend_hours: parseInt(autoSuspendHours, 10) || 0,
        auto_suspend_at: autoSuspendType === 'datetime' ? autoSuspendAt : null,
        auto_suspend_time: autoSuspendType === 'daily_time' ? autoSuspendTime : ''
      });

      if (res.success && res.server) {
        navigate(`/servers/${res.server.id}/overview`);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <Plus className="w-6 h-6 text-brand-400" />
          Admin VM Deployment (Unrestricted)
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Deploy and provision a container VM with auto port allocation, custom environment variables, and SSH credentials.
        </p>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleCreate} className="space-y-6">
        {/* Assign User */}
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 text-brand-400" /> Server Owner / Assigned User
          </h2>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Select User Account</label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.username} ({u.email}) — Role: {u.role}
                </option>
              ))}
            </select>
          </div>
        </GlassCard>

        {/* Basic Configuration */}
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-brand-400" /> VM Identity & Image
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Server Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                placeholder="e.g. node-vm-01"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Hostname</label>
              <input
                type="text"
                value={hostname}
                onChange={(e) => setHostname(e.target.value)}
                placeholder="e.g. node-vm-01"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Docker Image</label>
              <select
                value={image}
                onChange={(e) => setImage(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              >
                {(supportedImages?.length ? supportedImages : [
                  { id: 'nobitaa/ubuntu:22', name: 'Ubuntu 22.04' },
                  { id: 'nobitaa/ubuntu:24', name: 'Ubuntu 24.04' },
                  { id: 'nobitaa/debain:11', name: 'Debian 11' },
                  { id: 'nobitaa/debain:12', name: 'Debian 12' },
                  { id: 'nobitaa/debain:13', name: 'Debian 13' }
                ]).map((img) => (
                  <option key={img.id} value={img.id}>
                    {img.id} ({img.name})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Or Custom Image Tag</label>
              <input
                type="text"
                value={customImage}
                onChange={(e) => setCustomImage(e.target.value)}
                placeholder="e.g. alpine:latest"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div className="sm:col-span-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-slate-300">
                  SSH Port (Auto-Allocated from Pool)
                </label>
                <button
                  type="button"
                  onClick={fetchNextPort}
                  className="text-[10px] text-brand-300 hover:text-brand-200 flex items-center gap-1 transition-colors"
                  title="Scan & allocate next free port"
                >
                  <RotateCw className={`w-3 h-3 ${portChecking ? 'animate-spin' : ''}`} />
                  <span>Auto-Scan</span>
                </button>
              </div>

              <div className="relative">
                <input
                  type="number"
                  value={port}
                  onChange={(e) => {
                    setPort(e.target.value);
                    checkCustomPort(e.target.value);
                  }}
                  placeholder="Auto (25501-25599)"
                  min="25501"
                  max="25599"
                  className="w-full px-4 py-2.5 pr-20 rounded-xl bg-black/40 border border-white/10 text-brand-300 font-mono text-xs font-bold focus:outline-none focus:border-brand-500"
                />
                <div className="absolute right-2.5 top-2.5">
                  {portAvailable === true ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      <Check className="w-3 h-3" /> Free
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                      <AlertCircle className="w-3 h-3" /> In Use
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                <span>Auto Allocation Pool: 25501 - 25599</span>
                {portInfo && (
                  <span className="text-emerald-400 font-mono">
                    {portInfo.freeCount} free ports available
                  </span>
                )}
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Custom Hardware Allocations */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-1 border-b border-white/10">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" /> Custom Hardware Allocations
            </h2>
            <span className="text-[11px] text-purple-300 font-mono">
              Presets, Sliders & Custom Units
            </span>
          </div>

          <CustomResourcePicker
            ram={ram}
            setRam={setRam}
            cpus={cpus}
            setCpus={setCpus}
            diskSize={diskSize}
            setDiskSize={setDiskSize}
          />
        </GlassCard>

        {/* SSH Credentials */}
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" /> SSH Authentication
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SSH User</label>
              <input
                type="text"
                required
                value={sshUser}
                onChange={(e) => setSshUser(e.target.value)}
                placeholder="root"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">SSH Password</label>
              <input
                type="text"
                required
                value={sshPassword}
                onChange={(e) => setSshPassword(e.target.value)}
                placeholder="root"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          </div>
        </GlassCard>

        {/* Container Environment Variables */}
        <GlassCard className="p-6 space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Code className="w-4 h-4 text-cyan-400" /> Container Environment Variables (-e)
          </h2>

          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 font-sans">
              Automatic Launch Variables:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono text-xs">
              <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$VM_NAME</span>
                <span className="text-emerald-300 font-bold truncate block">{name || 'vm1'}</span>
              </div>
              <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$HOSTNAME</span>
                <span className="text-emerald-300 font-bold truncate block">{hostname || name || 'vm1'}</span>
              </div>
              <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$RAM</span>
                <span className="text-purple-300 font-bold block">{ram}</span>
              </div>
              <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$CPUS</span>
                <span className="text-cyan-300 font-bold block">{cpus}</span>
              </div>
              <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                <span className="text-[10px] text-slate-500 block">$DISK_SIZE</span>
                <span className="text-emerald-300 font-bold block">{diskSize}</span>
              </div>
            </div>
          </div>

          {customEnvList.length > 0 && (
            <div className="space-y-2 pt-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block font-sans">
                Custom Environment Variables:
              </span>
              {customEnvList.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 font-mono text-xs">
                  <div className="w-1/3 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-cyan-300 font-bold truncate">
                    ${item.key}
                  </div>
                  <div className="flex-1 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono text-xs truncate">
                    {item.value}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeCustomEnv(idx)}
                    className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                    title="Remove"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center gap-2 p-3 rounded-2xl bg-black/30 border border-dashed border-white/15">
            <input
              type="text"
              value={newEnvKey}
              onChange={(e) => setNewEnvKey(e.target.value)}
              placeholder="KEY (e.g. APP_ENV)"
              className="w-full sm:w-1/3 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-cyan-300 font-mono text-xs uppercase focus:outline-none focus:border-cyan-500"
            />
            <input
              type="text"
              value={newEnvVal}
              onChange={(e) => setNewEnvVal(e.target.value)}
              placeholder="VALUE (e.g. production or 8080)"
              className="w-full sm:flex-1 px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
            />
            <button
              type="button"
              onClick={addCustomEnv}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-bold border border-cyan-500/30 flex items-center justify-center gap-1.5 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Variable</span>
            </button>
          </div>
        </GlassCard>

        {/* VM Auto-Suspend & Sleep Automation Policy */}
        <GlassCard className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10 mb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-400" />
                VM Auto-Suspend & Sleep Automation Policy
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Automatically stop and suspend this VM container by runtime timer, calendar date & time, or daily recurring schedule.
              </p>
            </div>
            <span className="text-[11px] text-amber-300 font-mono flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" /> Full Custom Auto-Sleep
            </span>
          </div>

          <AutoSuspendPicker
            suspendType={autoSuspendType}
            setSuspendType={setAutoSuspendType}
            suspendHours={autoSuspendHours}
            setSuspendHours={setAutoSuspendHours}
            suspendAt={autoSuspendAt}
            setSuspendAt={setAutoSuspendAt}
            suspendTime={autoSuspendTime}
            setSuspendTime={setAutoSuspendTime}
          />
        </GlassCard>

        {/* Submit */}
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate('/admin/servers')}
            className="px-5 py-2.5 rounded-xl glass-panel text-slate-400 hover:text-white text-xs font-medium"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading || portAvailable === false}
            className="px-6 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-bold shadow-lg shadow-brand-500/25 flex items-center gap-2 disabled:opacity-50"
          >
            {loading ? 'Creating Server...' : 'Provision Server (Admin)'}
          </button>
        </div>
      </form>
    </div>
  );
}
