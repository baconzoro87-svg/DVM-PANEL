import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Clock, Activity, User, Shield, RefreshCw } from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';

export default function ServerActivity() {
  const { server } = useOutletContext();
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchActivities = async () => {
    try {
      const res = await api.get(`/servers/${server.id}/activity`);
      if (res.success) {
        setActivities(res.activities || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActivities();
  }, [server.id]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-400" />
            Server Activity Audit Log
          </h2>
          <p className="text-xs text-slate-400">
            A chronological timeline of power actions, file modifications, backups, and administrative operations on this instance.
          </p>
        </div>

        <button
          onClick={fetchActivities}
          className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <GlassCard className="p-0 overflow-hidden">
        {loading ? (
          <div className="py-12 text-center text-slate-400 text-xs">Loading activity logs...</div>
        ) : activities.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            No activity recorded for this server yet.
          </div>
        ) : (
          <div className="divide-y divide-white/5 font-sans">
            {activities.map((act) => (
              <div key={act.id} className="p-4 flex items-center justify-between gap-4 hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 text-teal-400 flex items-center justify-center shrink-0">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white font-mono">{act.action}</span>
                      {act.username && (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-white/5 border border-white/10 text-slate-300">
                          {act.username}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">{act.details}</p>
                  </div>
                </div>

                <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                  {new Date(act.created_at).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
}

