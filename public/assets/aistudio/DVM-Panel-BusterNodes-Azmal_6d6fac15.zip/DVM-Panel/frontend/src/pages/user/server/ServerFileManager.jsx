import React, { useState, useEffect, useRef } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  FolderTree,
  Folder,
  File,
  FileCode,
  FileText,
  Upload,
  Plus,
  Trash2,
  Edit,
  Download,
  FolderPlus,
  RefreshCw,
  Search,
  ChevronRight,
  Home,
  AlertCircle,
  Key,
  ShieldCheck,
  HardDrive,
  FileCog
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';
import FileEditorModal from '../../../components/FileEditorModal';

function formatBytes(bytes, decimals = 2) {
  if (!+bytes) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function getFileIcon(name, isDirectory) {
  if (isDirectory) {
    return <Folder className="w-4 h-4 text-amber-400 fill-amber-400/20" />;
  }
  const ext = name.split('.').pop().toLowerCase();
  if (['js', 'ts', 'jsx', 'tsx', 'py', 'sh', 'php', 'rb', 'go', 'rs', 'c', 'cpp', 'html', 'css', 'json', 'yaml', 'yml', 'toml'].includes(ext)) {
    return <FileCode className="w-4 h-4 text-cyan-400" />;
  }
  if (['conf', 'cfg', 'ini', 'env', 'service'].includes(ext)) {
    return <FileCog className="w-4 h-4 text-emerald-400" />;
  }
  if (['txt', 'md', 'log'].includes(ext)) {
    return <FileText className="w-4 h-4 text-slate-300" />;
  }
  return <File className="w-4 h-4 text-slate-400" />;
}

export default function ServerFileManager() {
  const { server } = useOutletContext();
  const fileInputRef = useRef(null);

  const [currentPath, setCurrentPath] = useState('/root');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  // Modals
  const [editorOpen, setEditorOpen] = useState(false);
  const [selectedFileForEdit, setSelectedFileForEdit] = useState('');

  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const [newFileOpen, setNewFileOpen] = useState(false);
  const [newFileName, setNewFileName] = useState('');

  const [renameOpen, setRenameOpen] = useState(false);
  const [targetItemForRename, setTargetItemForRename] = useState(null);
  const [renameNewName, setRenameNewName] = useState('');

  const [uploading, setUploading] = useState(false);

  const fetchFiles = async (dir = currentPath) => {
    setLoading(true);
    setError('');
    try {
      const res = await api.get(`/servers/${server.id}/files?path=${encodeURIComponent(dir)}`);
      if (res.success) {
        setItems(res.items || []);
        setCurrentPath(res.currentPath || dir);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles('/root');
  }, [server.id]);

  const handleNavigate = (path) => {
    fetchFiles(path);
  };

  const handleCreateFolder = async (e) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    try {
      const parent = currentPath === '/' ? '' : currentPath;
      const fullPath = `${parent}/${newFolderName.trim()}`;
      await api.post(`/servers/${server.id}/files/folder`, { path: fullPath });
      setNewFolderOpen(false);
      setNewFolderName('');
      fetchFiles(currentPath);
    } catch (err) {
      alert(`Error creating folder: ${err.message}`);
    }
  };

  const handleCreateFile = async (e) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    try {
      const parent = currentPath === '/' ? '' : currentPath;
      const fullPath = `${parent}/${newFileName.trim()}`;
      await api.post(`/servers/${server.id}/files/save`, { path: fullPath, content: '' });
      setNewFileOpen(false);
      setNewFileName('');
      fetchFiles(currentPath);
      // Open editor directly
      setSelectedFileForEdit(fullPath);
      setEditorOpen(true);
    } catch (err) {
      alert(`Error creating file: ${err.message}`);
    }
  };

  const handleDelete = async (itemPath) => {
    if (!confirm(`Are you sure you want to permanently delete "${itemPath}" inside the VM?`)) return;
    try {
      await api.post(`/servers/${server.id}/files/delete`, { path: itemPath });
      fetchFiles(currentPath);
    } catch (err) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleRename = async (e) => {
    e.preventDefault();
    if (!targetItemForRename || !renameNewName.trim()) return;
    try {
      const parent = currentPath === '/' ? '' : currentPath;
      const newFullPath = `${parent}/${renameNewName.trim()}`;
      await api.post(`/servers/${server.id}/files/rename`, {
        oldPath: targetItemForRename.path,
        newPath: newFullPath
      });
      setRenameOpen(false);
      setTargetItemForRename(null);
      setRenameNewName('');
      fetchFiles(currentPath);
    } catch (err) {
      alert(`Rename failed: ${err.message}`);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('path', currentPath);

    setUploading(true);
    try {
      await api.post(`/servers/${server.id}/files/upload`, formData);
      fetchFiles(currentPath);
    } catch (err) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const downloadFile = (filePath) => {
    const token = localStorage.getItem('dpanel_token');
    window.open(`/api/servers/${server.id}/files/download?path=${encodeURIComponent(filePath)}&token=${token}`, '_blank');
  };

  // Breadcrumbs builder
  const pathParts = currentPath.split('/').filter(Boolean);
  const filteredItems = items.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));

  const quickShortcuts = [
    { label: '~ /root (Home)', path: '/root' },
    { label: '/ (Root)', path: '/' },
    { label: '/home', path: '/home' },
    { label: '/etc (Config)', path: '/etc' },
    { label: '/var/log', path: '/var/log' },
    { label: '/tmp', path: '/tmp' }
  ];

  return (
    <div className="space-y-4">
      {/* Header Info & Quick Folders */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1 border-b border-white/5">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-brand-400" />
            VM File Manager (Native SSH / SFTP)
          </h2>
          <p className="text-xs text-slate-400">
            Directly browse, edit, create, upload, and download files inside virtual machine <code>{server.name}</code>.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded-xl bg-black/40 border border-white/10 text-emerald-300 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            SFTP Port: <strong>{server.port_ssh || 25501}</strong>
          </span>
        </div>
      </div>

      {/* Quick Jump Directory Buttons */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 mr-1">
          Quick Jump:
        </span>
        {quickShortcuts.map((sc) => (
          <button
            key={sc.path}
            onClick={() => handleNavigate(sc.path)}
            className={`px-2.5 py-1 rounded-lg font-mono text-[11px] border transition-all shrink-0 ${
              currentPath === sc.path
                ? 'bg-brand-500/20 border-brand-500/50 text-brand-300 font-bold'
                : 'bg-black/30 border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {sc.label}
          </button>
        ))}
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Breadcrumb Navigation */}
        <div className="flex items-center gap-1.5 p-2 rounded-xl bg-black/40 border border-white/10 text-xs text-slate-300 overflow-x-auto flex-1 font-mono">
          <button
            onClick={() => handleNavigate('/')}
            className="p-1 rounded hover:bg-white/10 hover:text-white flex items-center gap-1 text-slate-400 shrink-0"
            title="Root directory (/)"
          >
            <Home className="w-3.5 h-3.5" />
            <span>/</span>
          </button>

          {pathParts.map((part, idx) => {
            const accumulatedPath = '/' + pathParts.slice(0, idx + 1).join('/');
            const isLast = idx === pathParts.length - 1;

            return (
              <React.Fragment key={accumulatedPath}>
                <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />
                <button
                  onClick={() => handleNavigate(accumulatedPath)}
                  className={`px-1.5 py-0.5 rounded hover:bg-white/10 hover:text-white shrink-0 ${
                    isLast ? 'text-brand-300 font-bold bg-brand-500/15' : 'text-slate-300'
                  }`}
                >
                  {part}
                </button>
              </React.Fragment>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => fetchFiles(currentPath)}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Refresh Directory"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setNewFileOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10 active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5 text-brand-400" />
            <span>New File</span>
          </button>

          <button
            onClick={() => setNewFolderOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10 active:scale-95 transition-all"
          >
            <FolderPlus className="w-3.5 h-3.5 text-amber-400" />
            <span>New Folder</span>
          </button>

          <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-md shadow-brand-500/20 cursor-pointer transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>{uploading ? 'Uploading...' : 'Upload'}</span>
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
        </div>
      </div>

      {/* File List Table */}
      <GlassCard className="p-0 overflow-hidden">
        {/* Search inside dir */}
        <div className="p-3 bg-black/40 border-b border-white/10 flex items-center justify-between">
          <div className="relative w-full max-w-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search files in this folder..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-black/50 border border-white/10 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-brand-500"
            />
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'}
          </span>
        </div>

        {error ? (
          <div className="p-8 text-center text-rose-400 text-xs flex flex-col items-center">
            <AlertCircle className="w-8 h-8 mb-2" />
            <span>{error}</span>
            <button
              onClick={() => fetchFiles('/root')}
              className="mt-3 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-mono"
            >
              Go to /root
            </button>
          </div>
        ) : loading ? (
          <div className="p-12 text-center text-slate-400 text-xs flex items-center justify-center">
            <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mr-2" />
            Loading real VM files via SFTP...
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs">
            This directory is empty.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/30 text-slate-400 border-b border-white/10 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Size</th>
                  <th className="px-5 py-3">Permissions</th>
                  <th className="px-5 py-3">Modified</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {/* Back to parent directory button if not in root */}
                {currentPath !== '/' && (
                  <tr
                    onClick={() => {
                      const parent = pathParts.slice(0, -1).join('/');
                      handleNavigate(parent ? `/${parent}` : '/');
                    }}
                    className="hover:bg-white/5 cursor-pointer text-slate-300"
                  >
                    <td colSpan="5" className="px-5 py-3 flex items-center gap-2 text-brand-400 font-bold">
                      <Folder className="w-4 h-4 fill-brand-500/20" />
                      <span>.. (Up one level)</span>
                    </td>
                  </tr>
                )}

                {filteredItems.map((item) => (
                  <tr
                    key={item.path}
                    className="hover:bg-white/5 transition-colors group"
                  >
                    <td className="px-5 py-3">
                      <div
                        onClick={() => {
                          if (item.isDirectory) {
                            handleNavigate(item.path);
                          } else {
                            setSelectedFileForEdit(item.path);
                            setEditorOpen(true);
                          }
                        }}
                        className="flex items-center gap-2.5 cursor-pointer text-slate-200 hover:text-brand-300 font-medium"
                      >
                        {getFileIcon(item.name, item.isDirectory)}
                        <span className="truncate max-w-sm">{item.name}</span>
                      </div>
                    </td>

                    <td className="px-5 py-3 text-slate-400">
                      {item.isDirectory ? '—' : formatBytes(item.size)}
                    </td>

                    <td className="px-5 py-3 text-slate-400 text-[11px]">
                      <code>{item.permissions || '-rw-r--r--'}</code>
                    </td>

                    <td className="px-5 py-3 text-slate-400 text-[11px]">
                      {new Date(item.modifiedAt).toLocaleString()}
                    </td>

                    <td className="px-5 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {!item.isDirectory && (
                          <>
                            <button
                              onClick={() => {
                                setSelectedFileForEdit(item.path);
                                setEditorOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                              title="Edit File"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => downloadFile(item.path)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-white/10 transition-colors"
                              title="Download File"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => {
                            setTargetItemForRename(item);
                            setRenameNewName(item.name);
                            setRenameOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/10 transition-colors"
                          title="Rename"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleDelete(item.path)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {/* Modals */}
      <FileEditorModal
        isOpen={editorOpen}
        onClose={() => setEditorOpen(false)}
        serverId={server.id}
        filePath={selectedFileForEdit}
        onSaved={() => fetchFiles(currentPath)}
      />

      {/* New Folder Modal */}
      <Modal
        isOpen={newFolderOpen}
        onClose={() => setNewFolderOpen(false)}
        title="Create New Folder in VM"
      >
        <form onSubmit={handleCreateFolder} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Folder Name
            </label>
            <input
              type="text"
              required
              autoFocus
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="e.g. www, my-scripts, logs"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setNewFolderOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shadow-md"
            >
              Create Folder
            </button>
          </div>
        </form>
      </Modal>

      {/* New File Modal */}
      <Modal
        isOpen={newFileOpen}
        onClose={() => setNewFileOpen(false)}
        title="Create New File in VM"
      >
        <form onSubmit={handleCreateFile} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              File Name
            </label>
            <input
              type="text"
              required
              autoFocus
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="e.g. index.js, config.json, script.sh"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setNewFileOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shadow-md"
            >
              Create & Open Editor
            </button>
          </div>
        </form>
      </Modal>

      {/* Rename Modal */}
      <Modal
        isOpen={renameOpen}
        onClose={() => setRenameOpen(false)}
        title={`Rename "${targetItemForRename?.name}"`}
      >
        <form onSubmit={handleRename} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              New Name
            </label>
            <input
              type="text"
              required
              autoFocus
              value={renameNewName}
              onChange={(e) => setRenameNewName(e.target.value)}
              placeholder="new-name"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setRenameOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-md"
            >
              Rename
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
