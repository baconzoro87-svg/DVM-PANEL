import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Calendar,
  Plus,
  Trash2,
  Play,
  Clock,
  RotateCw,
  Archive,
  Terminal,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { api } from '../../../utils/api';
import GlassCard from '../../../components/GlassCard';
import Modal from '../../../components/Modal';

export default function ServerSchedules() {
  const { server } = useOutletContext();
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  const [name, setName] = useState('');
  const [cronExpression, setCronExpression] = useState('0 0 * * *');
  const [action, setAction] = useState('restart');
  const [payload, setPayload] = useState('');

  const fetchSchedules = async () => {
    try {
      const res = await api.get(`/servers/${server.id}/schedules`);
      if (res.success) {
        setSchedules(res.schedules || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedules();
  }, [server.id]);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/servers/${server.id}/schedules`, {
        name,
        cron_expression: cronExpression,
        action,
        payload,
        is_active: 1
      });
      setModalOpen(false);
      setName('');
      setPayload('');
      fetchSchedules();
    } catch (err) {
      alert(`Failed to create schedule: ${err.message}`);
    }
  };

  const handleToggle = async (sched) => {
    try {
      await api.put(`/servers/${server.id}/schedules/${sched.id}`, {
        is_active: sched.is_active ? 0 : 1
      });
      fetchSchedules();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDelete = async (schedId) => {
    if (!confirm('Delete this automated schedule?')) return;
    try {
      await api.delete(`/servers/${server.id}/schedules/${schedId}`);
      fetchSchedules();
    } catch (err) {
      alert(err.message);
    }
  };

  const cronPresets = [
    { label: 'Every hour', val: '0 * * * *' },
    { label: 'Every 6 hours', val: '0 */6 * * *' },
    { label: 'Every 12 hours', val: '0 */12 * * *' },
    { label: 'Every day (Midnight)', val: '0 0 * * *' },
    { label: 'Every Sunday', val: '0 0 * * 0' }
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-cyan-400" />
            Automated Schedules & Cron Tasks
          </h2>
          <p className="text-xs text-slate-400">
            Set up automatic recurring tasks such as regular server restarts, automated snapshot backups, or shell scripts.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-brand-500/25 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Schedule</span>
        </button>
      </div>

      {loading ? (
        <div className="py-12 text-center text-slate-400 text-xs">Loading schedules...</div>
      ) : schedules.length === 0 ? (
        <GlassCard className="py-12 text-center">
          <Calendar className="w-10 h-10 text-slate-500 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-white mb-1">No schedules configured</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            Automate routine maintenance tasks like daily restarts or weekly backups.
          </p>
          <button
            onClick={() => setModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10"
          >
            Create First Schedule
          </button>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {schedules.map((s) => (
            <GlassCard key={s.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
                  {s.action === 'restart' ? <RotateCw className="w-5 h-5" /> : s.action === 'backup' ? <Archive className="w-5 h-5" /> : <Terminal className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-white">{s.name}</h4>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-white/5 border border-white/10 text-slate-300">
                      {s.action}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1 font-mono">
                    <span>Cron: <strong className="text-brand-300">{s.cron_expression}</strong></span>
                    <span>•</span>
                    <span>Last run: {s.last_run ? new Date(s.last_run).toLocaleString() : 'Never'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  onClick={() => handleToggle(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    s.is_active ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-500/20 text-slate-400 border border-slate-500/30'
                  }`}
                >
                  {s.is_active ? 'Enabled' : 'Disabled'}
                </button>

                <button
                  onClick={() => handleDelete(s.id)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {/* New Schedule Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Create Automated Schedule"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Schedule Name</label>
            <input
              type="text"
              required
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Daily Restart at 3 AM"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Action to Perform</label>
            <select
              value={action}
              onChange={(e) => setAction(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-brand-500"
            >
              <option value="restart" className="bg-dark-900">Restart Server</option>
              <option value="backup" className="bg-dark-900">Create Snapshot Backup</option>
              <option value="command" className="bg-dark-900">Execute Custom Shell Command</option>
            </select>
          </div>

          {action === 'command' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Command to Execute</label>
              <input
                type="text"
                required
                value={payload}
                onChange={(e) => setPayload(e.target.value)}
                placeholder="e.g. /root/clean_logs.sh or apt-get update -y"
                className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500"
              />
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-slate-300">Cron Expression</label>
              <span className="text-[10px] text-slate-500 font-mono">Minute Hour Dom Month Dow</span>
            </div>
            <input
              type="text"
              required
              value={cronExpression}
              onChange={(e) => setCronExpression(e.target.value)}
              placeholder="0 0 * * *"
              className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-brand-300 font-mono text-xs font-bold focus:outline-none focus:border-brand-500"
            />
          </div>

          {/* Quick Presets */}
          <div>
            <span className="text-[10px] text-slate-400 block mb-1.5">Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              {cronPresets.map((p) => (
                <button
                  key={p.val}
                  type="button"
                  onClick={() => setCronExpression(p.val)}
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] text-slate-300 border border-white/10"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold"
            >
              Save Schedule
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

