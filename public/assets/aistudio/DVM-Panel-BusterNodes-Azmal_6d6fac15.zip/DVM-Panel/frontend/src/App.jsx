import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';

// Layout
import Layout from './components/Layout';

// Auth Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';

// User Pages
import UserDashboard from './pages/user/UserDashboard';
import CreateServer from './pages/user/CreateServer';
import UserPlans from './pages/user/UserPlans';
import ServerLayout from './pages/user/server/ServerLayout';
import ServerOverview from './pages/user/server/ServerOverview';
import ServerConsole from './pages/user/server/ServerConsole';
import ServerFileManager from './pages/user/server/ServerFileManager';
import ServerBackups from './pages/user/server/ServerBackups';
import ServerSchedules from './pages/user/server/ServerSchedules';
import ServerStartup from './pages/user/server/ServerStartup';
import ServerSubusers from './pages/user/server/ServerSubusers';
import ServerSettings from './pages/user/server/ServerSettings';
import ServerActivity from './pages/user/server/ServerActivity';
import ServerAnalytics from './pages/user/server/ServerAnalytics';
import ServerNetwork from './pages/user/server/ServerNetwork';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminCreateServer from './pages/admin/AdminCreateServer';
import AdminServerManagement from './pages/admin/AdminServerManagement';
import AdminUserManagement from './pages/admin/AdminUserManagement';
import AdminUserProfile from './pages/admin/AdminUserProfile';
import AdminSettings from './pages/admin/AdminSettings';
import AdminDocs from './pages/admin/AdminDocs';

// Account Pages
import Profile from './pages/account/Profile';
import Tickets from './pages/account/Tickets';

function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center text-slate-400">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mr-3" />
        Loading session...
      </div>
    );
  }
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
}

function AdminRoute({ children }) {
  const { isAuthenticated, isAdmin, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center text-slate-400">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mr-3" />
        Verifying permissions...
      </div>
    );
  }
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!isAdmin) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ThemeProvider>
          <Routes>
            {/* Public Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />

            {/* Protected Routes inside Main Layout */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              {/* User Dashboard */}
              <Route index element={<UserDashboard />} />
              <Route path="servers/create" element={<CreateServer />} />
              <Route path="plans" element={<UserPlans />} />

              {/* Individual Server Management */}
              <Route path="servers/:id" element={<ServerLayout />}>
                <Route index element={<Navigate to="overview" replace />} />
                <Route path="overview" element={<ServerOverview />} />
                <Route path="console" element={<ServerConsole />} />
                <Route path="analytics" element={<ServerAnalytics />} />
                <Route path="network" element={<ServerNetwork />} />
                <Route path="files" element={<ServerFileManager />} />
                <Route path="backups" element={<ServerBackups />} />
                <Route path="schedules" element={<ServerSchedules />} />
                <Route path="startup" element={<ServerStartup />} />
                <Route path="subusers" element={<ServerSubusers />} />
                <Route path="settings" element={<ServerSettings />} />
                <Route path="activity" element={<ServerActivity />} />
              </Route>

              {/* Account Pages */}
              <Route path="profile" element={<Profile />} />
              <Route path="tickets" element={<Tickets />} />

              {/* Admin Routes */}
              <Route
                path="admin"
                element={
                  <AdminRoute>
                    <AdminDashboard />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/servers"
                element={
                  <AdminRoute>
                    <AdminServerManagement />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/servers/create"
                element={
                  <AdminRoute>
                    <AdminCreateServer />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/users"
                element={
                  <AdminRoute>
                    <AdminUserManagement />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/users/:id"
                element={
                  <AdminRoute>
                    <AdminUserProfile />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/settings"
                element={
                  <AdminRoute>
                    <AdminSettings />
                  </AdminRoute>
                }
              />
              <Route
                path="admin/docs"
                element={
                  <AdminRoute>
                    <AdminDocs />
                  </AdminRoute>
                }
              />
            </Route>

            {/* Catch-all redirect */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </ThemeProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
