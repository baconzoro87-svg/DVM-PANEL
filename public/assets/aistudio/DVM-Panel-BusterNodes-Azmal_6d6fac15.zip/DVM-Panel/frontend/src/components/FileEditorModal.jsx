import React, { useState, useEffect } from 'react';
import { Save, X, Code2, AlertCircle } from 'lucide-react';
import { api } from '../utils/api';

export default function FileEditorModal({ isOpen, onClose, serverId, filePath, onSaved }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (isOpen && filePath) {
      loadFile();
    }
  }, [isOpen, filePath]);

  const loadFile = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const res = await api.get(`/servers/${serverId}/files/content?path=${encodeURIComponent(filePath)}`);
      if (res.success) {
        setContent(res.content || '');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      const res = await api.post(`/servers/${serverId}/files/save`, {
        path: filePath,
        content
      });
      if (res.success) {
        setSuccess('File saved successfully!');
        if (onSaved) onSaved();
        setTimeout(() => setSuccess(''), 2500);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-5xl h-[85vh] glass-panel rounded-2xl shadow-2xl border border-white/15 flex flex-col z-10 overflow-hidden animate-fade-in">
        <div className="flex items-center justify-between px-6 py-3.5 bg-dark-900/90 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-400">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white font-mono">{filePath}</p>
              <p className="text-[11px] text-slate-400">Container Code & Config Editor</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {success && <span className="text-xs text-emerald-400 font-medium animate-pulse">{success}</span>}
            {error && <span className="text-xs text-rose-400 font-medium truncate max-w-xs">{error}</span>}

            <button
              onClick={handleSave}
              disabled={saving || loading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-xs font-semibold shadow-md shadow-brand-500/20 disabled:opacity-50 transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              {saving ? 'Saving...' : 'Save File'}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 bg-[#0d1117] p-0 flex relative overflow-hidden">
          {loading ? (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              <div className="w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mr-2" />
              Loading file contents...
            </div>
          ) : error && !content ? (
            <div className="flex-1 flex flex-col items-center justify-center text-rose-400 p-6">
              <AlertCircle className="w-10 h-10 mb-2" />
              <p className="font-semibold">{error}</p>
            </div>
          ) : (
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full h-full p-4 bg-transparent text-slate-200 font-mono text-sm leading-relaxed outline-none resize-none selection:bg-brand-500 selection:text-white"
              placeholder="Type or paste file content..."
              spellCheck="false"
            />
          )}
        </div>

        <div className="px-6 py-2 bg-dark-900/90 border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>Lines: {content.split('\n').length}</span>
          <span>Size: {(new Blob([content]).size / 1024).toFixed(2)} KB</span>
        </div>
      </div>
    </div>
  );
}
