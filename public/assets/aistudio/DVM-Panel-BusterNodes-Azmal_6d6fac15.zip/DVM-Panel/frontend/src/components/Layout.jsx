import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import BackgroundPlayer from './BackgroundPlayer';
import MusicWidget from './MusicWidget';

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col relative text-slate-100 selection:bg-brand-500 selection:text-white">
      <BackgroundPlayer />
      <Navbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      <div className="flex-1 flex">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="flex-1 lg:pl-64 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto animate-fade-in">
          <Outlet />
          <footer className="mt-8 pt-4 border-t border-rose-500/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-500">
            <span className="tracking-[0.18em] uppercase">DVM Panel <span className="text-rose-400/70">/</span> BusterNodes</span>
            <span>Made by <span className="text-rose-300 font-semibold">Azmal</span></span>
          </footer>
        </main>
      </div>
      <MusicWidget />
    </div>
  );
}
