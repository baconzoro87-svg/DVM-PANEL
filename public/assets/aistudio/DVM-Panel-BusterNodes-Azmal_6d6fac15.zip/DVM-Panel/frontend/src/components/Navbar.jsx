import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, Music, User, LogOut, Shield, LifeBuoy, Server, Sliders } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export default function Navbar({ onToggleSidebar }) {
  const { user, isAdmin, logout } = useAuth();
  const { settings, effectiveLogo, isPlaying, togglePlay, setMusicWidgetVisible } = useTheme();
  const [profileOpen, setProfileOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="sticky top-0 z-30 h-16 glass-header px-4 sm:px-6 flex items-center justify-between border-b border-white/10 select-none">
      <div className="flex items-center gap-4">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <Link to="/" className="flex items-center gap-3 group">
          {effectiveLogo ? (
            <img
              src={effectiveLogo}
              alt="Logo"
              className="w-9 h-9 object-contain rounded-xl shadow-md border border-white/10 group-hover:scale-105 transition-transform"
            />
          ) : (
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-700 to-red-400 flex items-center justify-center text-white font-bold shadow-lg shadow-brand-500/25 group-hover:scale-105 transition-transform">
              <Server className="w-5 h-5" />
            </div>
          )}
          <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
            {settings.panel_name || 'DVM Panel'}
          </span>
        </Link>
      </div>

      <div className="flex items-center gap-3">
        {settings.music_url && (
          <button
            onClick={() => {
              setMusicWidgetVisible(true);
              togglePlay();
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
              isPlaying
                ? 'bg-brand-500/20 border-brand-500/40 text-brand-300 shadow-sm shadow-brand-500/30'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title="Toggle Background Music"
          >
            <Music className={`w-3.5 h-3.5 ${isPlaying ? 'animate-bounce text-brand-400' : ''}`} />
            <span className="hidden md:inline">{isPlaying ? 'Music On' : 'Music Off'}</span>
          </button>
        )}

        {isAdmin && (
          <Link
            to="/admin/settings"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors hidden sm:flex"
            title="Panel Settings"
          >
            <Sliders className="w-5 h-5 text-brand-400" />
          </Link>
        )}

        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full glass-panel hover:bg-white/10 border border-white/10 transition-all"
          >
            <div className="w-7 h-7 rounded-full bg-brand-600/30 border border-brand-500/40 flex items-center justify-center text-brand-300 text-xs font-bold">
              {user?.avatar ? (
                <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover rounded-full" />
              ) : (
                user?.username?.charAt(0).toUpperCase() || 'U'
              )}
            </div>
            <span className="text-xs font-medium text-slate-200 hidden sm:inline">{user?.username}</span>
            {user?.role === 'admin' && (
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-brand-500/20 text-brand-300 border border-brand-500/30 uppercase">
                Admin
              </span>
            )}
          </button>

          {profileOpen && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setProfileOpen(false)} />
              <div className="absolute right-0 mt-2 w-56 glass-panel rounded-2xl shadow-2xl border border-white/15 py-2 z-30 animate-fade-in divide-y divide-white/10">
                <div className="px-4 py-2.5">
                  <p className="text-xs font-semibold text-white truncate">{user?.username}</p>
                  <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                </div>

                <div className="py-1">
                  <Link
                    to="/profile"
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    <User className="w-4 h-4 text-brand-400" />
                    Account Profile & 2FA
                  </Link>
                  <Link
                    to="/tickets"
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    <LifeBuoy className="w-4 h-4 text-emerald-400" />
                    Support Tickets
                  </Link>
                </div>

                {isAdmin && (
                  <div className="py-1">
                    <Link
                      to="/admin"
                      onClick={() => setProfileOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2 text-xs text-brand-300 hover:text-brand-200 hover:bg-brand-500/10 transition-colors font-medium"
                    >
                      <Shield className="w-4 h-4 text-brand-400" />
                      Admin Dashboard
                    </Link>
                  </div>
                )}

                <div className="py-1">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
