import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Search,
  Image as ImageIcon,
  Video,
  Link2,
  Upload,
  Heart,
  Eye,
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  Sliders,
  Maximize2,
  X,
  Play
} from 'lucide-react';
import { api } from '../utils/api';
import GlassCard from './GlassCard';
import Modal from './Modal';

export default function WallpaperBrowser({ currentUrl, currentType, onApply }) {
  // Tabs: '4kwallpapers' | 'upload_image' | 'upload_video' | 'custom_url' | 'favorites'
  const [activeTab, setActiveTab] = useState('4kwallpapers');

  // 4kwallpapers state
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [wallpapers, setWallpapers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasNextPage, setHasNextPage] = useState(true);

  // Favorites
  const [favorites, setFavorites] = useState([]);
  const [favLoading, setFavLoading] = useState(false);

  // Custom URL / Upload state
  const [customUrl, setCustomUrl] = useState('');
  const [customType, setCustomType] = useState('image_url');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);

  // Live Preview Modal
  const [previewItem, setPreviewItem] = useState(null);
  const [applying, setApplying] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  // Fetch Categories on mount
  useEffect(() => {
    api.get('/settings/wallpapers/categories').then((res) => {
      if (res.success && res.categories) {
        setCategories(res.categories);
      }
    }).catch(() => {});

    fetchFavorites();
  }, []);

  // Fetch Wallpapers on category / search / page change
  const fetchWallpapers = async (cat = selectedCategory, p = page, q = searchQuery) => {
    setLoading(true);
    try {
      const res = await api.get(`/settings/wallpapers/browse?category=${cat}&page=${p}&search=${encodeURIComponent(q)}`);
      if (res.success) {
        setWallpapers(res.wallpapers || []);
        setHasNextPage(res.hasNextPage !== false);
      }
    } catch (err) {
      console.error('Failed to browse wallpapers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === '4kwallpapers') {
      fetchWallpapers(selectedCategory, page, searchQuery);
    }
  }, [selectedCategory, page, activeTab]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    fetchWallpapers(selectedCategory, 1, searchQuery);
  };

  const handleCategorySelect = (slug) => {
    setSelectedCategory(slug);
    setSearchQuery('');
    setPage(1);
  };

  const fetchFavorites = async () => {
    setFavLoading(true);
    try {
      const res = await api.get('/settings/wallpapers/favorites');
      if (res.success && res.favorites) {
        setFavorites(res.favorites);
      }
    } catch (err) {
      // silent
    } finally {
      setFavLoading(false);
    }
  };

  const toggleFavorite = async (e, wp) => {
    e.stopPropagation();
    try {
      const res = await api.post('/settings/wallpapers/favorites', { wallpaper: wp });
      if (res.success) {
        setFavorites(res.favorites || []);
        showToast(res.isFavorited ? '❤️ Added to Favorites' : 'Removed from Favorites');
      }
    } catch (err) {
      console.error('Favorite toggle failed:', err);
    }
  };

  const isFavorite = (url) => {
    return favorites.some((f) => f.url === url);
  };

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3000);
  };

  // Direct 1-Click Apply
  const handleApplyWallpaper = async (url, type = 'image_url', category = 'general') => {
    setApplying(true);
    try {
      if (onApply) {
        await onApply(url, type, category);
      } else {
        await api.post('/settings/wallpapers/apply', { url, type, category });
      }
      showToast('🎉 Background applied successfully!');
      if (previewItem) setPreviewItem(null);
    } catch (err) {
      alert(`Failed to apply background: ${err.message}`);
    } finally {
      setApplying(false);
    }
  };

  // Handle Upload
  const handleFileUpload = async (file, isVideo = false) => {
    if (!file) return;
    setUploading(true);
    setUploadProgress('Uploading media asset...');

    try {
      const formData = new FormData();
      formData.append('background', file);

      const res = await api.upload('/settings/upload', formData);
      if (res.success && res.results?.background) {
        const uploadedUrl = res.results.background;
        const uploadedType = isVideo ? 'video_url' : 'image_url';
        showToast(`✅ ${isVideo ? 'Video' : 'Image'} uploaded successfully!`);
        handleApplyWallpaper(uploadedUrl, uploadedType, 'custom-upload');
      }
    } catch (err) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setUploading(false);
      setUploadProgress(null);
    }
  };

  // Download Trigger
  const handleDownload = (e, url, title = '4k-wallpaper') => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.download = `${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 Download started in full 4K resolution');
  };

  return (
    <div className="space-y-5">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-5 right-5 z-50 px-4 py-2.5 rounded-xl bg-brand-500/90 text-white text-xs font-bold shadow-xl shadow-brand-500/30 flex items-center gap-2 animate-fade-in backdrop-blur-md">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Main Tab Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-1.5 rounded-2xl bg-black/40 border border-white/10">
        <div className="flex flex-wrap items-center gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('4kwallpapers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === '4kwallpapers'
                ? 'bg-brand-500 text-white shadow-md shadow-brand-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>4kwallpapers.com Browser</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('favorites')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'favorites'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Heart className="w-4 h-4 text-rose-300 fill-rose-300" />
            <span>Favorites ({favorites.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('upload_image')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'upload_image'
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-purple-300" />
            <span>Upload Image</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('upload_video')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'upload_video'
                ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Video className="w-4 h-4 text-cyan-300" />
            <span>Upload Video</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('custom_url')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'custom_url'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Link2 className="w-4 h-4 text-emerald-300" />
            <span>Add via URL</span>
          </button>
        </div>

        {/* Current Active Indicator */}
        <div className="px-3 py-1 text-[11px] font-mono text-slate-400 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Active: <strong className="text-white uppercase">{currentType?.replace('_url', '') || 'PRESET'}</strong></span>
        </div>
      </div>

      {/* 1. 4KWALLPAPERS.COM BROWSER TAB */}
      {activeTab === '4kwallpapers' && (
        <div className="space-y-4">
          {/* Search Bar & Stats */}
          <div className="flex flex-col sm:flex-row gap-3">
            <form onSubmit={handleSearchSubmit} className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search 10,000+ 4K wallpapers (e.g. Spider-Man, Cyberpunk, BMW, Anime, NASA, Dark)..."
                className="w-full pl-10 pr-24 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-brand-500 placeholder-slate-500"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <button
                type="submit"
                className="absolute right-1.5 top-1.5 px-3 py-1.5 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold transition-colors"
              >
                Search
              </button>
            </form>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => fetchWallpapers(selectedCategory, page, searchQuery)}
                className="p-2.5 rounded-xl bg-black/40 border border-white/10 text-slate-300 hover:text-white"
                title="Refresh Gallery"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* All Categories Scrollable Filter */}
          <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-thin">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.slug;
              return (
                <button
                  key={cat.slug}
                  type="button"
                  onClick={() => handleCategorySelect(cat.slug)}
                  className={`px-3 py-1.5 rounded-xl text-xs whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-brand-500 text-white font-bold shadow-md shadow-brand-500/20'
                      : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <span>{cat.name}</span>
                  {cat.count && <span className="text-[10px] opacity-60 font-mono">({cat.count})</span>}
                </button>
              );
            })}
          </div>

          {/* Wallpapers Grid */}
          {loading ? (
            <div className="h-64 flex flex-col items-center justify-center text-slate-400 gap-3">
              <RefreshCw className="w-7 h-7 text-brand-400 animate-spin" />
              <span className="text-xs font-mono">Loading high-resolution 4K wallpapers...</span>
            </div>
          ) : wallpapers.length === 0 ? (
            <div className="p-8 rounded-2xl bg-black/30 border border-white/5 text-center text-slate-400 space-y-2">
              <p className="text-sm font-bold text-white">No wallpapers found for "{searchQuery || selectedCategory}"</p>
              <p className="text-xs">Try searching for different keywords or pick another category.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {wallpapers.map((wp) => {
                const isSelected = currentUrl === wp.url;
                const isFav = isFavorite(wp.url);

                return (
                  <div
                    key={wp.id}
                    className={`group relative rounded-2xl overflow-hidden border-2 transition-all duration-300 ${
                      isSelected
                        ? 'border-brand-500 shadow-glass-glow scale-[1.01]'
                        : 'border-white/10 hover:border-brand-500/50 hover:shadow-xl'
                    }`}
                  >
                    {/* Thumbnail Image */}
                    <div className="relative aspect-video bg-black/60 overflow-hidden">
                      <img
                        src={wp.thumb || wp.url}
                        alt={wp.title}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />

                      {/* 4K Resolution Badge */}
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-lg bg-black/70 backdrop-blur-md text-[10px] font-mono font-bold text-amber-300 border border-amber-500/30">
                        4K UHD
                      </span>

                      {/* Favorite Button */}
                      <button
                        type="button"
                        onClick={(e) => toggleFavorite(e, wp)}
                        className={`absolute top-2 right-2 p-1.5 rounded-lg backdrop-blur-md transition-transform active:scale-90 ${
                          isFav ? 'bg-rose-500 text-white' : 'bg-black/60 text-slate-300 hover:text-rose-400'
                        }`}
                        title={isFav ? 'Remove Favorite' : 'Save to Favorites'}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                      </button>

                      {/* Active Checkmark */}
                      {isSelected && (
                        <div className="absolute inset-0 bg-brand-500/20 backdrop-blur-[1px] flex items-center justify-center pointer-events-none">
                          <div className="w-10 h-10 rounded-full bg-brand-500 text-white flex items-center justify-center shadow-lg animate-scale-in">
                            <Check className="w-6 h-6 stroke-[3]" />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Card Body */}
                    <div className="p-3 bg-black/50 backdrop-blur-sm space-y-2 border-t border-white/5">
                      <h4 className="text-xs font-bold text-white truncate" title={wp.title}>
                        {wp.title}
                      </h4>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-1.5 pt-1">
                        {/* 1-Click Apply */}
                        <button
                          type="button"
                          onClick={() => handleApplyWallpaper(wp.url, 'image_url', wp.category)}
                          disabled={applying || isSelected}
                          className={`flex-1 py-1.5 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                            isSelected
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-brand-500 hover:bg-brand-600 text-white shadow-md shadow-brand-500/25'
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Applied</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3 h-3 text-amber-300" />
                              <span>Apply</span>
                            </>
                          )}
                        </button>

                        {/* Live Preview Button */}
                        <button
                          type="button"
                          onClick={() => setPreviewItem(wp)}
                          className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white"
                          title="Live Preview on Panel"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {/* Download 4K */}
                        <button
                          type="button"
                          onClick={(e) => handleDownload(e, wp.url, wp.title)}
                          className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white"
                          title="Download 4K Image"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Pagination Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={() => setPage((prev) => Math.max(1, prev - 1))}
              disabled={page <= 1 || loading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-black/40 border border-white/10 text-xs font-bold text-slate-300 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous Page</span>
            </button>

            <span className="text-xs font-mono text-slate-400">
              Page <strong className="text-white">{page}</strong>
            </span>

            <button
              type="button"
              onClick={() => setPage((prev) => prev + 1)}
              disabled={!hasNextPage || loading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-xs font-bold text-white shadow-md disabled:opacity-30 disabled:pointer-events-none"
            >
              <span>Next Page</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 2. FAVORITES TAB */}
      {activeTab === 'favorites' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
              Your Starred 4K Wallpapers ({favorites.length})
            </h3>
            {favorites.length > 0 && (
              <span className="text-[11px] font-mono text-slate-400">Saved in your dpanel profile</span>
            )}
          </div>

          {favorites.length === 0 ? (
            <div className="p-10 rounded-2xl bg-black/30 border border-white/5 text-center text-slate-400 space-y-2">
              <Heart className="w-8 h-8 text-rose-400/40 mx-auto" />
              <p className="text-sm font-bold text-white">No favorite wallpapers yet</p>
              <p className="text-xs">Browse the 4kwallpapers catalog and click the ❤️ icon to pin your favorites here!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {favorites.map((wp) => {
                const isSelected = currentUrl === wp.url;
                return (
                  <div
                    key={wp.url}
                    className={`group relative rounded-2xl overflow-hidden border-2 transition-all ${
                      isSelected ? 'border-brand-500 shadow-glass-glow' : 'border-white/10 hover:border-brand-500/50'
                    }`}
                  >
                    <div className="relative aspect-video bg-black/60 overflow-hidden">
                      <img src={wp.thumb || wp.url} alt={wp.title} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={(e) => toggleFavorite(e, wp)}
                        className="absolute top-2 right-2 p-1.5 rounded-lg bg-rose-500 text-white shadow"
                        title="Remove Favorite"
                      >
                        <Heart className="w-3.5 h-3.5 fill-white" />
                      </button>
                    </div>

                    <div className="p-3 bg-black/50 backdrop-blur-sm space-y-2 border-t border-white/5">
                      <h4 className="text-xs font-bold text-white truncate">{wp.title}</h4>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleApplyWallpaper(wp.url, 'image_url', wp.category)}
                          disabled={applying || isSelected}
                          className="flex-1 py-1.5 px-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold flex items-center justify-center gap-1"
                        >
                          <Sparkles className="w-3 h-3 text-amber-300" />
                          <span>{isSelected ? 'Applied' : 'Apply'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setPreviewItem(wp)}
                          className="p-1.5 rounded-xl bg-white/5 text-slate-300 hover:text-white"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 3. UPLOAD IMAGE TAB */}
      {activeTab === 'upload_image' && (
        <div className="p-6 rounded-2xl bg-black/40 border border-white/10 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-purple-400" />
              Upload Custom High-Res Image Background
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Supports PNG, JPG, JPEG, WebP, SVG up to 50MB.
            </p>
          </div>

          <div className="border-2 border-dashed border-white/20 hover:border-purple-500/50 rounded-2xl p-8 text-center space-y-3 transition-colors bg-black/20">
            <Upload className="w-8 h-8 text-purple-400 mx-auto" />
            <div>
              <p className="text-xs font-bold text-white">Select image from your device</p>
              <p className="text-[11px] text-slate-500">Will be uploaded and hosted permanently in dpanel storage.</p>
            </div>
            <input
              type="file"
              accept="image/*"
              disabled={uploading}
              onChange={(e) => handleFileUpload(e.target.files?.[0], false)}
              className="text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-purple-500 file:text-white hover:file:bg-purple-600 cursor-pointer"
            />
          </div>

          {uploading && (
            <div className="flex items-center justify-center gap-2 text-xs font-mono text-purple-300">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>{uploadProgress || 'Uploading image...'}</span>
            </div>
          )}
        </div>
      )}

      {/* 4. UPLOAD VIDEO TAB */}
      {activeTab === 'upload_video' && (
        <div className="p-6 rounded-2xl bg-black/40 border border-white/10 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Video className="w-4 h-4 text-cyan-400" />
              Upload Looping MP4 / WebM Video Background
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Animated live wallpaper background that loops smoothly behind the glassmorphism panel.
            </p>
          </div>

          <div className="border-2 border-dashed border-white/20 hover:border-cyan-500/50 rounded-2xl p-8 text-center space-y-3 transition-colors bg-black/20">
            <Video className="w-8 h-8 text-cyan-400 mx-auto" />
            <div>
              <p className="text-xs font-bold text-white">Select MP4 / WebM video</p>
              <p className="text-[11px] text-slate-500">Autoplays muted and loops infinitely behind glass cards.</p>
            </div>
            <input
              type="file"
              accept="video/mp4,video/webm"
              disabled={uploading}
              onChange={(e) => handleFileUpload(e.target.files?.[0], true)}
              className="text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-cyan-500 file:text-white hover:file:bg-cyan-600 cursor-pointer"
            />
          </div>

          {uploading && (
            <div className="flex items-center justify-center gap-2 text-xs font-mono text-cyan-300">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>{uploadProgress || 'Uploading video...'}</span>
            </div>
          )}
        </div>
      )}

      {/* 5. ADD VIA URL TAB */}
      {activeTab === 'custom_url' && (
        <div className="p-6 rounded-2xl bg-black/40 border border-white/10 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Link2 className="w-4 h-4 text-emerald-400" />
              Add Background via Direct URL
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Paste any public CDN, Unsplash, Imgur, or direct video URL.
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Background Media URL</label>
              <input
                type="text"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://images.unsplash.com/... or https://domain.com/wallpaper.mp4"
                className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="customType"
                  value="image_url"
                  checked={customType === 'image_url'}
                  onChange={() => setCustomType('image_url')}
                  className="text-emerald-500"
                />
                <span>Static Image</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="customType"
                  value="video_url"
                  checked={customType === 'video_url'}
                  onChange={() => setCustomType('video_url')}
                  className="text-emerald-500"
                />
                <span>MP4 Video Loop</span>
              </label>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => handleApplyWallpaper(customUrl, customType, 'custom-url')}
                disabled={!customUrl || applying}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold shadow-md flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Apply Background</span>
              </button>

              <button
                type="button"
                onClick={() => setPreviewItem({ url: customUrl, title: 'Custom URL Preview', type: customType })}
                disabled={!customUrl}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-50 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1.5"
              >
                <Eye className="w-4 h-4" />
                <span>Live Preview</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LIVE PREVIEW MODAL (Shows actual dpanel glass cards over background) */}
      <Modal
        isOpen={!!previewItem}
        onClose={() => setPreviewItem(null)}
        title={`Live Preview: ${previewItem?.title || 'Wallpaper Preview'}`}
        maxWidth="max-w-4xl"
      >
        <div className="space-y-4">
          <div className="relative w-full h-96 rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
            {/* Background Layer */}
            {previewItem?.type === 'video_url' || previewItem?.url?.endsWith('.mp4') ? (
              <video
                src={previewItem?.url}
                autoPlay
                loop
                muted
                playsInline
                className="absolute inset-0 w-full h-full object-cover"
              />
            ) : (
              <div
                className="absolute inset-0 w-full h-full bg-cover bg-center"
                style={{ backgroundImage: `url("${previewItem?.url || previewItem?.thumb}")` }}
              />
            )}

            {/* Glass Overlays Mocking Real dpanel Dashboard */}
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm p-6 flex flex-col justify-between">
              {/* Header Mock */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/20">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-brand-500 text-white flex items-center justify-center font-bold text-xs">
                    dP
                  </div>
                  <span className="text-xs font-bold text-white">dpanel Dashboard Live Preview</span>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/30 text-emerald-300 text-[10px] font-mono font-bold">
                  ● SYSTEM RUNNING
                </span>
              </div>

              {/* Sample Metrics Cards */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10">
                  <span className="text-[10px] text-slate-400 font-sans uppercase block">CPU Usage</span>
                  <span className="text-lg font-bold text-brand-300 font-mono">14.2%</span>
                </div>
                <div className="p-3.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10">
                  <span className="text-[10px] text-slate-400 font-sans uppercase block">Memory RAM</span>
                  <span className="text-lg font-bold text-purple-300 font-mono">1.82 GB</span>
                </div>
                <div className="p-3.5 rounded-xl bg-black/60 backdrop-blur-md border border-white/10">
                  <span className="text-[10px] text-slate-400 font-sans uppercase block">Network RX/TX</span>
                  <span className="text-lg font-bold text-cyan-300 font-mono">1.2 MB/s</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Controls */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-mono text-slate-400 truncate max-w-[300px]">
              {previewItem?.url}
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium"
              >
                Close Preview
              </button>

              <button
                type="button"
                onClick={() => handleApplyWallpaper(previewItem?.url, previewItem?.type || 'image_url', previewItem?.category || 'general')}
                disabled={applying}
                className="px-5 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold shadow-lg shadow-brand-500/25 flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Apply As Background</span>
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

