import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Calendar as CalendarIcon,
  Sun,
  Moon,
  Timer,
  Zap,
  CheckCircle2,
  CalendarDays,
  Sparkles,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

// Helpers for 24h <-> 12h AM/PM conversion
export const parse24To12 = (time24 = '23:00') => {
  const [hStr, mStr, sStr] = (time24 || '23:00:00').split(':');
  let h = parseInt(hStr || '23', 10);
  if (isNaN(h)) h = 23;
  const m = String(mStr || '00').padStart(2, '0');
  const s = String(sStr || '00').padStart(2, '0');
  const period = h >= 12 ? 'PM' : 'AM';
  let h12 = h % 12;
  if (h12 === 0) h12 = 12;
  return {
    hour: String(h12).padStart(2, '0'),
    minute: m,
    second: s,
    period
  };
};

export const format12To24 = (hour12, minute, second = '00', period = 'PM') => {
  let h = parseInt(hour12 || '12', 10);
  const m = String(minute || '00').padStart(2, '0');
  const s = String(second || '00').padStart(2, '0');
  if (period === 'PM' && h < 12) h += 12;
  if (period === 'AM' && h === 12) h = 0;
  return `${String(h).padStart(2, '0')}:${m}:${s}`;
};

export const formatDisplay12 = (time24 = '23:00') => {
  if (!time24) return '11:00 PM';
  const { hour, minute, period } = parse24To12(time24);
  return `${hour}:${minute} ${period}`;
};

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const WEEKDAY_NAMES = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export default function AutoSuspendPicker({
  suspendType = 'hours',
  setSuspendType,
  suspendHours = '0',
  setSuspendHours,
  suspendAt = '',
  setSuspendAt,
  suspendTime = '23:00',
  setSuspendTime,
  className = ''
}) {
  const now = useMemo(() => new Date(), []);

  // --- Calendar Date State ---
  const initialDate = useMemo(() => {
    if (suspendAt) {
      const d = new Date(suspendAt);
      if (!isNaN(d.getTime())) return d;
    }
    // Default: current time + 2 hours
    const d = new Date(Date.now() + 2 * 60 * 60 * 1000);
    return d;
  }, [suspendAt]);

  const [viewYear, setViewYear] = useState(initialDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(initialDate.getMonth()); // 0 - 11
  const [selectedYear, setSelectedYear] = useState(initialDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(initialDate.getMonth());
  const [selectedDay, setSelectedDay] = useState(initialDate.getDate());

  // --- Calendar Time State (HH:MM:SS AM/PM) ---
  const [calHour12, setCalHour12] = useState(
    String(initialDate.getHours() % 12 === 0 ? 12 : initialDate.getHours() % 12).padStart(2, '0')
  );
  const [calMinute, setCalMinute] = useState(String(initialDate.getMinutes()).padStart(2, '0'));
  const [calSecond, setCalSecond] = useState(String(initialDate.getSeconds() || '00').padStart(2, '0'));
  const [calPeriod, setCalPeriod] = useState(initialDate.getHours() >= 12 ? 'PM' : 'AM');

  // --- Daily Schedule 12-Hour AM/PM State ---
  const initialDaily12 = parse24To12(suspendTime || '23:00');
  const [dailyHour12, setDailyHour12] = useState(initialDaily12.hour);
  const [dailyMinute, setDailyMinute] = useState(initialDaily12.minute);
  const [dailyPeriod, setDailyPeriod] = useState(initialDaily12.period);

  // Sync calendar selected date + time into parent suspendAt UTC ISO string
  const updateCalendarDateTime = (y, m, d, h12, min, sec, prd) => {
    setSelectedYear(y);
    setSelectedMonth(m);
    setSelectedDay(d);
    setCalHour12(h12);
    setCalMinute(min);
    setCalSecond(sec);
    setCalPeriod(prd);

    let h24 = parseInt(h12, 10);
    if (prd === 'PM' && h24 < 12) h24 += 12;
    if (prd === 'AM' && h24 === 12) h24 = 0;

    // Create exact local date object and export ISO UTC string so backend parses identical timestamp
    const dateObj = new Date(y, m, d, h24, parseInt(min, 10), parseInt(sec, 10));
    setSuspendAt(dateObj.toISOString());
  };

  // Sync daily schedule time into parent suspendTime ("HH:mm") + calculate next occurrence
  const updateDailyTime = (h12, min, prd) => {
    setDailyHour12(h12);
    setDailyMinute(min);
    setDailyPeriod(prd);

    let h24 = parseInt(h12, 10);
    if (prd === 'PM' && h24 < 12) h24 += 12;
    if (prd === 'AM' && h24 === 12) h24 = 0;
    const pad = (n) => String(n).padStart(2, '0');
    setSuspendTime(`${pad(h24)}:${pad(min)}`);

    // Also calculate next ISO timestamp for exact execution
    const d = new Date();
    d.setHours(h24, parseInt(min, 10), 0, 0);
    if (d.getTime() <= Date.now()) {
      d.setDate(d.getDate() + 1);
    }
    setSuspendAt(d.toISOString());
  };

  // Month navigation
  const prevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(viewYear - 1);
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const nextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(viewYear + 1);
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  // Calculate days for the calendar grid
  const calendarDays = useMemo(() => {
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
    const firstDayIndex = new Date(viewYear, viewMonth, 1).getDay(); // 0 = Sun
    const prevMonthDays = new Date(viewYear, viewMonth, 0).getDate();

    const days = [];

    // Leading padding days from previous month
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      days.push({
        day: prevMonthDays - i,
        isCurrentMonth: false,
        isPrevMonth: true,
        year: viewMonth === 0 ? viewYear - 1 : viewYear,
        month: viewMonth === 0 ? 11 : viewMonth - 1
      });
    }

    // Days in current month
    for (let d = 1; d <= daysInMonth; d++) {
      days.push({
        day: d,
        isCurrentMonth: true,
        year: viewYear,
        month: viewMonth
      });
    }

    // Trailing padding days to fill 35 or 42 grid slots
    const totalSlots = days.length <= 35 ? 35 : 42;
    const remaining = totalSlots - days.length;
    for (let i = 1; i <= remaining; i++) {
      days.push({
        day: i,
        isCurrentMonth: false,
        isNextMonth: true,
        year: viewMonth === 11 ? viewYear + 1 : viewYear,
        month: viewMonth === 11 ? 0 : viewMonth + 1
      });
    }

    return days;
  }, [viewYear, viewMonth]);

  // Selected date formatted in long full English (e.g. "Saturday, 1 August 2026")
  const selectedDateFullLabel = useMemo(() => {
    const d = new Date(selectedYear, selectedMonth, selectedDay);
    return d.toLocaleDateString('en-US', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  }, [selectedYear, selectedMonth, selectedDay]);

  // Quick Calendar Jump
  const handleQuickJump = (hoursOffset) => {
    const target = new Date(Date.now() + hoursOffset * 60 * 60 * 1000);
    const y = target.getFullYear();
    const m = target.getMonth();
    const d = target.getDate();
    const h12 = String(target.getHours() % 12 === 0 ? 12 : target.getHours() % 12).padStart(2, '0');
    const min = String(target.getMinutes()).padStart(2, '0');
    const sec = String(target.getSeconds()).padStart(2, '0');
    const prd = target.getHours() >= 12 ? 'PM' : 'AM';

    setViewYear(y);
    setViewMonth(m);
    updateCalendarDateTime(y, m, d, h12, min, sec, prd);
  };

  // Helper to format remaining time
  const getRemainingTimeNotice = () => {
    if (!suspendAt) return 'Select a date and time from the calendar';
    const target = new Date(suspendAt).getTime();
    if (isNaN(target)) return 'Invalid date';
    const diff = target - Date.now();
    if (diff <= 0) return 'Selected date & time has arrived or passed (Will suspend immediately)';

    const totalSeconds = Math.floor(diff / 1000);
    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;

    if (days > 0) {
      return `Suspends in ${days} day(s), ${hours} hour(s), ${mins} min(s)`;
    }
    return `Suspends in ${hours} hour(s), ${mins} minute(s), ${secs} second(s)`;
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Mode Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-1.5 rounded-2xl bg-black/40 border border-white/10">
        <button
          type="button"
          onClick={() => setSuspendType('hours')}
          className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold transition-all ${
            suspendType === 'hours'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <Timer className="w-3.5 h-3.5 shrink-0" />
          <span>Continuous Timer</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setSuspendType('datetime');
            updateCalendarDateTime(selectedYear, selectedMonth, selectedDay, calHour12, calMinute, calSecond, calPeriod);
          }}
          className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold transition-all ${
            suspendType === 'datetime'
              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm shadow-purple-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <CalendarDays className="w-3.5 h-3.5 shrink-0" />
          <span>📅 Date & Calendar</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setSuspendType('daily_time');
            updateDailyTime(dailyHour12, dailyMinute, dailyPeriod);
          }}
          className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold transition-all ${
            suspendType === 'daily_time'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <Moon className="w-3.5 h-3.5 shrink-0" />
          <span>Daily Sleep (AM/PM)</span>
        </button>
      </div>

      {/* Mode 1: Continuous Runtime Hours / Minutes */}
      {suspendType === 'hours' && (
        <div className="space-y-3 p-4 rounded-2xl bg-black/30 border border-white/10 animate-fade-in">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300">
              Select Continuous Runtime Duration:
            </label>
            <span className="text-[11px] text-amber-400 font-mono">
              Auto-sleep after continuous running
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
            {[
              { label: 'Never (Always On)', val: '0' },
              { label: '⚡ 5 Mins (Test)', val: '0.083' },
              { label: '⚡ 15 Mins', val: '0.25' },
              { label: '⚡ 30 Mins', val: '0.5' },
              { label: '1 Hour', val: '1' },
              { label: '2 Hours', val: '2' },
              { label: '4 Hours', val: '4' },
              { label: '6 Hours', val: '6' },
              { label: '12 Hours', val: '12' },
              { label: '24 Hours (1 Day)', val: '24' },
              { label: '48 Hours (2 Days)', val: '48' },
              { label: '72 Hours (3 Days)', val: '72' },
              { label: '7 Days', val: '168' },
              { label: '30 Days', val: '720' }
            ].map(opt => (
              <button
                key={opt.val}
                type="button"
                onClick={() => setSuspendHours(opt.val)}
                className={`p-2.5 rounded-xl border text-xs font-mono transition-all text-center ${
                  String(suspendHours) === opt.val
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-md shadow-amber-500/10'
                    : 'bg-black/40 border-white/10 text-slate-400 hover:text-slate-200 hover:bg-black/60'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Custom Hours Input */}
          <div className="flex items-center gap-3 pt-2">
            <span className="text-xs text-slate-400 font-sans">Or enter custom hours:</span>
            <div className="relative w-36">
              <input
                type="number"
                step="0.01"
                min="0"
                max="8760"
                value={suspendHours}
                onChange={(e) => setSuspendHours(e.target.value)}
                placeholder="0"
                className="w-full px-3 py-1.5 rounded-xl bg-black/60 border border-white/15 text-amber-300 text-xs font-mono font-bold focus:outline-none focus:border-amber-400 text-center"
              />
              <span className="absolute right-2.5 top-2 text-[10px] text-slate-500 font-mono">
                hrs
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Full Interactive Visual Calendar & AM/PM Time Selector */}
      {suspendType === 'datetime' && (
        <div className="space-y-4 p-4 rounded-2xl bg-black/40 border border-purple-500/40 shadow-xl animate-fade-in">
          {/* Header Banner: Selected Full Date */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-purple-900/40 via-purple-800/20 to-black border border-purple-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                <CalendarIcon className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-purple-300 uppercase tracking-widest font-mono block">
                  Selected Scheduled Date:
                </span>
                <span className="text-sm sm:text-base font-extrabold text-white tracking-tight">
                  {selectedDateFullLabel}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1 font-mono text-xs text-purple-300 bg-black/50 px-3 py-1.5 rounded-lg border border-purple-500/20 self-start sm:self-auto">
              <Clock className="w-3.5 h-3.5 text-purple-400" />
              <span className="font-bold">
                {calHour12}:{calMinute}:{calSecond} {calPeriod}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left Column: Visual Interactive Month Grid (7 Cols) */}
            <div className="lg:col-span-7 p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
              {/* Month & Year Navigation Bar */}
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <button
                  type="button"
                  onClick={prevMonth}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-sm font-extrabold text-white tracking-wide">
                    {MONTH_NAMES[viewMonth]} {viewYear}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={nextMonth}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                  title="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Days of Week Row (Su Mo Tu We Th Fr Sa) */}
              <div className="grid grid-cols-7 gap-1 text-center font-mono text-[11px] font-bold pb-1 text-slate-400">
                {WEEKDAY_NAMES.map((name, idx) => (
                  <div
                    key={name}
                    className={`py-1 ${idx === 0 || idx === 6 ? 'text-purple-400' : 'text-slate-400'}`}
                  >
                    {name}
                  </div>
                ))}
              </div>

              {/* Day Cells Grid */}
              <div className="grid grid-cols-7 gap-1.5 text-center font-mono text-xs">
                {calendarDays.map((item, idx) => {
                  const isSelected =
                    item.isCurrentMonth &&
                    selectedYear === item.year &&
                    selectedMonth === item.month &&
                    selectedDay === item.day;

                  const isToday =
                    now.getFullYear() === item.year &&
                    now.getMonth() === item.month &&
                    now.getDate() === item.day;

                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        updateCalendarDateTime(
                          item.year,
                          item.month,
                          item.day,
                          calHour12,
                          calMinute,
                          calSecond,
                          calPeriod
                        );
                        if (!item.isCurrentMonth) {
                          setViewYear(item.year);
                          setViewMonth(item.month);
                        }
                      }}
                      className={`h-9 rounded-xl flex items-center justify-center font-semibold transition-all relative ${
                        isSelected
                          ? 'bg-purple-600 text-white font-extrabold shadow-lg shadow-purple-600/40 ring-2 ring-purple-400 scale-105 z-10'
                          : isToday
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-400/50 hover:bg-purple-500/30'
                          : !item.isCurrentMonth
                          ? 'text-slate-600 hover:text-slate-400'
                          : 'text-slate-200 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <span>{item.day}</span>
                      {isToday && !isSelected && (
                        <span className="absolute bottom-1 w-1 h-1 rounded-full bg-purple-400" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right Column: 12-Hour AM/PM Time Selector (HH : MM : SS AM/PM) & Presets */}
            <div className="lg:col-span-5 space-y-3 flex flex-col justify-between">
              {/* Exact Time Input Box */}
              <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  Set Exact Time (Hour : Min : Sec AM/PM):
                </label>

                <div className="flex items-center gap-1.5">
                  {/* Hour (01-12) */}
                  <div className="flex-1">
                    <span className="text-[10px] text-slate-500 font-mono block mb-1 text-center">HH</span>
                    <select
                      value={calHour12}
                      onChange={(e) =>
                        updateCalendarDateTime(
                          selectedYear,
                          selectedMonth,
                          selectedDay,
                          e.target.value,
                          calMinute,
                          calSecond,
                          calPeriod
                        )
                      }
                      className="w-full px-2 py-2 rounded-xl bg-black/80 border border-purple-500/40 text-purple-200 font-mono text-sm font-bold focus:outline-none focus:border-purple-400 text-center"
                    >
                      {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')).map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>

                  <span className="text-lg font-bold text-purple-400 pt-4">:</span>

                  {/* Minute (00-59) */}
                  <div className="flex-1">
                    <span className="text-[10px] text-slate-500 font-mono block mb-1 text-center">MM</span>
                    <select
                      value={calMinute}
                      onChange={(e) =>
                        updateCalendarDateTime(
                          selectedYear,
                          selectedMonth,
                          selectedDay,
                          calHour12,
                          e.target.value,
                          calSecond,
                          calPeriod
                        )
                      }
                      className="w-full px-2 py-2 rounded-xl bg-black/80 border border-purple-500/40 text-purple-200 font-mono text-sm font-bold focus:outline-none focus:border-purple-400 text-center"
                    >
                      {Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0')).map(m => (
                        <option key={m} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>

                  <span className="text-lg font-bold text-purple-400 pt-4">:</span>

                  {/* Second (00-59) */}
                  <div className="flex-1">
                    <span className="text-[10px] text-slate-500 font-mono block mb-1 text-center">SS</span>
                    <select
                      value={calSecond}
                      onChange={(e) =>
                        updateCalendarDateTime(
                          selectedYear,
                          selectedMonth,
                          selectedDay,
                          calHour12,
                          calMinute,
                          e.target.value,
                          calPeriod
                        )
                      }
                      className="w-full px-2 py-2 rounded-xl bg-black/80 border border-purple-500/40 text-purple-200 font-mono text-sm font-bold focus:outline-none focus:border-purple-400 text-center"
                    >
                      {Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0')).map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  {/* AM/PM Toggle */}
                  <div className="w-20">
                    <span className="text-[10px] text-slate-500 font-mono block mb-1 text-center">PERIOD</span>
                    <div className="grid grid-cols-2 gap-1 bg-black/80 p-1 rounded-xl border border-white/10">
                      <button
                        type="button"
                        onClick={() =>
                          updateCalendarDateTime(
                            selectedYear,
                            selectedMonth,
                            selectedDay,
                            calHour12,
                            calMinute,
                            calSecond,
                            'AM'
                          )
                        }
                        className={`py-1 rounded-lg text-xs font-bold font-mono transition-all ${
                          calPeriod === 'AM'
                            ? 'bg-amber-500/30 border border-amber-400 text-amber-300 shadow-sm'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        AM
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          updateCalendarDateTime(
                            selectedYear,
                            selectedMonth,
                            selectedDay,
                            calHour12,
                            calMinute,
                            calSecond,
                            'PM'
                          )
                        }
                        className={`py-1 rounded-lg text-xs font-bold font-mono transition-all ${
                          calPeriod === 'PM'
                            ? 'bg-purple-500/40 border border-purple-400 text-purple-300 shadow-sm'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        PM
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-2 rounded-xl bg-purple-950/40 border border-purple-500/20 text-center font-mono text-xs text-purple-200">
                  🕒 Selected: <strong>{calHour12}:{calMinute}:{calSecond} {calPeriod}</strong>
                </div>
              </div>

              {/* Quick Jump Buttons */}
              <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Quick Calendar Jumps:
                </label>
                <div className="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                  <button
                    type="button"
                    onClick={() => handleQuickJump(0.083)}
                    className="p-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-center transition-all font-bold"
                  >
                    +5 Mins (Test)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickJump(2)}
                    className="p-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 text-center transition-all"
                  >
                    +2 Hours
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickJump(6)}
                    className="p-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 text-center transition-all"
                  >
                    +6 Hours
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickJump(24)}
                    className="p-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 text-center transition-all"
                  >
                    Tomorrow
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickJump(72)}
                    className="p-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 text-center transition-all"
                  >
                    +3 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickJump(168)}
                    className="p-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 text-center transition-all"
                  >
                    +7 Days
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Countdown / Remaining Time Notice */}
          <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-500/30 flex items-center gap-2.5 text-xs text-purple-200">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0 animate-pulse" />
            <span>
              <strong>Calendar Action: </strong>
              {getRemainingTimeNotice()} • Trigger target: <strong>{selectedDateFullLabel} at {calHour12}:{calMinute}:{calSecond} {calPeriod}</strong>
            </span>
          </div>
        </div>
      )}

      {/* Mode 3: Daily Recurring Sleep Schedule with AM/PM Support */}
      {suspendType === 'daily_time' && (
        <div className="space-y-4 p-4 rounded-2xl bg-black/30 border border-cyan-500/30 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Moon className="w-4 h-4 text-cyan-400" />
              <label className="text-xs font-bold text-white">
                Daily Automatic Sleep Time (12-Hour AM/PM):
              </label>
            </div>
            <span className="text-[11px] text-cyan-300 font-mono">
              Repeats Daily
            </span>
          </div>

          {/* Full Custom 12-Hour AM/PM Time Selector */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
              <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                Select Exact Time (Hour : Minute : AM/PM):
              </label>

              <div className="flex items-center gap-2">
                {/* Hour Select (01-12) */}
                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 font-mono block mb-1">HOUR</span>
                  <select
                    value={dailyHour12}
                    onChange={(e) => updateDailyTime(e.target.value, dailyMinute, dailyPeriod)}
                    className="w-full px-3 py-2 rounded-xl bg-black/80 border border-cyan-500/40 text-cyan-200 font-mono text-sm font-bold focus:outline-none focus:border-cyan-400 text-center"
                  >
                    {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')).map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>

                <span className="text-xl font-bold text-slate-400 pt-4">:</span>

                {/* Minute Select (00-59) */}
                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 font-mono block mb-1">MINUTE</span>
                  <select
                    value={dailyMinute}
                    onChange={(e) => updateDailyTime(dailyHour12, e.target.value, dailyPeriod)}
                    className="w-full px-3 py-2 rounded-xl bg-black/80 border border-cyan-500/40 text-cyan-200 font-mono text-sm font-bold focus:outline-none focus:border-cyan-400 text-center"
                  >
                    {Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0')).map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                {/* AM / PM Toggle Buttons */}
                <div className="flex-1">
                  <span className="text-[10px] text-slate-500 font-mono block mb-1">PERIOD</span>
                  <div className="grid grid-cols-2 gap-1 bg-black/80 p-1 rounded-xl border border-white/10">
                    <button
                      type="button"
                      onClick={() => updateDailyTime(dailyHour12, dailyMinute, 'AM')}
                      className={`py-1 rounded-lg text-xs font-bold font-mono transition-all ${
                        dailyPeriod === 'AM'
                          ? 'bg-amber-500/30 border border-amber-400 text-amber-300 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      AM
                    </button>
                    <button
                      type="button"
                      onClick={() => updateDailyTime(dailyHour12, dailyMinute, 'PM')}
                      className={`py-1 rounded-lg text-xs font-bold font-mono transition-all ${
                        dailyPeriod === 'PM'
                          ? 'bg-indigo-500/30 border border-indigo-400 text-indigo-300 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      PM
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs font-mono pt-1 text-slate-400">
                <span>Selected:</span>
                <span className="text-cyan-300 font-extrabold text-sm">
                  {dailyHour12}:{dailyMinute} {dailyPeriod} ({format12To24(dailyHour12, dailyMinute, '00', dailyPeriod)} 24h)
                </span>
              </div>
            </div>

            {/* Quick AM/PM Popular Presets */}
            <div className="space-y-2">
              <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                Quick AM / PM Presets:
              </label>

              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                {[
                  { label: '🌙 10:00 PM (Night Sleep)', h: '10', m: '00', p: 'PM' },
                  { label: '🌙 11:00 PM (Late Night)', h: '11', m: '00', p: 'PM' },
                  { label: '🌙 11:30 PM (Pre-Midnight)', h: '11', m: '30', p: 'PM' },
                  { label: '🌌 12:00 AM (Midnight)', h: '12', m: '00', p: 'AM' },
                  { label: '🌌 02:00 AM (Deep Night)', h: '02', m: '00', p: 'AM' },
                  { label: '☀️ 06:00 AM (Morning)', h: '06', m: '00', p: 'AM' },
                  { label: '☀️ 12:00 PM (Noon)', h: '12', m: '00', p: 'PM' },
                  { label: '🌆 06:00 PM (Evening)', h: '06', m: '00', p: 'PM' }
                ].map(item => {
                  const isSelected = dailyHour12 === item.h && dailyMinute === item.m && dailyPeriod === item.p;
                  return (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => updateDailyTime(item.h, item.m, item.p)}
                      className={`p-2 rounded-xl border text-left text-[11px] transition-all truncate ${
                        isSelected
                          ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 font-bold shadow-sm'
                          : 'bg-black/40 hover:bg-black/60 text-slate-300 border-white/10 hover:border-white/20'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-500/20 flex items-center gap-2.5 text-xs text-cyan-200">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              VM will automatically stop and sleep <strong>every day at {dailyHour12}:{dailyMinute} {dailyPeriod}</strong> ({format12To24(dailyHour12, dailyMinute, '00', dailyPeriod)} 24h) to optimize server resources.
            </span>
          </div>
        </div>
      )}

      {/* Live Status Badge */}
      <div className="flex items-center gap-3 p-3.5 rounded-xl bg-black/40 border border-white/10">
        <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping shrink-0" />
        <span className="text-xs text-slate-300">
          <strong>Configured Policy: </strong>
          {suspendType === 'hours' ? (
            String(suspendHours) === '0' ? (
              <span className="text-emerald-400 font-bold">Continuous 24/7 (Never Auto-Suspend)</span>
            ) : (
              <span className="text-amber-300 font-bold">Auto-Suspend after {suspendHours} continuous hour(s)</span>
            )
          ) : suspendType === 'datetime' ? (
            <span className="text-purple-300 font-bold">
              Scheduled Calendar Sleep on {selectedDateFullLabel} at {calHour12}:{calMinute}:{calSecond} {calPeriod}
            </span>
          ) : (
            <span className="text-cyan-300 font-bold">
              Daily Sleep Schedule at {dailyHour12}:{dailyMinute} {dailyPeriod} ({format12To24(dailyHour12, dailyMinute, '00', dailyPeriod)} 24h)
            </span>
          )}
        </span>
      </div>
    </div>
  );
}
