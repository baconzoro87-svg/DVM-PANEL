import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export default function GlassCard({ children, className = '', hover = true, glow = false, ...props }) {
  return (
    <div
      className={twMerge(
        clsx(
          'glass-card rounded-2xl p-6 transition-all duration-200 border border-white/10',
          hover && 'hover:border-brand-500/30 hover:shadow-glass-hover',
          glow && 'shadow-glass-glow border-brand-500/40',
          className
        )
      )}
      {...props}
    >
      {children}
    </div>
  );
}
