import React, { useState, useEffect } from 'react';
import { Layers, Cpu, HardDrive } from 'lucide-react';

export default function CustomResourcePicker({
  ram,
  setRam,
  cpus,
  setCpus,
  diskSize,
  setDiskSize,
  disabled = false
}) {
  // RAM internal state
  const parseRamToMb = (val) => {
    const s = String(val || '1G').trim().toUpperCase();
    if (s.endsWith('M')) return parseInt(s, 10) || 1024;
    if (s.endsWith('G')) return Math.round((parseFloat(s) || 1) * 1024);
    const num = parseFloat(s);
    return isNaN(num) ? 1024 : Math.round(num >= 32 ? num : num * 1024);
  };

  const parseDiskToGb = (val) => {
    const s = String(val || '10G').trim().toUpperCase();
    if (s.endsWith('T')) return Math.round((parseFloat(s) || 1) * 1024);
    if (s.endsWith('G')) return parseInt(s, 10) || 10;
    const num = parseInt(s, 10);
    return isNaN(num) ? 10 : num;
  };

  const [ramMb, setRamMb] = useState(parseRamToMb(ram));
  const [cpuVal, setCpuVal] = useState(Math.max(1, Math.round(parseFloat(cpus) || 1)));
  const [diskGb, setDiskGb] = useState(parseDiskToGb(diskSize));

  // Sync internal slider/input states whenever external props change (e.g. clicking Plan Presets)
  useEffect(() => {
    setRamMb(parseRamToMb(ram));
  }, [ram]);

  useEffect(() => {
    setCpuVal(Math.max(1, Math.round(parseFloat(cpus) || 1)));
  }, [cpus]);

  useEffect(() => {
    setDiskGb(parseDiskToGb(diskSize));
  }, [diskSize]);

  // Sync state changes back up
  const handleRamChange = (mb) => {
    const safeMb = Math.max(256, Math.min(65536, parseInt(mb, 10) || 1024));
    setRamMb(safeMb);
    if (safeMb % 1024 === 0) {
      setRam(`${safeMb / 1024}G`);
    } else {
      setRam(`${safeMb}M`);
    }
  };

  const handleCpuChange = (c) => {
    // Only whole numbers (1, 2, 3, 4, 6, 8, etc.)
    const safeC = Math.max(1, Math.min(64, Math.round(parseFloat(c) || 1)));
    setCpuVal(safeC);
    setCpus(String(safeC));
  };

  const handleDiskChange = (gb) => {
    const safeGb = Math.max(5, Math.min(2048, parseInt(gb, 10) || 10));
    setDiskGb(safeGb);
    if (safeGb >= 1024 && safeGb % 1024 === 0) {
      setDiskSize(`${safeGb / 1024}T`);
    } else {
      setDiskSize(`${safeGb}G`);
    }
  };

  const ramPresets = [
    { label: '512M', mb: 512 },
    { label: '1G', mb: 1024 },
    { label: '2G', mb: 2048 },
    { label: '4G', mb: 4096 },
    { label: '8G', mb: 8192 },
    { label: '16G', mb: 16384 },
    { label: '32G', mb: 32768 }
  ];

  const cpuPresets = [
    { label: '1 Core', val: 1 },
    { label: '2 Cores', val: 2 },
    { label: '3 Cores', val: 3 },
    { label: '4 Cores', val: 4 },
    { label: '6 Cores', val: 6 },
    { label: '8 Cores', val: 8 },
    { label: '12 Cores', val: 12 },
    { label: '16 Cores', val: 16 }
  ];

  const diskPresets = [
    { label: '10G', gb: 10 },
    { label: '20G', gb: 20 },
    { label: '40G', gb: 40 },
    { label: '80G', gb: 80 },
    { label: '160G', gb: 160 },
    { label: '320G', gb: 320 },
    { label: '500G', gb: 500 },
    { label: '1T', gb: 1024 }
  ];

  return (
    <div className={`grid grid-cols-1 lg:grid-cols-3 gap-5 ${disabled ? 'opacity-70 pointer-events-none select-none' : ''}`}>
      {/* 1. RAM MEMORY */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">RAM Memory</span>
              <span className="text-[10px] text-slate-500 font-mono">Launch: $RAM</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
              {ramMb >= 1024 ? `${(ramMb / 1024).toFixed(ramMb % 1024 === 0 ? 0 : 1)} GB` : `${ramMb} MB`}
            </span>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-1.5">
          {ramPresets.map((p) => (
            <button
              key={p.label}
              type="button"
              disabled={disabled}
              onClick={() => handleRamChange(p.mb)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold border transition-all ${
                ramMb === p.mb
                  ? 'bg-purple-500 text-white border-purple-500 shadow-md shadow-purple-500/20'
                  : 'bg-black/30 border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
              } ${disabled ? 'cursor-not-allowed' : ''}`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Interactive Slider */}
        <div className="space-y-1 pt-1">
          <input
            type="range"
            min="256"
            max="32768"
            step="256"
            disabled={disabled}
            value={ramMb}
            onChange={(e) => handleRamChange(e.target.value)}
            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500 disabled:cursor-not-allowed"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>256 MB</span>
            <span>16 GB</span>
            <span>32 GB</span>
          </div>
        </div>

        {/* Custom Direct Input */}
        <div className="flex items-center gap-2 pt-1 border-t border-white/5">
          <span className="text-[10px] text-slate-400 font-sans uppercase">Custom:</span>
          <input
            type="number"
            min="256"
            max="65536"
            step="1"
            disabled={disabled}
            value={ramMb}
            onChange={(e) => handleRamChange(e.target.value)}
            className="flex-1 px-2.5 py-1 rounded-lg bg-black/50 border border-white/10 text-purple-300 font-mono text-xs focus:outline-none focus:border-purple-500 disabled:cursor-not-allowed"
          />
          <span className="text-xs font-mono text-slate-400">MB</span>
        </div>
      </div>

      {/* 2. CPU CORES (WHOLE NUMBERS ONLY: 1, 2, 3, 4, 6, 8, etc.) */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">CPU Allocation</span>
              <span className="text-[10px] text-slate-500 font-mono">Launch: $CPUS</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              {cpuVal} {cpuVal === 1 ? 'Core' : 'Cores'}
            </span>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-1.5">
          {cpuPresets.map((p) => (
            <button
              key={p.label}
              type="button"
              disabled={disabled}
              onClick={() => handleCpuChange(p.val)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold border transition-all ${
                cpuVal === p.val
                  ? 'bg-cyan-500 text-white border-cyan-500 shadow-md shadow-cyan-500/20'
                  : 'bg-black/30 border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
              } ${disabled ? 'cursor-not-allowed' : ''}`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Interactive Slider */}
        <div className="space-y-1 pt-1">
          <input
            type="range"
            min="1"
            max="32"
            step="1"
            disabled={disabled}
            value={cpuVal}
            onChange={(e) => handleCpuChange(e.target.value)}
            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-cyan-500 disabled:cursor-not-allowed"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>1 Core</span>
            <span>16 Cores</span>
            <span>32 Cores</span>
          </div>
        </div>

        {/* Custom Direct Input (Whole Numbers Only) */}
        <div className="flex items-center gap-2 pt-1 border-t border-white/5">
          <span className="text-[10px] text-slate-400 font-sans uppercase">Custom:</span>
          <input
            type="number"
            step="1"
            min="1"
            max="64"
            disabled={disabled}
            value={cpuVal}
            onChange={(e) => handleCpuChange(e.target.value)}
            className="flex-1 px-2.5 py-1 rounded-lg bg-black/50 border border-white/10 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-500 disabled:cursor-not-allowed"
          />
          <span className="text-xs font-mono text-slate-400">Cores</span>
        </div>
      </div>

      {/* 3. DISK SSD STORAGE */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Disk / SSD Storage</span>
              <span className="text-[10px] text-slate-500 font-mono">Launch: $DISK_SIZE</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              {diskGb >= 1024 ? `${(diskGb / 1024).toFixed(diskGb % 1024 === 0 ? 0 : 1)} TB` : `${diskGb} GB`}
            </span>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-1.5">
          {diskPresets.map((p) => (
            <button
              key={p.label}
              type="button"
              disabled={disabled}
              onClick={() => handleDiskChange(p.gb)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold border transition-all ${
                diskGb === p.gb
                  ? 'bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-500/20'
                  : 'bg-black/30 border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
              } ${disabled ? 'cursor-not-allowed' : ''}`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Interactive Slider */}
        <div className="space-y-1 pt-1">
          <input
            type="range"
            min="10"
            max="1024"
            step="10"
            disabled={disabled}
            value={diskGb}
            onChange={(e) => handleDiskChange(e.target.value)}
            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-emerald-500 disabled:cursor-not-allowed"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>10 GB</span>
            <span>500 GB</span>
            <span>1 TB</span>
          </div>
        </div>

        {/* Custom Direct Input */}
        <div className="flex items-center gap-2 pt-1 border-t border-white/5">
          <span className="text-[10px] text-slate-400 font-sans uppercase">Custom:</span>
          <input
            type="number"
            step="1"
            min="5"
            max="10240"
            disabled={disabled}
            value={diskGb}
            onChange={(e) => handleDiskChange(e.target.value)}
            className="flex-1 px-2.5 py-1 rounded-lg bg-black/50 border border-white/10 text-emerald-300 font-mono text-xs focus:outline-none focus:border-emerald-500 disabled:cursor-not-allowed"
          />
          <span className="text-xs font-mono text-slate-400">GB</span>
        </div>
      </div>
    </div>
  );
}
