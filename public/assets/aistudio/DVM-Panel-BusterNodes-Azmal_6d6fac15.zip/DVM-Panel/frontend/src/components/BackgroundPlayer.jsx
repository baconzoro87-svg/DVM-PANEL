import React from 'react';
import { useTheme } from '../context/ThemeContext';

export default function BackgroundPlayer() {
  const { settings } = useTheme();
  const bgType = settings.background_type || 'preset';
  const bgUrl = settings.background_url || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop';
  const isVideo = bgType === 'video_url' || (bgUrl && bgUrl.match(/\.(mp4|webm|mov)(\?.*)?$/i));

  return (
    <div className="fixed inset-0 pointer-events-none -z-50 overflow-hidden bg-dark-950">
      {isVideo ? (
        <video
          key={bgUrl}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        >
          <source src={bgUrl} type="video/mp4" />
          <source src={bgUrl} type="video/webm" />
        </video>
      ) : (
        <div
          key={bgUrl}
          className="absolute inset-0 w-full h-full bg-cover bg-center transition-all duration-700 opacity-60"
          style={{
            backgroundImage: `url("${bgUrl}")`,
            backgroundAttachment: 'fixed'
          }}
        />
      )}

      {/* Dark gradient & Vignette overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-dark-950 via-dark-950/70 to-dark-950/40" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-transparent via-dark-950/50 to-dark-950/90" />
    </div>
  );
}
