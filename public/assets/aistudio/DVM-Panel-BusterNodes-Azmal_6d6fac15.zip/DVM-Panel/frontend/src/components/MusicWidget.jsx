import React, { useState } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, Repeat, X, ChevronUp, ChevronDown } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function MusicWidget() {
  const {
    settings,
    audioRef,
    isPlaying,
    audioVolume,
    handleVolumeChange,
    isMuted,
    toggleMute,
    isLooping,
    setIsLooping,
    togglePlay,
    musicWidgetVisible,
    setMusicWidgetVisible
  } = useTheme();

  const [minimized, setMinimized] = useState(false);

  const isMusicEnabled = settings.music_enabled === 'true' || settings.music_enabled === true;
  const musicUrl = settings.music_url;

  if (!isMusicEnabled || !musicUrl || !musicWidgetVisible) {
    return (
      <audio
        ref={audioRef}
        src={musicUrl}
        loop={isLooping}
        preload="auto"
      />
    );
  }

  return (
    <>
      <audio
        ref={audioRef}
        src={musicUrl}
        loop={isLooping}
        preload="auto"
      />

      <div className="fixed bottom-5 right-5 z-40 transition-all duration-300">
        {minimized ? (
          <button
            onClick={() => setMinimized(false)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-full glass-panel shadow-glass text-slate-200 hover:text-white border border-brand-500/40 hover:border-brand-500 transition-all"
            title="Expand Music Player"
          >
            <div className={`w-2.5 h-2.5 rounded-full ${isPlaying ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
            <Music className="w-4 h-4 text-brand-400" />
            <span className="text-xs font-medium max-w-[120px] truncate">{settings.music_title || 'Audio'}</span>
            <ChevronUp className="w-3.5 h-3.5 opacity-60" />
          </button>
        ) : (
          <div className="w-80 rounded-2xl glass-panel shadow-glass p-3.5 border border-white/10 flex flex-col gap-2.5 backdrop-blur-xl animate-fade-in">
            {/* Header / Title */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-8 h-8 rounded-lg bg-brand-500/20 border border-brand-500/30 flex items-center justify-center text-brand-400 shrink-0">
                  <Music className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-semibold text-white truncate">{settings.music_title || 'Background Music'}</p>
                  <p className="text-[10px] text-slate-400 truncate">{isPlaying ? 'Playing • dpanel Audio' : 'Paused'}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setMinimized(true)}
                  className="p-1 rounded text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
                  title="Minimize"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setMusicWidgetVisible(false)}
                  className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-white/5 transition-colors"
                  title="Hide"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Controls Bar */}
            <div className="flex items-center justify-between gap-3 pt-1 border-t border-white/5">
              <div className="flex items-center gap-2">
                <button
                  onClick={togglePlay}
                  className="w-9 h-9 rounded-full bg-brand-500 hover:bg-brand-600 active:scale-95 text-white flex items-center justify-center shadow-md shadow-brand-500/20 transition-all"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>

                <button
                  onClick={() => setIsLooping(!isLooping)}
                  className={`p-1.5 rounded-lg transition-colors ${isLooping ? 'text-brand-400 bg-brand-500/10' : 'text-slate-500 hover:text-slate-300'}`}
                  title={isLooping ? 'Loop Enabled' : 'Loop Disabled'}
                >
                  <Repeat className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-2 flex-1 max-w-[140px]">
                <button
                  onClick={toggleMute}
                  className="text-slate-400 hover:text-white transition-colors"
                  title={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted || audioVolume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={isMuted ? 0 : audioVolume}
                  onChange={(e) => handleVolumeChange(parseInt(e.target.value, 10))}
                  className="w-full h-1.5 bg-slate-700/60 rounded-lg cursor-pointer appearance-none"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
