import React, { useEffect, useRef, useState } from 'react';
import { Terminal as XtermTerminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import {
  Terminal as TermIcon,
  Maximize2,
  Minimize2,
  RefreshCw,
  Trash2,
  Zap,
  Copy,
  Check,
  Eye,
  EyeOff,
  Radio,
  RotateCcw,
  ShieldCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Terminal({
  serverId,
  serverName,
  portSsh = 25501,
  sshUser = 'root',
  sshPassword = 'root'
}) {
  const { token } = useAuth();
  const [activeTab, setActiveTab] = useState('terminal'); // 'terminal' (SSH) or 'logs' (Real Live Logs)
  const [showPassword, setShowPassword] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);

  const terminalRef = useRef(null);
  const xtermInstance = useRef(null);
  const fitAddonRef = useRef(null);
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const sshCommand = `ssh -p ${portSsh} ${sshUser}@localhost`;

  const copyToClipboard = (text, type) => {
    navigator.clipboard.writeText(text);
    if (type === 'cmd') {
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2000);
    } else {
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
  };

  const restartTerminalSession = () => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      if (window.confirm('Are you sure you want to kill and restart this SSH terminal session?')) {
        socketRef.current.send(JSON.stringify({ type: 'restart_session' }));
        if (xtermInstance.current) {
          xtermInstance.current.clear();
          xtermInstance.current.writeln('\r\n\x1b[33m⚡ Restarting persistent SSH session...\x1b[0m\r\n');
        }
      }
    }
  };

  const initSession = (type = activeTab) => {
    if (!terminalRef.current) return;

    if (xtermInstance.current) {
      xtermInstance.current.dispose();
      xtermInstance.current = null;
    }
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }

    const isLogsMode = type === 'logs';

    const term = new XtermTerminal({
      cursorBlink: !isLogsMode,
      cursorStyle: isLogsMode ? 'underline' : 'block',
      fontSize: 13,
      fontFamily: '"Fira Code", "JetBrains Mono", Consolas, monospace',
      letterSpacing: 0,
      lineHeight: 1.2,
      convertEol: true,
      disableStdin: isLogsMode,
      theme: {
        background: '#07090e',
        foreground: isLogsMode ? '#a5f3fc' : '#e2e8f0',
        cursor: isLogsMode ? 'transparent' : '#6366f1',
        cursorAccent: '#07090e',
        selectionBackground: 'rgba(99, 102, 241, 0.4)',
        black: '#121620',
        red: '#f87171',
        green: '#4ade80',
        yellow: '#fbbf24',
        blue: '#60a5fa',
        magenta: '#c084fc',
        cyan: '#38bdf8',
        white: '#f8fafc',
        brightBlack: '#475569',
        brightRed: '#ef4444',
        brightGreen: '#22c55e',
        brightYellow: '#f59e0b',
        brightBlue: '#3b82f6',
        brightMagenta: '#a855f7',
        brightCyan: '#0ea5e9',
        brightWhite: '#ffffff'
      }
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(terminalRef.current);

    setTimeout(() => {
      try {
        fitAddon.fit();
        if (!isLogsMode) term.focus();
      } catch (e) {}
    }, 100);

    xtermInstance.current = term;
    fitAddonRef.current = fitAddon;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const path = isLogsMode ? '/ws/logs' : '/ws/terminal';
    const wsUrl = `${protocol}//${host}${path}?serverId=${serverId}&token=${token}`;

    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      try {
        fitAddon.fit();
        if (!isLogsMode) {
          term.focus();
          ws.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
        }
      } catch (e) {}
    };

    ws.onmessage = (event) => {
      term.write(event.data);
    };

    ws.onclose = () => {
      setConnected(false);
      term.writeln(`\r\n\x1b[31m✖ Disconnected from ${isLogsMode ? 'logs stream' : 'VM SSH stream'}.\x1b[0m\r\n`);
    };

    ws.onerror = () => {
      setConnected(false);
      term.writeln(`\r\n\x1b[31m✖ Connection error on ${wsUrl}\x1b[0m\r\n`);
    };

    if (!isLogsMode) {
      term.onData((data) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'input', data }));
        }
      });

      term.onResize(({ cols, rows }) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'resize', cols, rows }));
        }
      });
    }
  };

  useEffect(() => {
    initSession(activeTab);

    const handleResize = () => {
      if (fitAddonRef.current) {
        try {
          fitAddonRef.current.fit();
        } catch (e) {}
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      if (xtermInstance.current) xtermInstance.current.dispose();
      if (socketRef.current) socketRef.current.close();
    };
  }, [serverId, token, activeTab]);

  const sendQuickCommand = (cmd) => {
    if (activeTab === 'terminal' && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'input', data: `${cmd}\n` }));
      if (xtermInstance.current) xtermInstance.current.focus();
    }
  };

  const clearScreen = () => {
    if (xtermInstance.current) {
      xtermInstance.current.clear();
      if (activeTab === 'terminal') xtermInstance.current.focus();
    }
  };

  return (
    <div className={`flex flex-col glass-card border border-white/10 rounded-2xl overflow-hidden transition-all duration-300 ${isFullScreen ? 'fixed inset-4 z-50 shadow-2xl' : 'h-[630px]'}`}>
      {/* Top SSH Credentials Bar */}
      <div className="px-4 py-2.5 bg-black/60 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-xl border border-white/10">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">SSH Command:</span>
            <code className="text-brand-300 font-mono font-bold">{sshCommand}</code>
            <button
              type="button"
              onClick={() => copyToClipboard(sshCommand, 'cmd')}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Copy SSH Command"
            >
              {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center gap-2 bg-black/50 px-3 py-1.5 rounded-xl border border-white/10">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Password:</span>
            <code className="text-amber-300 font-mono font-bold">
              {showPassword ? sshPassword : '••••••••'}
            </code>
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title={showPassword ? 'Hide Password' : 'Show Password'}
            >
              {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => copyToClipboard(sshPassword, 'pass')}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Copy Password"
            >
              {copiedPass ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <span className="hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold border border-emerald-500/20">
            <ShieldCheck className="w-3.5 h-3.5" />
            24/7 Background Persistent Shell
          </span>
        </div>

        {/* View Switcher: Real SSH vs Live Logs */}
        <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'terminal' ? 'bg-brand-500 text-white shadow-md shadow-brand-500/25' : 'text-slate-400 hover:text-white'
            }`}
          >
            <TermIcon className="w-3.5 h-3.5" />
            <span>Real SSH Terminal</span>
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'logs' ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/25' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3.5 h-3.5 animate-pulse text-rose-400" />
            <span>Live Real VM Logs</span>
          </button>
        </div>
      </div>

      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-dark-900/80 border-b border-white/10 select-none">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
          </div>
          <div className="flex items-center gap-2 pl-2 border-l border-white/10 font-mono text-xs">
            <span className="text-slate-200 font-bold">
              {activeTab === 'terminal' ? `ssh://${sshUser}@localhost:${portSsh}` : `vm-logs://${serverName} (real-time stream)`}
            </span>
            <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
              connected ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300'
            }`}>
              {connected ? 'CONNECTED (PERSISTENT)' : 'RECONNECTING'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {activeTab === 'terminal' && (
            <button
              onClick={restartTerminalSession}
              className="flex items-center gap-1 px-2 py-1 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 text-[11px] font-semibold transition-colors"
              title="Kill and restart active terminal shell session"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Session</span>
            </button>
          )}

          <button
            onClick={() => initSession(activeTab)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Reconnect view"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={clearScreen}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Clear Screen"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setIsFullScreen(!isFullScreen);
              setTimeout(() => {
                try {
                  fitAddonRef.current?.fit();
                  xtermInstance.current?.focus();
                } catch (e) {}
              }, 200);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title={isFullScreen ? 'Exit Full Screen' : 'Full Screen'}
          >
            {isFullScreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Terminal Canvas */}
      <div
        className="flex-1 bg-[#07090e] p-2 overflow-hidden terminal-container cursor-text"
        ref={terminalRef}
        onClick={() => {
          if (activeTab === 'terminal' && xtermInstance.current) {
            xtermInstance.current.focus();
          }
        }}
      />

      {/* Quick Commands */}
      {activeTab === 'terminal' && (
        <div className="flex items-center gap-2 px-3 py-2 bg-dark-900/60 border-t border-white/5 overflow-x-auto text-xs">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 shrink-0">
            <Zap className="w-3 text-amber-400" /> Quick Commands:
          </span>
          <button onClick={() => sendQuickCommand('clear')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            clear
          </button>
          <button onClick={() => sendQuickCommand('ls -la')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            ls -la
          </button>
          <button onClick={() => sendQuickCommand('df -h')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            df -h
          </button>
          <button onClick={() => sendQuickCommand('free -m')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            free -m
          </button>
          <button onClick={() => sendQuickCommand('uname -a')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            uname -a
          </button>
          <button onClick={() => sendQuickCommand('cat /etc/os-release')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            os-release
          </button>
          <button onClick={() => sendQuickCommand('top')} className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 font-mono text-[11px] shrink-0">
            top
          </button>
        </div>
      )}
    </div>
  );
}
