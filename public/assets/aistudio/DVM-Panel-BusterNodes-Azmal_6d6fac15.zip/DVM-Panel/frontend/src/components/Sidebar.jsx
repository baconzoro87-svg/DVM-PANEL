import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Server,
  PlusCircle,
  Shield,
  Users,
  Settings,
  Activity,
  LifeBuoy,
  User,
  BookOpen,
  Layers,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ isOpen, onClose }) {
  const { isAdmin, user } = useAuth();

  const navItemClass = ({ isActive }) =>
    `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
      isActive
        ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/25'
        : 'text-slate-400 hover:text-slate-100 hover:bg-white/5'
    }`;

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-16 bottom-0 left-0 w-64 glass-sidebar p-4 z-30 flex flex-col justify-between transition-transform duration-300 select-none overflow-y-auto lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="space-y-6">
          <div className="flex items-center justify-between lg:hidden pb-2 border-b border-white/10">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Navigation</span>
            <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div>
            <div className="px-3 mb-2 flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">User Dashboard</span>
            </div>
            <nav className="space-y-1">
              <NavLink to="/" end className={navItemClass} onClick={onClose}>
                <Server className="w-4 h-4" />
                <span>My Servers / VMs</span>
              </NavLink>
              <NavLink to="/servers/create" className={navItemClass} onClick={onClose}>
                <PlusCircle className="w-4 h-4 text-emerald-400" />
                <span>Create VM</span>
              </NavLink>
              <NavLink to="/plans" className={navItemClass} onClick={onClose}>
                <Layers className="w-4 h-4 text-purple-400" />
                <span>Plans & Quotas</span>
              </NavLink>
              <NavLink to="/profile" className={navItemClass} onClick={onClose}>
                <User className="w-4 h-4 text-cyan-400" />
                <span>Account Profile</span>
              </NavLink>
              <NavLink to="/tickets" className={navItemClass} onClick={onClose}>
                <LifeBuoy className="w-4 h-4 text-amber-400" />
                <span>Support Tickets</span>
              </NavLink>
            </nav>
          </div>

          {isAdmin && (
            <div className="pt-4 border-t border-white/10">
              <div className="px-3 mb-2 flex items-center justify-between">
                <span className="text-[11px] font-bold text-brand-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" /> Admin Control
                </span>
              </div>
              <nav className="space-y-1">
                <NavLink to="/admin" end className={navItemClass} onClick={onClose}>
                  <Activity className="w-4 h-4 text-purple-400" />
                  <span>Dashboard (Monitoring)</span>
                </NavLink>
                <NavLink to="/admin/servers" className={navItemClass} onClick={onClose}>
                  <Server className="w-4 h-4 text-blue-400" />
                  <span>Server Management</span>
                </NavLink>
                <NavLink to="/admin/servers/create" className={navItemClass} onClick={onClose}>
                  <PlusCircle className="w-4 h-4 text-emerald-400" />
                  <span>Create Server (Admin)</span>
                </NavLink>
                <NavLink to="/admin/users" className={navItemClass} onClick={onClose}>
                  <Users className="w-4 h-4 text-amber-400" />
                  <span>User Management</span>
                </NavLink>
                <NavLink to="/admin/settings" className={navItemClass} onClick={onClose}>
                  <Settings className="w-4 h-4 text-rose-400" />
                  <span>Settings & Appearance</span>
                </NavLink>
                <NavLink to="/admin/docs" className={navItemClass} onClick={onClose}>
                  <BookOpen className="w-4 h-4 text-teal-400" />
                  <span>Documentation</span>
                </NavLink>
              </nav>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-white/10">
          <NavLink
            to="/plans"
            onClick={onClose}
            className="block p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group"
          >
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3 h-3 text-purple-400" /> Account Quotas
              </p>
              <span className="text-[9px] text-purple-400 group-hover:underline">View Plans →</span>
            </div>
            <div className="mt-1.5 text-[10px] text-slate-400 space-y-1">
              <div className="flex justify-between">
                <span>Max VMs:</span>
                <span className="text-slate-200 font-mono">{user?.max_servers || 3}</span>
              </div>
              <div className="flex justify-between">
                <span>RAM Limit:</span>
                <span className="text-slate-200 font-mono">{user?.ram_limit || '2G'}</span>
              </div>
              <div className="flex justify-between">
                <span>CPU Cores:</span>
                <span className="text-slate-200 font-mono">{user?.cpu_limit || 2} Cores</span>
              </div>
              <div className="flex justify-between">
                <span>Storage:</span>
                <span className="text-slate-200 font-mono">{user?.disk_limit || '20G'}</span>
              </div>
            </div>
          </NavLink>
        </div>
      </aside>
    </>
  );
}
