import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../utils/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('dpanel_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState(() => localStorage.getItem('dpanel_token'));
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const res = await api.get('/auth/me');
      if (res.success && res.user) {
        setUser(res.user);
        localStorage.setItem('dpanel_user', JSON.stringify(res.user));
      }
    } catch (err) {
      console.warn('Session expired:', err.message);
      logout();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, [token]);

  const login = async (identifier, password, twoFactorCode = null) => {
    const res = await api.post('/auth/login', { identifier, password, twoFactorCode });
    if (res.require2FA) {
      return { require2FA: true, userId: res.userId, message: res.message };
    }
    if (res.success && res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('dpanel_token', res.token);
      localStorage.setItem('dpanel_user', JSON.stringify(res.user));
      return { success: true, user: res.user };
    }
    throw new Error(res.message || 'Login failed');
  };

  const verify2FALogin = async (userId, code) => {
    const res = await api.post('/auth/2fa/verify', { userId, code });
    if (res.success && res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('dpanel_token', res.token);
      localStorage.setItem('dpanel_user', JSON.stringify(res.user));
      return { success: true, user: res.user };
    }
    throw new Error(res.message || '2FA verification failed');
  };

  const register = async (username, email, password) => {
    const res = await api.post('/auth/register', { username, email, password });
    if (res.success && res.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('dpanel_token', res.token);
      localStorage.setItem('dpanel_user', JSON.stringify(res.user));
      return { success: true, user: res.user };
    }
    throw new Error(res.message || 'Registration failed');
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('dpanel_token');
    localStorage.removeItem('dpanel_user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isAuthenticated: !!token && !!user,
      isAdmin: user?.role === 'admin',
      loading,
      login,
      verify2FALogin,
      register,
      logout,
      refreshUser,
      setUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
