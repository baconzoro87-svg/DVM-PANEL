import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { api } from '../utils/api';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [settings, setSettings] = useState({
    panel_name: 'dpanel',
    panel_logo: '',
    panel_logo_url: '',
    panel_favicon_name: 'dpanel',
    panel_favicon_url: '',
    background_type: 'preset',
    background_url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop',
    background_category: 'black-dark',
    music_enabled: 'false',
    music_type: 'url',
    music_url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3',
    music_title: 'Ambient Synthwave',
    music_volume: '45',
    music_autoplay: 'false',
    transparency: '75',
    blur: '14',
    theme: 'dark-glass',
    accent_color: '#6366f1',
    custom_css: '',
    register_enabled: 'true',
    require_2fa: 'false',
    social_discord: 'https://discord.gg/',
    social_telegram: 'https://t.me/',
    social_github: 'https://github.com/'
  });

  const [wallpaperCategories, setWallpaperCategories] = useState([]);
  const [supportedImages, setSupportedImages] = useState([]);
  const [loading, setLoading] = useState(true);

  // Audio player state
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioVolume, setAudioVolume] = useState(45);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(true);
  const [musicWidgetVisible, setMusicWidgetVisible] = useState(true);
  const audioRef = useRef(null);

  const fetchPublicSettings = async () => {
    try {
      const res = await api.get('/settings/public');
      if (res.success && res.settings) {
        setSettings(prev => ({ ...prev, ...res.settings }));
        if (res.wallpaperCategories) setWallpaperCategories(res.wallpaperCategories);
        if (res.supportedImages) setSupportedImages(res.supportedImages);
        if (res.settings.music_volume) setAudioVolume(parseInt(res.settings.music_volume, 10));
      }
    } catch (err) {
      console.warn('Failed to load public settings:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPublicSettings();
  }, []);

  // Apply CSS Variables and Document Title/Favicon
  useEffect(() => {
    const root = document.documentElement;

    // 1. Transparency slider (0 to 100) -> 0.0 to 1.0 opacity
    const rawTrans = parseInt(settings.transparency || '75', 10);
    const opacity = Math.max(0.05, Math.min(1, rawTrans / 100));
    root.style.setProperty('--panel-opacity', opacity.toFixed(2));

    // 2. Blur slider (0 to 30) -> 0px to 30px
    const rawBlur = parseInt(settings.blur || '14', 10);
    root.style.setProperty('--panel-blur', `${rawBlur}px`);

    // 3. Accent Color
    if (settings.accent_color) {
      root.style.setProperty('--brand-color', settings.accent_color);
    }

    // 4. Update Document Title
    const panelName = settings.panel_name || 'DVM Panel';
    document.title = `${panelName} - VM Management`;

    // 5. Update Favicon
    const faviconLink = document.getElementById('dynamic-favicon');
    if (faviconLink) {
      if (settings.panel_favicon_url) {
        faviconLink.href = settings.panel_favicon_url;
      } else {
        faviconLink.href = '/favicon.svg';
      }
    }

    // 6. Custom CSS Inject
    let styleTag = document.getElementById('dpanel-custom-css');
    if (!styleTag) {
      styleTag = document.createElement('style');
      styleTag.id = 'dpanel-custom-css';
      document.head.appendChild(styleTag);
    }
    styleTag.innerHTML = settings.custom_css || '';

  }, [settings]);

  // Audio Control Handlers
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(e => console.warn('Audio play blocked:', e));
    }
  };

  const handleVolumeChange = (newVol) => {
    setAudioVolume(newVol);
    if (audioRef.current) {
      audioRef.current.volume = newVol / 100;
      if (newVol > 0 && isMuted) setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    audioRef.current.muted = nextMute;
  };

  const updateSettingsLocally = (partial) => {
    setSettings(prev => ({ ...prev, ...partial }));
  };

  const effectiveLogo = settings.panel_logo || settings.panel_logo_url;

  return (
    <ThemeContext.Provider value={{
      settings,
      effectiveLogo,
      wallpaperCategories,
      supportedImages,
      loading,
      updateSettingsLocally,
      fetchPublicSettings,
      // Audio controls
      audioRef,
      isPlaying,
      setIsPlaying,
      audioVolume,
      handleVolumeChange,
      isMuted,
      toggleMute,
      isLooping,
      setIsLooping,
      togglePlay,
      musicWidgetVisible,
      setMusicWidgetVisible
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
}
