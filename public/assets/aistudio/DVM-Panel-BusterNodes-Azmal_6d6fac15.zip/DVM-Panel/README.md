# DVM Panel — BusterNodes Docker VM Management

DVM Panel by BusterNodes (Made by Azmal) is a high-performance, full-stack web panel for managing Docker-based virtual machines through a clean browser interface. Built with a React + Tailwind + Xterm frontend and a Node.js + Express + SQLite backend using `ssh2` for container terminal access.

## Features

- **Full VM Lifecycle** — create, start, stop, restart, and destroy Docker-based VMs
- **Web Terminal** — in-browser console via Xterm over SSH (`ssh2`)
- **File Manager** — browse, upload, download, and edit container files
- **Backups** — create and restore container backups
- **Scheduler** — scheduled tasks for VM operations
- **Network & Ports** — SSH port pool management (`25501-25599`)
- **Roles** — Admin, Reseller, and User tiers
- **Tickets** — support tickets between users and admins
- **Wallpapers & Media** — per-VM background and media widgets
- **Statistics & Activity** — analytics and live activity logs

## Tech Stack

| Layer      | Tech |
|------------|------|
| Frontend   | React, Vite, Tailwind CSS, Xterm.js |
| Backend    | Node.js, Express, `ssh2`, SQLite (node:sqlite) |
| Orchestration | Docker |
| Process Mgmt | PM2 |

## Requirements

- **systemd is not required.** Panel processes run through PM2 and the installer does not use systemctl.
- Docker daemon must be available; the installer tries service/init scripts or a direct `dockerd` launch where supported.


- **Node.js** 18+ (20 LTS recommended)
- **Docker** (daemon running)
- **PM2** (installed automatically)
- Linux (Debian/Ubuntu, RHEL, Alpine supported)

## Quick Start

### One-command install

```bash
bash run.sh install
```

This checks and installs Node.js, PM2, and Docker as needed, installs backend/frontend dependencies, builds the production bundle, initializes the SQLite database, and starts services via PM2.

### Interactive menu

```bash
bash run.sh
```

### CLI commands

```bash
bash run.sh install       # Full fresh setup & start
bash run.sh update        # Pull latest code, rebuild & restart
bash run.sh start         # Start web & api services
bash run.sh stop          # Stop background services
bash run.sh restart       # Restart all processes
bash run.sh status        # Health, ports & containers
bash run.sh logs          # Stream PM2 logs
bash run.sh reset-admin   # Reset admin / create user
bash run.sh uninstall     # Clean removal
```

### npm scripts

```bash
npm run install:all    # Install backend + frontend dependencies
npm run build          # Build frontend production bundle
npm start              # Run via Node (no process manager)
npm run dev            # Development mode
npm run createuser     # Create / reset a user
npm run pm2:start      # Start via PM2 (ecosystem.config.js)
npm run pm2:stop       # Stop PM2 processes
npm run pm2:restart    # Restart PM2 processes
npm run pm2:logs       # Stream PM2 logs
```

## Default Ports & Credentials

| Item | Value |
|------|-------|
| Web Panel | `http://<server-ip>:3001` |
| API Backend | `http://<server-ip>:3002` |
| SSH Port Pool | `25501-25599` |
| Default Admin | `admin@dpanel.io` / username `admin` |
| Default Password | `admin123` |
| Default VM SSH | `root:root` |

> **Security note:** Change the default admin password and VM SSH credentials immediately after first login.

## Default VM Images

The panel pre-pulls these default Linux VM images in the background:

- `nobitaa/ubuntu:22`
- `nobitaa/ubuntu:24`
- `nobitaa/debain:11`
- `nobitaa/debain:12`
- `nobitaa/debain:13`

## Project Structure

```
.
├── backend/
│   ├── src/
│   │   ├── db/            # SQLite database & models
│   │   ├── routes/        # API routes (auth, servers, admin, users, ...)
│   │   ├── services/      # Docker, SSH, backup, scheduler, stats, ...
│   │   ├── middleware/    # Auth & upload middleware
│   │   ├── utils/         # Ports & security helpers
│   │   └── server.js      # Express API server (port 3002)
├── frontend/
│   ├── src/
│   │   ├── pages/         # Admin, Reseller, User, Auth pages
│   │   ├── components/    # Terminal, FileEditor, Navbar, Sidebar, ...
│   │   ├── context/       # Auth & Theme context
│   │   └── utils/
│   └── server.js          # Static + proxy web server (port 3001)
├── data/                  # Runtime data, uploads, backups, SQLite
├── scripts/               # start-all / dev helpers
├── ecosystem.config.js    # PM2 configuration
└── run.sh                 # Install / update / lifecycle CLI
```

## License

MIT


---

**DVM Panel · BusterNodes**  
Made by Azmal
