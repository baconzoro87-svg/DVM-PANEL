#!/usr/bin/env bash
# ==============================================================================
#  DVM Panel | BusterNodes VM Management CLI
#  Full Installation, Update, Uninstallation, and Lifecycle Management Script
#  Optimized for Ubuntu, Debian & Linux Systems
# ==============================================================================

set -e

# ANSI Color Codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m' # No Color

PANEL_NAME="DVM Panel"
WEB_PORT=3001
API_PORT=3002
SSH_PORT_RANGE="25501-25599"

# Non-interactive settings for apt
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

# ------------------------------------------------------------------------------
# Privilege & Sudo Configuration
# ------------------------------------------------------------------------------
if [ "$EUID" -eq 0 ]; then
  SUDO_CMD=""
  TARGET_USER="${SUDO_USER:-root}"
elif command -v sudo &>/dev/null; then
  SUDO_CMD="sudo"
  TARGET_USER="$USER"
else
  SUDO_CMD=""
  TARGET_USER="$USER"
fi

# ------------------------------------------------------------------------------
# Resolve Working Directory
# ------------------------------------------------------------------------------
resolve_project_dir() {
  local script_dir
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"
  
  if [ -f "$script_dir/backend/src/server.js" ] && [ -f "$script_dir/frontend/server.js" ]; then
    cd "$script_dir"
  elif [ -f "$script_dir/dpanel/backend/src/server.js" ]; then
    cd "$script_dir/dpanel"
  elif [ -f "$(pwd)/backend/src/server.js" ]; then
    cd "$(pwd)"
  elif [ -f "$(pwd)/dpanel/backend/src/server.js" ]; then
    cd "$(pwd)/dpanel"
  fi
}

resolve_project_dir

# ------------------------------------------------------------------------------
# Output & Logging Helpers
# ------------------------------------------------------------------------------
print_banner() {
  clear 2>/dev/null || true
  echo -e "${CYAN}${BOLD}"
  echo "  ██████╗ ██╗   ██╗███╗   ███╗"
  echo "  ██╔══██╗██║   ██║████╗ ████║"
  echo "  ██║  ██║██║   ██║██╔████╔██║"
  echo "  ██║  ██║╚██╗ ██╔╝██║╚██╔╝██║"
  echo "  ██████╔╝ ╚████╔╝ ██║ ╚═╝ ██║"
  echo "  ╚═════╝   ╚═══╝  ╚═╝     ╚═╝"
  echo -e "${PURPLE}  — DVM Panel | BusterNodes — Made by Azmal —${NC}"
  echo -e "${WHITE}  Web Port: ${CYAN}${WEB_PORT}${WHITE} | API Port: ${CYAN}${API_PORT}${WHITE} | SSH Ports: ${CYAN}${SSH_PORT_RANGE}${NC}\n"
}

log_info() {
  echo -e "${CYAN}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

# ------------------------------------------------------------------------------
# PM2 Execution Wrapper
# ------------------------------------------------------------------------------
pm2_cmd() {
  if command -v pm2 &> /dev/null; then
    pm2 "$@"
  elif [ -f "./node_modules/.bin/pm2" ]; then
    ./node_modules/.bin/pm2 "$@"
  elif [ -f "../node_modules/.bin/pm2" ]; then
    ../node_modules/.bin/pm2 "$@"
  elif command -v npx &> /dev/null; then
    npx -y pm2 "$@"
  else
    if [ -n "$SUDO_CMD" ]; then
      $SUDO_CMD npm install -g pm2 2>/dev/null || npm install pm2 --save-dev
    else
      npm install -g pm2 2>/dev/null || npm install pm2 --save-dev
    fi
    if command -v pm2 &> /dev/null; then
      pm2 "$@"
    else
      npx -y pm2 "$@"
    fi
  fi
}

# ------------------------------------------------------------------------------
# Detect Server Public / Local IP
# ------------------------------------------------------------------------------
get_server_ip() {
  local ip
  ip=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || curl -s --max-time 3 https://ifconfig.me 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')
  echo "${ip:-localhost}"
}

# ------------------------------------------------------------------------------
# Check Privileges
# ------------------------------------------------------------------------------
check_privileges() {
  if [ "$EUID" -ne 0 ] && [ -z "$SUDO_CMD" ]; then
    log_warn "Running as non-root user without sudo. Package and Docker installations may require manual privileges."
  fi
}

# ------------------------------------------------------------------------------
# Ensure Repository Exists
# ------------------------------------------------------------------------------
ensure_repo() {
  resolve_project_dir
  if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    log_error "DVM Panel source files were not found in this directory."
    log_info "Extract the DVM Panel archive first, then run ./run.sh from its root."
    exit 1
  fi
}

# ------------------------------------------------------------------------------
# Install Base Prerequisites (curl, wget, git, build tools, ca-certificates)
# ------------------------------------------------------------------------------
install_prerequisites() {
  log_info "Installing core system tools & prerequisites for Ubuntu/Debian..."
  if command -v apt-get &> /dev/null; then
    $SUDO_CMD apt-get update -qq || true
    $SUDO_CMD apt-get install -y -qq \
      curl wget git ca-certificates gnupg lsb-release \
      build-essential python3 make gcc g++ tar lsof psmisc procps || true
  elif command -v dnf &> /dev/null; then
    $SUDO_CMD dnf install -y curl wget git ca-certificates gnupg make gcc gcc-c++ python3 tar lsof psmisc procps-ng || true
  elif command -v yum &> /dev/null; then
    $SUDO_CMD yum install -y curl wget git ca-certificates gnupg make gcc gcc-c++ python3 tar lsof psmisc procps-ng || true
  elif command -v apk &> /dev/null; then
    $SUDO_CMD apk add --no-cache curl wget git ca-certificates gnupg make gcc g++ python3 tar lsof || true
  fi
}

# ------------------------------------------------------------------------------
# Check & Install Node.js 22 LTS (with native node:sqlite support)
# ------------------------------------------------------------------------------
check_nodejs() {
  log_info "Checking Node.js runtime environment..."
  local need_install=0

  if ! command -v node &> /dev/null; then
    need_install=1
  else
    local node_ver
    node_ver=$(node -v 2>/dev/null | sed -E 's/^v//' | cut -d. -f1)
    if [ -z "$node_ver" ] || [ "$node_ver" -lt 18 ]; then
      log_warn "Existing Node.js version is too old (v${node_ver}). Minimum required is Node.js 20/22 LTS."
      need_install=1
    fi
  fi

  if [ "$need_install" -eq 1 ]; then
    log_info "Installing Node.js 22 LTS and essential build tools..."
    install_prerequisites

    if command -v apt-get &> /dev/null; then
      # Method 1: NodeSource Setup Script
      local ns_success=0
      if curl -fsSL https://deb.nodesource.com/setup_22.x | $SUDO_CMD -E bash -; then
        if $SUDO_CMD apt-get install -y -qq nodejs build-essential; then
          ns_success=1
        fi
      fi

      # Method 2: Manual Keyring Fallback
      if [ "$ns_success" -eq 0 ]; then
        log_warn "Retrying NodeSource installation via direct keyring..."
        $SUDO_CMD mkdir -p /etc/apt/keyrings
        curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | $SUDO_CMD gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg --yes 2>/dev/null || true
        echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" | $SUDO_CMD tee /etc/apt/sources.list.d/nodesource.list >/dev/null
        $SUDO_CMD apt-get update -qq || true
        $SUDO_CMD apt-get install -y -qq nodejs build-essential || true
      fi

      # Method 3: Direct Official Binary Fallback
      if ! command -v node &> /dev/null || [ "$(node -v 2>/dev/null | sed -E 's/^v//' | cut -d. -f1)" -lt 18 ]; then
        log_warn "Installing Node.js 22 via official standalone binary archive..."
        local arch="x64"
        case "$(uname -m)" in
          x86_64|amd64) arch="x64" ;;
          aarch64|arm64) arch="arm64" ;;
          armv7l) arch="armv7l" ;;
        esac
        local node_tar_ver="v22.14.0"
        local node_tar="node-${node_tar_ver}-linux-${arch}.tar.xz"
        curl -fsSLO "https://nodejs.org/dist/${node_tar_ver}/${node_tar}"
        $SUDO_CMD tar -xJf "${node_tar}" -C /usr/local --strip-components=1
        rm -f "${node_tar}"
      fi

    elif command -v dnf &> /dev/null; then
      $SUDO_CMD dnf module install -y nodejs:22 || $SUDO_CMD dnf install -y nodejs
      $SUDO_CMD dnf install -y make gcc-c++ python3
    elif command -v yum &> /dev/null; then
      curl -fsSL https://rpm.nodesource.com/setup_22.x | $SUDO_CMD bash -
      $SUDO_CMD yum install -y nodejs gcc-c++ make python3
    elif command -v apk &> /dev/null; then
      $SUDO_CMD apk add --no-cache nodejs npm python3 make g++
    fi
  fi

  # Final verification
  if ! command -v node &> /dev/null; then
    log_error "Failed to install Node.js automatically. Please install Node.js 22 LTS manually."
    exit 1
  fi

  local detected_node
  detected_node=$(node -v 2>/dev/null || echo "Unknown")
  log_success "Node.js ready: ${detected_node}"
}

# ------------------------------------------------------------------------------
# Check & Install PM2 Process Manager
# ------------------------------------------------------------------------------
check_pm2() {
  log_info "Checking PM2 process manager..."
  if ! command -v pm2 &> /dev/null && ! command -v npx &> /dev/null; then
    log_info "Installing PM2 globally via npm..."
    if [ -n "$SUDO_CMD" ]; then
      $SUDO_CMD npm install -g pm2 || npm install pm2 --save-dev
    else
      npm install -g pm2 || npm install pm2 --save-dev
    fi
  fi
  log_success "PM2 is ready."
}

# ------------------------------------------------------------------------------
# Check & Install Docker Hypervisor Daemon
# ------------------------------------------------------------------------------
check_docker() {
  log_info "Checking Docker hypervisor daemon..."
  if ! command -v docker &> /dev/null; then
    log_warn "Docker is not installed. Installing Docker CE automatically..."
    if curl -fsSL https://get.docker.com | $SUDO_CMD sh; then
      log_success "Docker CE installed successfully."
    elif command -v apt-get &> /dev/null; then
      $SUDO_CMD apt-get update -qq
      $SUDO_CMD apt-get install -y -qq docker.io
    fi
  fi

  # Start Docker without systemd (service/init script or standalone dockerd)
  if ! docker info &> /dev/null; then
    log_info "Attempting to start Docker daemon without systemd..."
    $SUDO_CMD service docker start 2>/dev/null || \
    $SUDO_CMD /etc/init.d/docker start 2>/dev/null || true
    sleep 2

    if ! docker info &> /dev/null && command -v dockerd &>/dev/null; then
      log_info "Launching dockerd directly in background..."
      if [ -n "$SUDO_CMD" ]; then
        $SUDO_CMD sh -c 'nohup dockerd >/var/log/dvm-dockerd.log 2>&1 &' 
      else
        nohup dockerd >/var/log/dvm-dockerd.log 2>&1 &
      fi
      sleep 4
    fi
  fi

  # Add current user to docker group if needed
  if [ -n "$TARGET_USER" ] && [ "$TARGET_USER" != "root" ]; then
    $SUDO_CMD usermod -aG docker "$TARGET_USER" 2>/dev/null || true
  fi

  # Ensure socket permissions
  if [ -S "/var/run/docker.sock" ]; then
    $SUDO_CMD chmod 666 /var/run/docker.sock 2>/dev/null || true
  fi

  if docker info &> /dev/null; then
    local docker_ver
    docker_ver=$(docker --version 2>/dev/null | awk '{print $3}' | tr -d ',' || echo "Active")
    log_success "Docker daemon is active and running (Version: ${docker_ver})."
  else
    log_warn "Docker daemon could not be reached directly. Panel will attempt to connect via root/sudo."
  fi

  # Check KVM Hardware Virtualization
  if [ -e "/dev/kvm" ]; then
    $SUDO_CMD chmod 666 /dev/kvm 2>/dev/null || true
    log_success "KVM Hardware Acceleration (/dev/kvm) detected & configured."
  else
    log_info "KVM device (/dev/kvm) not found. Standard container virtualization active."
  fi
}

# ------------------------------------------------------------------------------
# Configure Firewall Ports (UFW / iptables)
# ------------------------------------------------------------------------------
configure_firewall() {
  if command -v ufw &> /dev/null && $SUDO_CMD ufw status 2>/dev/null | grep -q "Status: active"; then
    log_info "Configuring UFW Firewall rules for dpanel..."
    $SUDO_CMD ufw allow ${WEB_PORT}/tcp comment "dpanel Web UI" 2>/dev/null || true
    $SUDO_CMD ufw allow ${API_PORT}/tcp comment "dpanel API Backend" 2>/dev/null || true
    $SUDO_CMD ufw allow 25501:25599/tcp comment "dpanel VM SSH Pool" 2>/dev/null || true
    log_success "UFW rules updated: Ports ${WEB_PORT}, ${API_PORT}, and ${SSH_PORT_RANGE} allowed."
  fi
}

# ------------------------------------------------------------------------------
# Pre-pull default Docker VM images
# ------------------------------------------------------------------------------
prepull_images() {
  log_info "Pre-caching default Linux VM images in background..."
  local images=(
    "nobitaa/ubuntu:22"
    "nobitaa/ubuntu:24"
    "nobitaa/debain:11"
    "nobitaa/debain:12"
    "nobitaa/debain:13"
  )

  for img in "${images[@]}"; do
    if docker images -q "$img" 2>/dev/null | grep -q .; then
      echo -e "  ${GREEN}✔ ${img} is already cached locally.${NC}"
    else
      echo -e "  ${YELLOW}→ Background pulling ${img}...${NC}"
      docker pull "$img" &>/dev/null &
    fi
  done
}

# ------------------------------------------------------------------------------
# Clean Port Conflicts & Zombie Processes
# ------------------------------------------------------------------------------
clean_zombies() {
  log_info "Checking and releasing ports ${WEB_PORT} and ${API_PORT}..."
  if command -v fuser &> /dev/null; then
    $SUDO_CMD fuser -k -9 ${WEB_PORT}/tcp ${API_PORT}/tcp 2>/dev/null || true
  elif command -v lsof &> /dev/null; then
    $SUDO_CMD lsof -ti:${WEB_PORT},${API_PORT} 2>/dev/null | xargs -r $SUDO_CMD kill -9 2>/dev/null || true
  fi
  pm2_cmd delete dpanel-backend dpanel-frontend &>/dev/null || true
  sleep 1
}

# ------------------------------------------------------------------------------
# Full Installation Routine
# ------------------------------------------------------------------------------
do_install() {
  print_banner
  echo -e "${BOLD}${WHITE}======================================================${NC}"
  echo -e "${BOLD}${GREEN}        Starting Full DVM Panel Installation             ${NC}"
  echo -e "${BOLD}${WHITE}======================================================${NC}\n"

  check_privileges
  ensure_repo
  install_prerequisites
  check_nodejs
  check_pm2
  check_docker
  configure_firewall

  # 1. Create storage directories
  log_info "Creating required data directories..."
  mkdir -p data/uploads data/backups backend/data

  # 2. Install backend dependencies
  log_info "Installing backend dependencies (Express, ssh2, SQLite)..."
  (cd backend && npm install --no-audit)
  (cd backend && npm rebuild better-sqlite3 --build-from-source 2>/dev/null || true)
  log_success "Backend dependencies installed."

  # 3. Install frontend dependencies
  log_info "Installing frontend dependencies (React, Vite, Tailwind, Xterm)..."
  (cd frontend && npm install --no-audit)
  log_success "Frontend dependencies installed."

  # 4. Build frontend production assets
  log_info "Building frontend production bundle..."
  (cd frontend && npm run build)
  log_success "Frontend production bundle built successfully."

  # 5. Initialize Database & Safe Migrations
  log_info "Initializing SQLite database & default administrator account..."
  node -e "
    try {
      const db = require('./backend/src/db/index.js');
      console.log('Database initialized successfully.');
    } catch(e) {
      console.error('Database initialization error:', e.message || e);
      process.exit(1);
    }
  "

  # 6. Start PM2 Services
  log_info "Starting DVM Panel backend (port ${API_PORT}) and frontend (port ${WEB_PORT}) via PM2..."
  clean_zombies
  pm2_cmd start ecosystem.config.js
  pm2_cmd save &>/dev/null || true

  # 7. Register global 'dvm-panel' CLI command in system PATH
  log_info "Registering global 'dvm-panel' CLI command..."
  $SUDO_CMD ln -sf "$(pwd)/bin/dpanel.js" /usr/local/bin/dvm-panel 2>/dev/null || true
  $SUDO_CMD ln -sf "$(pwd)/bin/dpanel.js" /usr/local/bin/dpanel 2>/dev/null || true
  $SUDO_CMD chmod +x "$(pwd)/bin/dpanel.js" /usr/local/bin/dvm-panel /usr/local/bin/dpanel 2>/dev/null || true
  log_success "Global command 'dvm-panel' registered (/usr/local/bin/dvm-panel)."

  # 8. Start image caching in background
  prepull_images

  local server_ip
  server_ip=$(get_server_ip)

  echo -e "\n${BOLD}${GREEN}======================================================${NC}"
  echo -e "${BOLD}${GREEN}   🎉 DVM Panel Installation Completed Successfully!    ${NC}"
  echo -e "${BOLD}${GREEN}======================================================${NC}"
  echo -e "  ${WHITE}Web Panel URL  :${NC} ${CYAN}http://${server_ip}:${WEB_PORT}${NC}  ${YELLOW}(or http://localhost:${WEB_PORT})${NC}"
  echo -e "  ${WHITE}API Backend URL:${NC} ${CYAN}http://${server_ip}:${API_PORT}${NC}"
  echo -e "  ${WHITE}Default Admin  :${NC} ${YELLOW}admin@dpanel.io${NC} ${WHITE}(or username: ${YELLOW}admin${WHITE})${NC}"
  echo -e "  ${WHITE}Default Pass   :${NC} ${YELLOW}admin123${NC}"
  echo -e "  ${WHITE}SSH Port Pool  :${NC} ${GREEN}${SSH_PORT_RANGE}${NC} ${WHITE}(default root:root)${NC}"
  echo -e "${BOLD}${GREEN}======================================================${NC}\n"
}

# ------------------------------------------------------------------------------
# Update Routine
# ------------------------------------------------------------------------------
do_update() {
  print_banner
  echo -e "${BOLD}${WHITE}======================================================${NC}"
  echo -e "${BOLD}${CYAN}            Updating DVM Panel                 ${NC}"
  echo -e "${BOLD}${WHITE}======================================================${NC}\n"

  ensure_repo
  check_nodejs
  check_pm2

  # 1. Keep local DVM Panel customizations intact (no upstream Git pull).

  # 2. Update Backend dependencies
  log_info "Updating backend dependencies..."
  (cd backend && npm install --no-audit)
  (cd backend && npm rebuild better-sqlite3 --build-from-source 2>/dev/null || true)

  # 3. Update Frontend dependencies & Rebuild UI
  log_info "Updating frontend dependencies & rebuilding UI..."
  (cd frontend && npm install --no-audit && npm run build)

  # 4. Run all SQLite migrations
  log_info "Verifying database migrations..."
  node -e "
    try {
      const db = require('./backend/src/db/index.js');
      console.log('Database verified and updated.');
    } catch(e) {
      console.error('Database migration error:', e.message || e);
      process.exit(1);
    }
  "

  # 5. Restart PM2 processes cleanly
  log_info "Restarting DVM Panel PM2 services cleanly..."
  clean_zombies
  pm2_cmd start ecosystem.config.js
  pm2_cmd save &>/dev/null || true

  log_success "DVM Panel updated and reloaded successfully!"
  pm2_cmd status
}

# ------------------------------------------------------------------------------
# Uninstall Routine
# ------------------------------------------------------------------------------
do_uninstall() {
  print_banner
  echo -e "${BOLD}${RED}======================================================${NC}"
  echo -e "${BOLD}${RED}             DVM Panel Uninstallation Wizard             ${NC}"
  echo -e "${BOLD}${RED}======================================================${NC}\n"

  echo -e "${YELLOW}Warning: This will stop all DVM Panel services.${NC}"
  read -r -p "Are you sure you want to uninstall dpanel? (y/N): " CONFIRM
  if [[ ! "$CONFIRM" =~ ^[yY]$ ]]; then
    echo "Uninstallation cancelled."
    exit 0
  fi

  read -r -p "Do you want to stop and delete all dpanel Docker VM containers? (y/N): " REMOVE_VMS
  read -r -p "Do you want to delete all database files, backups, and user data? (y/N): " REMOVE_DATA

  log_info "Stopping and removing PM2 processes..."
  clean_zombies
  pm2_cmd save &>/dev/null || true

  if [[ "$REMOVE_VMS" =~ ^[yY]$ ]]; then
    log_info "Removing DVM Panel Docker containers..."
    node -e "
      const { execSync } = require('child_process');
      try {
        const { ServerModel } = require('./backend/src/db/models.js');
        const servers = ServerModel.getAll();
        for (const s of servers) {
          try { execSync('docker rm -f ' + s.name); console.log('Removed container: ' + s.name); } catch(e){}
        }
      } catch(e){}
    " 2>/dev/null || true
  fi

  if [[ "$REMOVE_DATA" =~ ^[yY]$ ]]; then
    log_info "Deleting database and data directory..."
    rm -rf data backend/data
  fi

  log_info "Cleaning node_modules and build artifacts..."
  rm -rf frontend/dist backend/node_modules frontend/node_modules
  $SUDO_CMD rm -f /usr/local/bin/dvm-panel /usr/local/bin/dpanel 2>/dev/null || true

  log_success "DVM Panel has been uninstalled."
}

# ------------------------------------------------------------------------------
# Service Lifecycle Routines
# ------------------------------------------------------------------------------
do_start() {
  ensure_repo
  log_info "Starting DVM Panel services via PM2..."
  clean_zombies
  pm2_cmd start ecosystem.config.js
  pm2_cmd save &>/dev/null || true
  pm2_cmd status
  log_success "DVM Panel is online! Web Panel: http://localhost:${WEB_PORT}"
}

do_stop() {
  ensure_repo
  log_info "Stopping DVM Panel services..."
  pm2_cmd stop ecosystem.config.js 2>/dev/null || true
  clean_zombies
  log_success "DVM Panel services stopped."
}

do_restart() {
  ensure_repo
  log_info "Restarting DVM Panel services cleanly..."
  clean_zombies
  pm2_cmd start ecosystem.config.js
  pm2_cmd save &>/dev/null || true
  pm2_cmd status
  log_success "DVM Panel services restarted cleanly."
}

do_status() {
  ensure_repo
  print_banner
  echo -e "${BOLD}${WHITE}================== PM2 Process Status ================${NC}"
  pm2_cmd status

  echo -e "\n${BOLD}${WHITE}================ Running VM Containers ===============${NC}"
  docker ps --filter "name=vm" --filter "name=ui" --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || docker ps 2>/dev/null || echo "Docker daemon not reachable"

  echo -e "\n${BOLD}${WHITE}================ API & Web Health ====================${NC}"
  local health
  health=$(curl -s http://127.0.0.1:${API_PORT}/api/health 2>/dev/null || echo '{"status":"offline"}')
  echo -e "Health Check: ${GREEN}${health}${NC}\n"
}

do_logs() {
  ensure_repo
  log_info "Streaming DVM Panel live PM2 logs (Press Ctrl+C to exit)..."
  pm2_cmd logs
}

do_reset_admin() {
  ensure_repo
  print_banner
  echo -e "${BOLD}${CYAN}=========== Reset Admin / Create User ===========${NC}\n"
  node backend/src/scripts/createuser.js "$@"
}

# ------------------------------------------------------------------------------
# Interactive CLI Menu
# ------------------------------------------------------------------------------
show_menu() {
  print_banner
  echo -e "${BOLD}${WHITE}Please choose an action:${NC}"
  echo -e "  ${CYAN}1)${NC} ${BOLD}Install / Setup DVM Panel${NC} (Full fresh setup & start)"
  echo -e "  ${CYAN}2)${NC} ${BOLD}Update DVM Panel${NC} (Pull latest code, rebuild & restart)"
  echo -e "  ${CYAN}3)${NC} ${BOLD}Start DVM Panel${NC} (Start web & api services)"
  echo -e "  ${CYAN}4)${NC} ${BOLD}Stop DVM Panel${NC} (Stop background services)"
  echo -e "  ${CYAN}5)${NC} ${BOLD}Restart DVM Panel${NC} (Restart all processes)"
  echo -e "  ${CYAN}6)${NC} ${BOLD}Check Status${NC} (View health, ports & containers)"
  echo -e "  ${CYAN}7)${NC} ${BOLD}View Live Logs${NC} (PM2 stream output)"
  echo -e "  ${CYAN}8)${NC} ${BOLD}Reset Admin Password / Create User${NC}"
  echo -e "  ${RED}9)${NC} ${BOLD}Uninstall DVM Panel${NC} (Clean removal)"
  echo -e "  ${WHITE}0)${NC} Exit"
  echo ""
  read -r -p "Enter choice [1-9, 0]: " CHOICE

  case "$CHOICE" in
    1) do_install ;;
    2) do_update ;;
    3) do_start ;;
    4) do_stop ;;
    5) do_restart ;;
    6) do_status ;;
    7) do_logs ;;
    8) do_reset_admin ;;
    9) do_uninstall ;;
    0) echo "Goodbye!"; exit 0 ;;
    *) log_error "Invalid option."; exit 1 ;;
  esac
}

# ------------------------------------------------------------------------------
# CLI Argument Router
# ------------------------------------------------------------------------------
case "$1" in
  install|-i|--install)
    do_install
    ;;
  update|-u|--update)
    do_update
    ;;
  uninstall|--uninstall|remove)
    do_uninstall
    ;;
  start)
    do_start
    ;;
  stop)
    do_stop
    ;;
  restart)
    do_restart
    ;;
  status)
    do_status
    ;;
  logs)
    do_logs
    ;;
  reset-admin|createuser|create-user)
    shift
    do_reset_admin "$@"
    ;;
  help|-h|--help)
    echo "Usage: bash run.sh [install|update|uninstall|start|stop|restart|status|logs|reset-admin]"
    ;;
  *)
    show_menu
    ;;
esac
