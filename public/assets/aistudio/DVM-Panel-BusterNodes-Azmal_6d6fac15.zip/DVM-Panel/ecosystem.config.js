const path = require('path');

module.exports = {
  apps: [
    {
      name: 'dpanel-backend',
      script: './backend/src/server.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        PORT: 3002,
        DATA_DIR: path.join(__dirname, 'data')
      },
      watch: false,
      autorestart: true,
      max_memory_restart: '500M',
      restart_delay: 2000,
      max_restarts: 20,
      min_uptime: '3s'
    },
    {
      name: 'dpanel-frontend',
      script: './frontend/server.js',
      cwd: __dirname,
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
        API_TARGET: 'http://127.0.0.1:3002'
      },
      watch: false,
      autorestart: true,
      max_memory_restart: '300M',
      restart_delay: 2000,
      max_restarts: 20,
      min_uptime: '3s'
    }
  ]
};

