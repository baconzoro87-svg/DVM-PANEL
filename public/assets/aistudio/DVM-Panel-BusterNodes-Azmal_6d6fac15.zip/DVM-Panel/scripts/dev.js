#!/usr/bin/env node
const { spawn } = require('child_process');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

console.log('----------------------------------------------------');
console.log('🛠️  Starting DVM Panel in Development Mode');
console.log('   Web UI Port : 3001 (Vite Dev Server)');
console.log('   API Port    : 3002 (Node.js API)');
console.log('----------------------------------------------------');

const backend = spawn('node', ['--watch', 'backend/src/server.js'], {
  cwd: rootDir,
  env: { ...process.env, PORT: '3002', NODE_ENV: 'development' },
  stdio: 'inherit'
});

const frontend = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '3001'], {
  cwd: path.join(rootDir, 'frontend'),
  env: { ...process.env, NODE_ENV: 'development' },
  stdio: 'inherit'
});

function cleanup() {
  console.log('\n🛑 Stopping DVM Panel dev services...');
  backend.kill('SIGINT');
  frontend.kill('SIGINT');
  process.exit(0);
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

