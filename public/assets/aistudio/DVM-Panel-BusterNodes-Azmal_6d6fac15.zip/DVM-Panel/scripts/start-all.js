#!/usr/bin/env node
const { spawn } = require('child_process');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

console.log('----------------------------------------------------');
console.log('🚀 Starting DVM Panel by BusterNodes');
console.log('   Web UI Port : 3001');
console.log('   API Port    : 3002');
console.log('----------------------------------------------------');

const backend = spawn('node', ['backend/src/server.js'], {
  cwd: rootDir,
  env: { ...process.env, PORT: '3002', NODE_ENV: 'production' },
  stdio: 'inherit'
});

const frontend = spawn('node', ['frontend/server.js'], {
  cwd: rootDir,
  env: { ...process.env, PORT: '3001', API_TARGET: 'http://127.0.0.1:3002', NODE_ENV: 'production' },
  stdio: 'inherit'
});

function cleanup() {
  console.log('\n🛑 Stopping DVM Panel services...');
  backend.kill('SIGINT');
  frontend.kill('SIGINT');
  process.exit(0);
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

