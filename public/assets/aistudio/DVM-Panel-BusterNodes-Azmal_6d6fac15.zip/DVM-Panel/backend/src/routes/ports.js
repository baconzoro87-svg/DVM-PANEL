const express = require('express');
const router = express.Router();
const CONFIG = require('../config');
const { ServerModel } = require('../db/models');
const { allocateNextFreePort, isPortInUseOnHost } = require('../utils/ports');
const { authenticateToken } = require('../middleware/auth');

/**
 * GET /api/ports/next-free
 * Automatically calculates and returns the next free port in the 25501-25599 pool
 */
router.get('/next-free', authenticateToken, async (req, res) => {
  try {
    const preferred = req.query.preferred ? parseInt(req.query.preferred, 10) : null;
    const nextPort = await allocateNextFreePort(preferred);
    const usedPortsSet = ServerModel.getAllUsedPorts();

    const min = CONFIG.PORT_RANGE.MIN;
    const max = CONFIG.PORT_RANGE.MAX;
    const total = max - min + 1;
    const usedCount = usedPortsSet.size;
    const freeCount = Math.max(0, total - usedCount);

    res.json({
      success: true,
      port: nextPort,
      nextPort,
      range: { min, max },
      total,
      usedCount,
      freeCount
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/ports/check?port=25501
 * Checks availability of a specific port
 */
router.get('/check', authenticateToken, async (req, res) => {
  try {
    const port = parseInt(req.query.port, 10);
    const min = CONFIG.PORT_RANGE.MIN;
    const max = CONFIG.PORT_RANGE.MAX;

    if (!port || isNaN(port)) {
      return res.status(400).json({ success: false, message: 'Valid port number is required.' });
    }

    if (port < min || port > max) {
      return res.json({
        success: true,
        port,
        available: false,
        inRange: false,
        message: `Port must be in range ${min}-${max}.`
      });
    }

    const usedPorts = ServerModel.getAllUsedPorts();
    const inDb = usedPorts.has(port);
    const inHost = await isPortInUseOnHost(port);
    const available = !inDb && !inHost;

    res.json({
      success: true,
      port,
      available,
      inRange: true,
      inDb,
      inHost,
      message: available ? `Port ${port} is available.` : `Port ${port} is currently in use.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/ports/pool
 * Returns full status of the 25501-25599 port pool
 */
router.get('/pool', authenticateToken, (req, res) => {
  try {
    const min = CONFIG.PORT_RANGE.MIN;
    const max = CONFIG.PORT_RANGE.MAX;
    const servers = ServerModel.getAll();

    const usedMap = new Map();
    for (const s of servers) {
      if (s.port_ssh) {
        usedMap.set(Number(s.port_ssh), { serverId: s.id, serverName: s.name, type: 'SSH' });
      }
      try {
        const extra = JSON.parse(s.additional_ports || '[]');
        for (const p of extra) {
          if (p.host) {
            usedMap.set(Number(p.host), { serverId: s.id, serverName: s.name, type: 'Additional' });
          }
        }
      } catch (e) {}
    }

    const pool = [];
    for (let p = min; p <= max; p++) {
      if (usedMap.has(p)) {
        pool.push({ port: p, status: 'used', ...usedMap.get(p) });
      } else {
        pool.push({ port: p, status: 'free' });
      }
    }

    res.json({
      success: true,
      range: { min, max },
      total: max - min + 1,
      used: usedMap.size,
      free: (max - min + 1) - usedMap.size,
      pool
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
