const express = require('express');
const router = express.Router();
const { TicketModel, ActivityLogModel } = require('../db/models');
const { authenticateToken } = require('../middleware/auth');

// List tickets (user sees their own, admin sees all)
router.get('/', authenticateToken, (req, res) => {
  if (req.user.role === 'admin') {
    const tickets = TicketModel.getAll();
    return res.json({ success: true, tickets });
  }
  const tickets = TicketModel.getByUserId(req.user.id);
  res.json({ success: true, tickets });
});

// Create ticket
router.post('/', authenticateToken, (req, res) => {
  try {
    const { title, message, priority } = req.body;
    if (!title || !message) {
      return res.status(400).json({ success: false, message: 'Title and message are required.' });
    }

    const ticket = TicketModel.create({
      user_id: req.user.id,
      title,
      priority: priority || 'medium'
    });

    TicketModel.addMessage({
      ticket_id: ticket.id,
      user_id: req.user.id,
      message
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'TICKET_CREATE',
      details: `Opened ticket #${ticket.id}: "${title}"`
    });

    res.status(201).json({ success: true, message: 'Ticket opened.', ticket });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get ticket details and conversation thread
router.get('/:id', authenticateToken, (req, res) => {
  const ticketId = parseInt(req.params.id, 10);
  const ticket = TicketModel.findById(ticketId);

  if (!ticket) return res.status(404).json({ success: false, message: 'Ticket not found.' });

  // Check access
  if (req.user.role !== 'admin' && ticket.user_id !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Access denied.' });
  }

  const messages = TicketModel.getMessages(ticketId);
  res.json({ success: true, ticket, messages });
});

// Send message to ticket
router.post('/:id/messages', authenticateToken, (req, res) => {
  try {
    const ticketId = parseInt(req.params.id, 10);
    const ticket = TicketModel.findById(ticketId);

    if (!ticket) return res.status(404).json({ success: false, message: 'Ticket not found.' });

    if (req.user.role !== 'admin' && ticket.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const { message } = req.body;
    if (!message) return res.status(400).json({ success: false, message: 'Message cannot be empty.' });

    const msg = TicketModel.addMessage({
      ticket_id: ticketId,
      user_id: req.user.id,
      message
    });

    // If ticket was closed and user replies, reopen it
    if (ticket.status === 'closed') {
      TicketModel.updateStatus(ticketId, 'open');
    }

    res.status(201).json({ success: true, message: msg });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Update ticket status
router.put('/:id/status', authenticateToken, (req, res) => {
  try {
    const ticketId = parseInt(req.params.id, 10);
    const ticket = TicketModel.findById(ticketId);

    if (!ticket) return res.status(404).json({ success: false, message: 'Ticket not found.' });

    if (req.user.role !== 'admin' && ticket.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const { status } = req.body;
    if (!['open', 'in_progress', 'resolved', 'closed'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status.' });
    }

    const updated = TicketModel.updateStatus(ticketId, status);
    res.json({ success: true, message: 'Ticket status updated.', ticket: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

