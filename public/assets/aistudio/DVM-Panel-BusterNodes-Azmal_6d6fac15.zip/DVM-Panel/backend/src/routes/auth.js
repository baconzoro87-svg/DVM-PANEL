const express = require('express');
const router = express.Router();
const { UserModel, SettingsModel, LoginHistoryModel, ActivityLogModel, PlanModel } = require('../db/models');
const { hashPassword, comparePassword, generateToken, generate2FASecret, generate2FAQRCode, verify2FAToken } = require('../utils/security');
const { authenticateToken } = require('../middleware/auth');

// Register
router.post('/register', async (req, res) => {
  try {
    const registerEnabled = SettingsModel.get('register_enabled', 'true') === 'true';
    if (!registerEnabled) {
      return res.status(403).json({ success: false, message: 'User registration is currently disabled by administrator.' });
    }

    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Username, email, and password are required.' });
    }

    if (username.length < 3 || username.length > 32) {
      return res.status(400).json({ success: false, message: 'Username must be between 3 and 32 characters.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    // Check existing
    if (UserModel.findByUsername(username)) {
      return res.status(400).json({ success: false, message: 'Username is already taken.' });
    }

    if (UserModel.findByEmail(email)) {
      return res.status(400).json({ success: false, message: 'Email is already registered.' });
    }

    // Check if this is the very first user (make them admin automatically)
    const isFirstUser = UserModel.count() === 0;
    const defaultRole = isFirstUser ? 'admin' : 'user';

    // Get default plan limits
    const defaultPlan = PlanModel.getDefault();
    const ram_limit = defaultPlan ? defaultPlan.max_ram : '2G';
    const cpu_limit = defaultPlan ? defaultPlan.max_cpu : 2;
    const disk_limit = defaultPlan ? defaultPlan.max_disk : '20G';
    const max_servers = defaultPlan ? defaultPlan.max_servers : 3;

    const password_hash = await hashPassword(password);

    const newUser = UserModel.create({
      username,
      email,
      password_hash,
      role: defaultRole,
      ram_limit,
      cpu_limit,
      disk_limit,
      max_servers
    });

    const token = generateToken(newUser);

    LoginHistoryModel.create({
      user_id: newUser.id,
      username: newUser.username,
      ip_address: req.ip || req.connection.remoteAddress,
      user_agent: req.headers['user-agent'] || '',
      status: 'success'
    });

    ActivityLogModel.create({
      user_id: newUser.id,
      action: 'USER_REGISTER',
      details: `New account registered: ${newUser.username} (${newUser.role})`
    });

    return res.status(201).json({
      success: true,
      message: 'Account created successfully.',
      token,
      user: newUser
    });
  } catch (err) {
    console.error('[Auth Register] Error:', err);
    return res.status(500).json({ success: false, message: 'Registration failed. ' + err.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { identifier, password, twoFactorCode } = req.body;

    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'Username/Email and password are required.' });
    }

    const user = UserModel.findByEmailOrUsername(identifier);
    const clientIp = req.ip || req.connection.remoteAddress;
    const clientUa = req.headers['user-agent'] || '';

    if (!user) {
      LoginHistoryModel.create({
        user_id: null,
        username: identifier,
        ip_address: clientIp,
        user_agent: clientUa,
        status: 'failed'
      });
      return res.status(400).json({ success: false, message: 'Invalid credentials.' });
    }

    if (user.status === 'suspended') {
      return res.status(403).json({ success: false, message: 'Account is suspended. Contact administrator.' });
    }

    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      LoginHistoryModel.create({
        user_id: user.id,
        username: user.username,
        ip_address: clientIp,
        user_agent: clientUa,
        status: 'failed'
      });
      return res.status(400).json({ success: false, message: 'Invalid credentials.' });
    }

    // Check 2FA
    if (user.two_factor_enabled) {
      if (!twoFactorCode) {
        return res.json({
          success: true,
          require2FA: true,
          userId: user.id,
          message: '2FA authentication required.'
        });
      }

      const isValid2FA = verify2FAToken(twoFactorCode, user.two_factor_secret);
      if (!isValid2FA) {
        LoginHistoryModel.create({
          user_id: user.id,
          username: user.username,
          ip_address: clientIp,
          user_agent: clientUa,
          status: 'failed_2fa'
        });
        return res.status(400).json({ success: false, message: 'Invalid 2FA verification code.' });
      }
    }

    const token = generateToken(user);

    LoginHistoryModel.create({
      user_id: user.id,
      username: user.username,
      ip_address: clientIp,
      user_agent: clientUa,
      status: 'success'
    });

    const safeUser = UserModel.findById(user.id);

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: safeUser
    });
  } catch (err) {
    console.error('[Auth Login] Error:', err);
    return res.status(500).json({ success: false, message: 'Login failed: ' + err.message });
  }
});

// Verify 2FA separate step
router.post('/2fa/verify', async (req, res) => {
  try {
    const { userId, code } = req.body;
    if (!userId || !code) {
      return res.status(400).json({ success: false, message: 'User ID and code are required.' });
    }

    const user = UserModel.findByIdFull(userId);
    if (!user || !user.two_factor_secret) {
      return res.status(400).json({ success: false, message: 'Invalid request.' });
    }

    const isValid = verify2FAToken(code, user.two_factor_secret);
    if (!isValid) {
      return res.status(400).json({ success: false, message: 'Invalid 2FA code.' });
    }

    const token = generateToken(user);
    const safeUser = UserModel.findById(user.id);

    return res.json({
      success: true,
      token,
      user: safeUser
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Forgot Password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: 'Email is required.' });
    }

    const user = UserModel.findByEmail(email);
    if (!user) {
      // Return ok to prevent email enumeration
      return res.json({ success: true, message: 'If this email exists, a password reset link has been sent.' });
    }

    const crypto = require('crypto');
    const resetToken = crypto.randomBytes(32).toString('hex');
    const expires = new Date(Date.now() + 3600000).toISOString(); // 1 hour

    UserModel.update(user.id, {
      reset_token: resetToken,
      reset_token_expires: expires
    });

    return res.json({
      success: true,
      message: 'Password reset instructions generated.',
      resetToken // for dev/offline testing if SMTP is not configured
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Reset Password
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword || newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'Valid token and minimum 6 character password required.' });
    }

    const db = require('../db');
    const user = db.prepare('SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > CURRENT_TIMESTAMP').get(token);

    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid or expired password reset token.' });
    }

    const password_hash = await hashPassword(newPassword);
    UserModel.update(user.id, {
      password_hash,
      reset_token: null,
      reset_token_expires: null
    });

    return res.json({ success: true, message: 'Password has been successfully updated.' });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Get Current User
router.get('/me', authenticateToken, (req, res) => {
  return res.json({
    success: true,
    user: req.user
  });
});

module.exports = router;

