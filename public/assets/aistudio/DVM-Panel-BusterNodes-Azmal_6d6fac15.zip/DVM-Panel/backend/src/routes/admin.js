const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const { UserModel, ServerModel, PlanModel, ApiKeyModel, ActivityLogModel, LoginHistoryModel, SettingsModel } = require('../db/models');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { hashPassword } = require('../utils/security');
const { allocateNextFreePort } = require('../utils/ports');
const DockerService = require('../services/dockerService');
const StatsService = require('../services/statsService');
const CONFIG = require('../config');

// All routes in this file require admin authentication
router.use(authenticateToken, requireAdmin);

// Admin Dashboard Overview
router.get('/overview', async (req, res) => {
  try {
    const hostStats = await StatsService.getHostStats();
    const dockerPing = await DockerService.ping();
    const recentActivity = ActivityLogModel.getRecent(10);
    const recentLogins = LoginHistoryModel.getRecent(10);

    res.json({
      success: true,
      stats: hostStats,
      docker: dockerPing,
      recentActivity,
      recentLogins
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// USER MANAGEMENT
// ----------------------------------------------------

// List all users
router.get('/users', (req, res) => {
  const users = UserModel.getAll();
  res.json({ success: true, users });
});

// Get user profile details
router.get('/users/:id', (req, res) => {
  const user = UserModel.findById(parseInt(req.params.id, 10));
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

  const servers = ServerModel.getByUserId(user.id);
  const activities = ActivityLogModel.getByUserId(user.id, 20);
  const loginHistory = LoginHistoryModel.getByUserId(user.id, 10);

  res.json({
    success: true,
    user,
    servers,
    activities,
    loginHistory
  });
});

// Create new user (Admin)
router.post('/users', async (req, res) => {
  try {
    const { username, email, password, role = 'user', ram_limit = '2G', cpu_limit = 2, disk_limit = '20G', max_servers = 3 } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Username, email, and password are required.' });
    }

    if (UserModel.findByUsername(username)) {
      return res.status(400).json({ success: false, message: 'Username is already taken.' });
    }

    if (UserModel.findByEmail(email)) {
      return res.status(400).json({ success: false, message: 'Email is already in use.' });
    }

    const password_hash = await hashPassword(password);
    const newUser = UserModel.create({
      username,
      email,
      password_hash,
      role,
      ram_limit,
      cpu_limit: parseInt(cpu_limit, 10) || 2,
      disk_limit,
      max_servers: parseInt(max_servers, 10) || 3
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'ADMIN_CREATE_USER',
      details: `Admin created user: ${username} (${role})`
    });

    res.status(201).json({ success: true, message: 'User created successfully.', user: newUser });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Edit user (Admin)
router.put('/users/:id', async (req, res) => {
  try {
    const userId = parseInt(req.params.id, 10);
    const { username, email, role, status, ram_limit, cpu_limit, disk_limit, max_servers, password } = req.body;
    const updates = {};

    if (username) updates.username = username;
    if (email) updates.email = email;
    if (role) updates.role = role;
    if (status) updates.status = status;
    if (ram_limit) updates.ram_limit = ram_limit;
    if (cpu_limit !== undefined) updates.cpu_limit = parseInt(cpu_limit, 10);
    if (disk_limit) updates.disk_limit = disk_limit;
    if (max_servers !== undefined) updates.max_servers = parseInt(max_servers, 10);
    if (password && password.length >= 6) {
      updates.password_hash = await hashPassword(password);
    }

    const updated = UserModel.update(userId, updates);

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'ADMIN_UPDATE_USER',
      details: `Admin updated user ID ${userId} (${updated.username})`
    });

    res.json({ success: true, message: 'User updated.', user: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Suspend / Unsuspend user
router.post('/users/:id/toggle-status', async (req, res) => {
  try {
    const userId = parseInt(req.params.id, 10);
    if (userId === req.user.id) {
      return res.status(400).json({ success: false, message: 'You cannot suspend your own admin account.' });
    }

    const user = UserModel.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    const newStatus = user.status === 'active' ? 'suspended' : 'active';
    UserModel.update(userId, { status: newStatus });

    // If user suspended, auto-suspend all their VMs; if unsuspended, clear suspend flag
    const userServers = ServerModel.getByUserId(userId) || [];
    if (newStatus === 'suspended') {
      for (const s of userServers) {
        try {
          await DockerService.stopVM(s.name);
          ServerModel.update(s.id, { status: 'suspended', is_suspended: 1, suspend_reason: 'User account suspended by administrator' });
        } catch (e) {}
      }
    } else {
      for (const s of userServers) {
        try {
          ServerModel.update(s.id, { status: 'stopped', is_suspended: 0, suspend_reason: '' });
        } catch (e) {}
      }
    }

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'ADMIN_USER_STATUS',
      details: `Admin changed user ${user.username} status to ${newStatus}`
    });

    res.json({ success: true, message: `User status changed to ${newStatus}.`, status: newStatus });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Suspend a server container manually
router.post('/servers/:id/suspend', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const server = ServerModel.findById(id);
    if (!server) return res.status(404).json({ success: false, message: 'Server not found.' });

    await DockerService.stopVM(server.name);
    ServerModel.update(id, {
      status: 'suspended',
      is_suspended: 1,
      suspend_reason: req.body.reason || 'Manually suspended by Administrator'
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: server.id,
      action: 'SERVER_SUSPEND',
      details: `Admin suspended VM "${server.name}"`
    });

    res.json({ success: true, message: `Server "${server.name}" suspended successfully.` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Unsuspend a server container
router.post('/servers/:id/unsuspend', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const server = ServerModel.findById(id);
    if (!server) return res.status(404).json({ success: false, message: 'Server not found.' });

    ServerModel.update(id, {
      status: 'stopped',
      is_suspended: 0,
      suspend_reason: ''
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: server.id,
      action: 'SERVER_UNSUSPEND',
      details: `Admin unsuspended VM "${server.name}"`
    });

    res.json({ success: true, message: `Server "${server.name}" unsuspended successfully.` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Delete user
router.delete('/users/:id', async (req, res) => {
  try {
    const userId = parseInt(req.params.id, 10);
    if (userId === req.user.id) {
      return res.status(400).json({ success: false, message: 'You cannot delete your own admin account.' });
    }

    const user = UserModel.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    // Stop and remove all user's servers
    const servers = ServerModel.getByUserId(userId);
    for (const s of servers) {
      await DockerService.removeVM(s.name);
      ServerModel.delete(s.id);
    }

    UserModel.delete(userId);

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'ADMIN_DELETE_USER',
      details: `Admin deleted user ${user.username}`
    });

    res.json({ success: true, message: 'User and all associated servers deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// SERVER MANAGEMENT (ADMIN)
// ----------------------------------------------------

// List all servers with host & docker stats
router.get('/servers', async (req, res) => {
  try {
    const servers = ServerModel.getAll();
    const enriched = await Promise.all(servers.map(async (srv) => {
      const dockerStatus = await DockerService.getStatus(srv.name);
      return {
        ...srv,
        status: dockerStatus || srv.status
      };
    }));
    res.json({ success: true, servers: enriched });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin Create VM for any user
router.post('/servers', async (req, res) => {
  try {
    const {
      name,
      hostname,
      image,
      port_ssh,
      memory_limit = '1G',
      cpu_limit = '1',
      disk_limit = '10G',
      user_id,
      env_vars,
      additional_ports,
      ssh_user = 'root',
      ssh_password = 'root'
    } = req.body;

    const targetUserId = user_id ? parseInt(user_id, 10) : req.user.id;
    const targetUser = UserModel.findById(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ success: false, message: 'Target user not found.' });
    }

    const vmName = (name || CONFIG.DEFAULT_VM_SPECS.NAME).toLowerCase().replace(/[^a-z0-9_-]/g, '');
    const vmHostname = hostname || vmName;
    const vmImage = image || CONFIG.SUPPORTED_IMAGES[0].id;
    const cleanSshUser = String(ssh_user).trim() || 'root';
    const cleanSshPass = String(ssh_password).trim() || 'root';

    if (ServerModel.findByName(vmName)) {
      return res.status(400).json({ success: false, message: `A VM named "${vmName}" already exists.` });
    }

    const allocatedPort = await allocateNextFreePort(port_ssh ? parseInt(port_ssh, 10) : null);
    const serverUuid = uuidv4();

    console.log(`[Admin Create VM] Creating container: ${vmName} (${vmImage}) on port ${allocatedPort}...`);

    const defaultEnv = {
      VM_NAME: vmName,
      HOSTNAME: vmHostname,
      RAM: String(memory_limit).toUpperCase(),
      CPUS: String(cpu_limit),
      DISK_SIZE: String(disk_limit).toUpperCase()
    };
    let customEnv = {};
    if (typeof env_vars === 'string') {
      try { customEnv = JSON.parse(env_vars); } catch(e) {}
    } else if (typeof env_vars === 'object' && env_vars !== null) {
      customEnv = env_vars;
    }
    const mergedEnv = { ...defaultEnv, ...customEnv };

    const containerResult = await DockerService.createVM({
      name: vmName,
      hostname: vmHostname,
      image: vmImage,
      port_ssh: allocatedPort,
      ram: memory_limit,
      cpus: cpu_limit,
      disk_size: disk_limit,
      env_vars: mergedEnv,
      additional_ports: Array.isArray(additional_ports) ? additional_ports : []
    });

    const newServer = ServerModel.create({
      uuid: serverUuid,
      name: vmName,
      hostname: vmHostname,
      image: vmImage,
      port_ssh: allocatedPort,
      additional_ports: JSON.stringify(additional_ports || []),
      memory_limit,
      cpu_limit: String(cpu_limit),
      disk_limit,
      user_id: targetUserId,
      container_id: containerResult.containerId,
      status: 'running',
      env_vars: JSON.stringify(mergedEnv),
      ssh_user: cleanSshUser,
      ssh_password: cleanSshPass,
      auto_suspend_type: req.body.auto_suspend_type || 'hours',
      auto_suspend_hours: parseInt(req.body.auto_suspend_hours, 10) || 0,
      auto_suspend_at: req.body.auto_suspend_at || null,
      auto_suspend_time: req.body.auto_suspend_time || ''
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: newServer.id,
      action: 'ADMIN_SERVER_CREATE',
      details: `Admin created VM "${vmName}" for user ${targetUser.username} on port ${allocatedPort}`
    });

    res.status(201).json({
      success: true,
      message: 'Server created successfully.',
      server: { ...newServer, status: 'running' }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Change server owner
router.put('/servers/:id/owner', (req, res) => {
  try {
    const serverId = parseInt(req.params.id, 10);
    const { newUserId } = req.body;

    const targetUser = UserModel.findById(newUserId);
    if (!targetUser) return res.status(404).json({ success: false, message: 'New owner user not found.' });

    const server = ServerModel.findById(serverId);
    if (!server) return res.status(404).json({ success: false, message: 'Server not found.' });

    ServerModel.update(serverId, { user_id: newUserId });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: serverId,
      action: 'SERVER_TRANSFER',
      details: `Admin transferred VM "${server.name}" to user ${targetUser.username}`
    });

    res.json({ success: true, message: `Server owner transferred to ${targetUser.username}.` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// PLANS MANAGEMENT
// ----------------------------------------------------

router.get('/plans', (req, res) => {
  const plans = PlanModel.getAll();
  res.json({ success: true, plans });
});

router.post('/plans', (req, res) => {
  try {
    const { name, price, max_servers, max_ram, max_cpu, max_disk, is_default } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Plan name is required.' });
    }
    const plan = PlanModel.create({
      name: name.trim(),
      price: price ? price.trim() : '₹0 / Free',
      max_servers: parseInt(max_servers, 10) || 3,
      max_ram: String(max_ram || '2G').toUpperCase(),
      max_cpu: parseInt(max_cpu, 10) || 2,
      max_disk: String(max_disk || '20G').toUpperCase(),
      is_default: is_default ? 1 : 0
    });
    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'PLAN_CREATE',
      details: `Created quota plan "${plan.name}"`
    });
    res.status(201).json({ success: true, message: 'Quota plan created successfully.', plan });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/plans/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = PlanModel.findById(id);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Plan not found.' });
    }
    const { name, price, max_servers, max_ram, max_cpu, max_disk, is_default } = req.body;
    const updates = {};
    if (name) updates.name = name.trim();
    if (price !== undefined) updates.price = price.trim() || '₹0 / Free';
    if (max_servers !== undefined) updates.max_servers = parseInt(max_servers, 10) || 1;
    if (max_ram) updates.max_ram = String(max_ram).toUpperCase();
    if (max_cpu !== undefined) updates.max_cpu = parseInt(max_cpu, 10) || 1;
    if (max_disk) updates.max_disk = String(max_disk).toUpperCase();
    if (is_default !== undefined) updates.is_default = is_default ? 1 : 0;

    const updated = PlanModel.update(id, updates);
    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'PLAN_UPDATE',
      details: `Updated quota plan "${updated.name}"`
    });
    res.json({ success: true, message: 'Quota plan updated successfully.', plan: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/plans/:id/set-default', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = PlanModel.findById(id);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Plan not found.' });
    }
    const updated = PlanModel.setDefault(id);
    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'PLAN_SET_DEFAULT',
      details: `Set plan "${updated.name}" as default quota plan for new users`
    });
    res.json({ success: true, message: `Plan "${updated.name}" is now default.`, plan: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/plans/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = PlanModel.findById(id);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Plan not found.' });
    }
    PlanModel.delete(id);
    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'PLAN_DELETE',
      details: `Deleted quota plan "${existing.name}"`
    });
    res.json({ success: true, message: 'Quota plan deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// TOOLBOX & DIAGNOSTICS
// ----------------------------------------------------

router.post('/toolbox/prune', async (req, res) => {
  try {
    const result = await DockerService.systemPrune();
    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'TOOLBOX_PRUNE',
      details: 'Docker system prune executed'
    });
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/toolbox/images', async (req, res) => {
  try {
    const images = await DockerService.listImages();
    res.json({ success: true, images });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// API KEYS
// ----------------------------------------------------

router.get('/api-keys', (req, res) => {
  const keys = ApiKeyModel.getAll();
  res.json({ success: true, keys });
});

router.post('/api-keys', (req, res) => {
  try {
    const { name, permissions } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'Key name is required.' });

    const rawToken = `dp_${crypto.randomBytes(24).toString('hex')}`;
    const prefix = rawToken.substring(0, 7);
    const key_hash = crypto.createHash('sha256').update(rawToken).digest('hex');

    const keyRecord = ApiKeyModel.create({
      user_id: req.user.id,
      name,
      key_hash,
      prefix,
      permissions: permissions || ['all']
    });

    res.status(201).json({
      success: true,
      message: 'API Key created. Copy it now, it will not be shown again.',
      token: rawToken,
      key: keyRecord
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/api-keys/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    ApiKeyModel.delete(id);
    res.json({ success: true, message: 'API key revoked.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// AUDIT LOGS
// ----------------------------------------------------

router.get('/activity', (req, res) => {
  const limit = parseInt(req.query.limit || '100', 10);
  const logs = ActivityLogModel.getRecent(limit);
  res.json({ success: true, logs });
});

router.get('/login-history', (req, res) => {
  const limit = parseInt(req.query.limit || '100', 10);
  const history = LoginHistoryModel.getRecent(limit);
  res.json({ success: true, history });
});

module.exports = router;

