const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { SettingsModel, ActivityLogModel } = require('../db/models');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const WallpaperService = require('../services/wallpaperService');
const CONFIG = require('../config');

// Get all wallpaper categories
router.get('/wallpapers/categories', (req, res) => {
  res.json({ success: true, categories: WallpaperService.getCategories() });
});

// Browse wallpapers from 4kwallpapers.com with search, categories, and pagination
router.get('/wallpapers/browse', async (req, res) => {
  try {
    const { category = 'all', page = 1, search = '' } = req.query;
    const data = await WallpaperService.fetchWallpapers({ category, page, search });
    res.json(data);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get favorites
router.get('/wallpapers/favorites', authenticateToken, (req, res) => {
  res.json({ success: true, favorites: WallpaperService.getFavorites() });
});

// Toggle favorite
router.post('/wallpapers/favorites', authenticateToken, (req, res) => {
  try {
    const { wallpaper } = req.body;
    if (!wallpaper || !wallpaper.url) {
      return res.status(400).json({ success: false, message: 'Wallpaper object is required.' });
    }
    const result = WallpaperService.toggleFavorite(wallpaper);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 1-Click Apply Wallpaper
router.post('/wallpapers/apply', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { url, type = 'image_url', category = 'general' } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, message: 'Wallpaper URL is required.' });
    }
    SettingsModel.set('background_url', url, 'branding');
    SettingsModel.set('background_type', type, 'branding');
    SettingsModel.set('background_category', category, 'branding');

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'BACKGROUND_UPDATED',
      details: `Admin applied background wallpaper: ${url.substring(0, 60)}`
    });

    res.json({
      success: true,
      message: 'Background applied successfully to panel.',
      background_url: url,
      background_type: type
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Public settings (branding, theme, wallpaper, music for client rendering)
router.get('/public', (req, res) => {
  const all = SettingsModel.getAll();
  // Filter out sensitive settings like smtp password
  const publicKeys = [
    'panel_name',
    'panel_logo',
    'panel_logo_url',
    'panel_favicon_name',
    'panel_favicon_url',
    'background_type',
    'background_url',
    'background_category',
    'music_enabled',
    'music_type',
    'music_url',
    'music_title',
    'music_volume',
    'music_autoplay',
    'transparency',
    'blur',
    'theme',
    'accent_color',
    'custom_css',
    'register_enabled',
    'require_2fa',
    'social_discord',
    'social_telegram',
    'social_github',
    'social_twitter',
    'social_website'
  ];

  const publicSettings = {};
  for (const k of publicKeys) {
    publicSettings[k] = all[k] !== undefined ? all[k] : '';
  }

  res.json({
    success: true,
    settings: publicSettings,
    wallpaperCategories: CONFIG.WALLPAPER_CATEGORIES,
    supportedImages: CONFIG.SUPPORTED_IMAGES
  });
});

// Admin get all settings
router.get('/all', authenticateToken, requireAdmin, (req, res) => {
  const settings = SettingsModel.getAll();
  // Mask SMTP password
  if (settings.smtp_pass) {
    settings.smtp_pass_masked = '********';
  }
  res.json({
    success: true,
    settings,
    wallpaperCategories: CONFIG.WALLPAPER_CATEGORIES,
    supportedImages: CONFIG.SUPPORTED_IMAGES
  });
});

// Admin update settings
router.put('/', authenticateToken, requireAdmin, (req, res) => {
  try {
    const updates = req.body;
    SettingsModel.setMany(updates);

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'SETTINGS_UPDATE',
      details: `Admin updated panel settings`
    });

    res.json({ success: true, message: 'Settings updated successfully.', settings: SettingsModel.getAll() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin upload media (logo, favicon, background image/video, background music)
router.post('/upload', authenticateToken, requireAdmin, upload.fields([
  { name: 'logo', maxCount: 1 },
  { name: 'favicon', maxCount: 1 },
  { name: 'background', maxCount: 1 },
  { name: 'music', maxCount: 1 }
]), (req, res) => {
  try {
    const results = {};

    if (req.files.logo && req.files.logo[0]) {
      const file = req.files.logo[0];
      const mediaUrl = `/api/settings/media/branding/${file.filename}`;
      SettingsModel.set('panel_logo', mediaUrl);
      SettingsModel.set('panel_logo_url', mediaUrl);
      results.logo = mediaUrl;
    }

    if (req.files.favicon && req.files.favicon[0]) {
      const file = req.files.favicon[0];
      const mediaUrl = `/api/settings/media/branding/${file.filename}`;
      SettingsModel.set('panel_favicon_url', mediaUrl);
      results.favicon = mediaUrl;
    }

    if (req.files.background && req.files.background[0]) {
      const file = req.files.background[0];
      const mediaUrl = `/api/settings/media/wallpapers/${file.filename}`;
      const isVideo = file.mimetype.startsWith('video/');
      SettingsModel.set('background_url', mediaUrl);
      SettingsModel.set('background_type', isVideo ? 'video_url' : 'image_url');
      results.background = mediaUrl;
      results.backgroundType = isVideo ? 'video' : 'image';
    }

    if (req.files.music && req.files.music[0]) {
      const file = req.files.music[0];
      const mediaUrl = `/api/settings/media/audio/${file.filename}`;
      SettingsModel.set('music_url', mediaUrl);
      SettingsModel.set('music_type', 'upload');
      SettingsModel.set('music_title', file.originalname);
      results.music = mediaUrl;
      results.musicTitle = file.originalname;
    }

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'MEDIA_UPLOAD',
      details: `Admin uploaded media assets: ${Object.keys(results).join(', ')}`
    });

    res.json({
      success: true,
      message: 'Media uploaded successfully.',
      results,
      settings: SettingsModel.getAll()
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Static media server route
router.get('/media/:folder/:filename', (req, res) => {
  const { folder, filename } = req.params;
  const safeFolder = folder.replace(/[^a-zA-Z0-9_-]/g, '');
  const safeFile = filename.replace(/[^a-zA-Z0-9_.-]/g, '');
  const filePath = path.resolve(CONFIG.UPLOAD_DIR, safeFolder, safeFile);

  if (fs.existsSync(filePath)) {
    return res.sendFile(filePath);
  }
  return res.status(404).send('Media file not found');
});

// Test SMTP configuration
router.post('/test-email', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { to } = req.body;
    const host = SettingsModel.get('smtp_host');
    if (!host) {
      return res.status(400).json({ success: false, message: 'SMTP is not configured yet. Please enter SMTP Host and details.' });
    }
    // Simulation / nodemailer test
    res.json({ success: true, message: `Test email simulated successfully to ${to || req.user.email}` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

