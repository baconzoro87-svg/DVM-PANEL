const express = require('express');
const router = express.Router();
const { UserModel, LoginHistoryModel, ActivityLogModel, SettingsModel } = require('../db/models');
const { hashPassword, comparePassword, generate2FASecret, generate2FAQRCode, verify2FAToken } = require('../utils/security');
const { authenticateToken } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

// Get current profile
router.get('/profile', authenticateToken, (req, res) => {
  const user = UserModel.findById(req.user.id);
  res.json({ success: true, user });
});

// Update profile info / avatar
router.put('/profile', authenticateToken, upload.single('avatar'), (req, res) => {
  try {
    const { username, email } = req.body;
    const updates = {};

    if (username && username !== req.user.username) {
      const existing = UserModel.findByUsername(username);
      if (existing && existing.id !== req.user.id) {
        return res.status(400).json({ success: false, message: 'Username is already taken.' });
      }
      updates.username = username;
    }

    if (email && email !== req.user.email) {
      const existing = UserModel.findByEmail(email);
      if (existing && existing.id !== req.user.id) {
        return res.status(400).json({ success: false, message: 'Email is already in use.' });
      }
      updates.email = email;
    }

    if (req.file) {
      updates.avatar = `/api/settings/media/avatars/${req.file.filename}`;
    }

    const updated = UserModel.update(req.user.id, updates);
    res.json({ success: true, message: 'Profile updated.', user: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Change Password
router.put('/password', authenticateToken, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword || newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'Current password and minimum 6 character new password required.' });
    }

    const fullUser = UserModel.findByIdFull(req.user.id);
    const isMatch = await comparePassword(currentPassword, fullUser.password_hash);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect.' });
    }

    const password_hash = await hashPassword(newPassword);
    UserModel.update(req.user.id, { password_hash });

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'USER_PASSWORD_CHANGE',
      details: 'User updated account password'
    });

    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Setup 2FA - Step 1: Generate QR Code & Secret
router.post('/2fa/setup', authenticateToken, async (req, res) => {
  try {
    const panelName = SettingsModel.get('panel_name', 'dpanel');
    const { secret, otpauthUrl } = generate2FASecret(req.user.username, panelName);
    const qrCodeUrl = await generate2FAQRCode(otpauthUrl);

    // Save temporary secret to user
    UserModel.update(req.user.id, { two_factor_secret: secret });

    res.json({
      success: true,
      secret,
      qrCodeUrl,
      otpauthUrl
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Setup 2FA - Step 2: Confirm code and activate
router.post('/2fa/enable', authenticateToken, (req, res) => {
  try {
    const { code } = req.body;
    const fullUser = UserModel.findByIdFull(req.user.id);

    if (!fullUser.two_factor_secret) {
      return res.status(400).json({ success: false, message: '2FA setup was not initiated.' });
    }

    const isValid = verify2FAToken(code, fullUser.two_factor_secret);
    if (!isValid) {
      return res.status(400).json({ success: false, message: 'Invalid verification code. Please check your Authenticator app.' });
    }

    UserModel.update(req.user.id, { two_factor_enabled: 1 });

    ActivityLogModel.create({
      user_id: req.user.id,
      action: '2FA_ENABLED',
      details: 'Two-Factor Authentication enabled'
    });

    res.json({ success: true, message: 'Two-Factor Authentication enabled successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Disable 2FA
router.post('/2fa/disable', authenticateToken, async (req, res) => {
  try {
    const { password } = req.body;
    const fullUser = UserModel.findByIdFull(req.user.id);

    const isMatch = await comparePassword(password, fullUser.password_hash);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Incorrect password.' });
    }

    UserModel.update(req.user.id, {
      two_factor_enabled: 0,
      two_factor_secret: null
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      action: '2FA_DISABLED',
      details: 'Two-Factor Authentication disabled'
    });

    res.json({ success: true, message: 'Two-Factor Authentication disabled.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// User Login History & Personal Activity
router.get('/activity', authenticateToken, (req, res) => {
  const loginHistory = LoginHistoryModel.getByUserId(req.user.id, 20);
  const activities = ActivityLogModel.getByUserId(req.user.id, 30);
  res.json({
    success: true,
    loginHistory,
    activities
  });
});

module.exports = router;

