const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const { ServerModel, UserModel, SubuserModel, BackupModel, ScheduleModel, ActivityLogModel, PlanModel } = require('../db/models');
const { authenticateToken, requireServerAccess } = require('../middleware/auth');
const { containerFileUpload } = require('../middleware/upload');
const DockerService = require('../services/dockerService');
const FileService = require('../services/fileService');
const BackupService = require('../services/backupService');
const SchedulerService = require('../services/schedulerService');
const TerminalService = require('../services/terminalService');
const StatsService = require('../services/statsService');
const { allocateNextFreePort } = require('../utils/ports');
const { getUserQuota, validateResourceAllocation, parseRamToMb } = require('../utils/quota');
const CONFIG = require('../config');

// Get available plans for VM creation / presets
router.get('/plans', authenticateToken, async (req, res) => {
  try {
    const plans = PlanModel.getAll();
    res.json({ success: true, plans });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get user's resource limits and remaining quota
router.get('/user/quota', authenticateToken, async (req, res) => {
  try {
    const excludeServerId = req.query.excludeServerId ? parseInt(req.query.excludeServerId, 10) : null;
    const quota = getUserQuota(req.user, excludeServerId);
    res.json({ success: true, quota });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// List all accessible servers for user
router.get('/', authenticateToken, async (req, res) => {
  try {
    let servers = [];
    if (req.user.role === 'admin') {
      servers = ServerModel.getAll();
    } else {
      servers = ServerModel.getAccessibleByUser(req.user.id);
    }

    // Attach live docker status to each server
    const enriched = await Promise.all(servers.map(async (srv) => {
      const dockerStatus = await DockerService.getStatus(srv.name);
      return {
        ...srv,
        status: dockerStatus || srv.status
      };
    }));

    res.json({ success: true, servers: enriched });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Create new VM
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      name,
      hostname,
      image,
      port_ssh,
      memory_limit,
      cpu_limit,
      disk_limit,
      env_vars,
      additional_ports,
      ssh_user = 'root',
      ssh_password = 'root'
    } = req.body;

    const vmName = (name || CONFIG.DEFAULT_VM_SPECS.NAME).toLowerCase().replace(/[^a-z0-9_-]/g, '');
    const vmHostname = hostname || vmName || CONFIG.DEFAULT_VM_SPECS.HOSTNAME;
    const vmImage = image || CONFIG.SUPPORTED_IMAGES[0].id;
    const ram = memory_limit || CONFIG.DEFAULT_VM_SPECS.RAM;
    const cpus = cpu_limit || CONFIG.DEFAULT_VM_SPECS.CPUS;
    const ssd = disk_limit || CONFIG.DEFAULT_VM_SPECS.DISK_SIZE;
    const cleanSshUser = String(ssh_user).trim() || 'root';
    const cleanSshPass = String(ssh_password).trim() || 'root';

    // Check if name is already taken
    const existing = ServerModel.findByName(vmName);
    if (existing) {
      return res.status(400).json({ success: false, message: `A VM named "${vmName}" already exists. Please choose another name.` });
    }

    // Validate resource limits against user's allocated quota
    const quotaValidation = validateResourceAllocation(req.user, {
      ram,
      cpus,
      disk_size: ssd
    });

    if (!quotaValidation.valid) {
      return res.status(403).json({
        success: false,
        message: quotaValidation.message
      });
    }

    // Allocate port in 25501-25599 range
    let allocatedPort;
    try {
      allocatedPort = await allocateNextFreePort(port_ssh ? parseInt(port_ssh, 10) : null);
    } catch (portErr) {
      return res.status(400).json({ success: false, message: 'Port allocation failed: ' + portErr.message });
    }

    const serverUuid = uuidv4();

    // Default & Custom Launch Environment Variables
    const defaultEnv = {
      VM_NAME: vmName,
      HOSTNAME: vmHostname,
      RAM: String(ram).toUpperCase(),
      CPUS: String(cpus),
      DISK_SIZE: String(ssd).toUpperCase()
    };
    let customEnv = {};
    if (typeof env_vars === 'string') {
      try { customEnv = JSON.parse(env_vars); } catch(e) {}
    } else if (typeof env_vars === 'object' && env_vars !== null) {
      customEnv = env_vars;
    }
    const mergedEnv = { ...defaultEnv, ...customEnv };

    // Create container via DockerService
    console.log(`[Create VM] Creating container: ${vmName} on port ${allocatedPort}...`);
    const containerResult = await DockerService.createVM({
      name: vmName,
      hostname: vmHostname,
      image: vmImage,
      port_ssh: allocatedPort,
      ram,
      cpus,
      disk_size: ssd,
      env_vars: mergedEnv,
      additional_ports: Array.isArray(additional_ports) ? additional_ports : []
    });

    const newServer = ServerModel.create({
      uuid: serverUuid,
      name: vmName,
      hostname: vmHostname,
      image: vmImage,
      port_ssh: allocatedPort,
      additional_ports: JSON.stringify(additional_ports || []),
      memory_limit: ram,
      cpu_limit: String(cpus),
      disk_limit: ssd,
      user_id: req.user.id,
      container_id: containerResult.containerId,
      status: 'running',
      env_vars: JSON.stringify(mergedEnv),
      ssh_user: cleanSshUser,
      ssh_password: cleanSshPass,
      auto_suspend_type: req.body.auto_suspend_type || 'hours',
      auto_suspend_hours: parseInt(req.body.auto_suspend_hours, 10) || 0,
      auto_suspend_at: req.body.auto_suspend_at || null,
      auto_suspend_time: req.body.auto_suspend_time || ''
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: newServer.id,
      action: 'SERVER_CREATE',
      details: `Created VM "${vmName}" (${vmImage}) on port ${allocatedPort}`
    });

    res.status(201).json({
      success: true,
      message: 'Virtual Machine created and started successfully.',
      server: { ...newServer, status: 'running' }
    });
  } catch (err) {
    console.error('[Create VM] Error:', err);
    res.status(500).json({ success: false, message: 'Failed to create VM: ' + err.message });
  }
});

// Get single server details
router.get('/:id', authenticateToken, requireServerAccess(), async (req, res) => {
  try {
    const dockerStatus = await DockerService.getStatus(req.server.name);
    const stats = await DockerService.getStats(req.server.name);

    res.json({
      success: true,
      server: {
        ...req.server,
        status: dockerStatus
      },
      stats,
      accessLevel: req.accessLevel
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get live real-time analytics and performance history
router.get('/:id/analytics', authenticateToken, requireServerAccess(), async (req, res) => {
  try {
    const analytics = await StatsService.getServerAnalytics(req.server);
    res.json(analytics);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get detailed network telemetry and port mapping info
router.get('/:id/network', authenticateToken, requireServerAccess(), async (req, res) => {
  try {
    const analytics = await StatsService.getServerAnalytics(req.server);
    let additionalPorts = [];
    try {
      additionalPorts = JSON.parse(req.server.additional_ports || '[]');
    } catch (e) {}

    res.json({
      success: true,
      server: {
        id: req.server.id,
        name: req.server.name,
        status: analytics.status,
        port_ssh: req.server.port_ssh,
        additional_ports: additionalPorts
      },
      network: analytics.network,
      currentStats: analytics.current
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Add additional port allocation / forward
router.post('/:id/network/ports', authenticateToken, requireServerAccess('settings'), async (req, res) => {
  try {
    const { containerPort, hostPort, protocol = 'TCP' } = req.body;
    if (!containerPort) {
      return res.status(400).json({ success: false, message: 'Container internal port is required.' });
    }

    let allocatedHostPort = hostPort ? parseInt(hostPort, 10) : null;
    if (!allocatedHostPort) {
      allocatedHostPort = await allocateNextFreePort();
    }

    let current = [];
    try {
      current = JSON.parse(req.server.additional_ports || '[]');
    } catch (e) {}

    current.push({
      host: allocatedHostPort,
      container: parseInt(containerPort, 10),
      protocol: protocol.toUpperCase(),
      created_at: new Date().toISOString()
    });

    ServerModel.update(req.server.id, {
      additional_ports: JSON.stringify(current)
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'PORT_ALLOCATED',
      details: `Mapped Host Port ${allocatedHostPort} -> Container Port ${containerPort} (${protocol})`
    });

    res.json({
      success: true,
      message: `Port ${allocatedHostPort} -> ${containerPort} allocated successfully. (Restart VM to apply if not active)`,
      port: { host: allocatedHostPort, container: parseInt(containerPort, 10), protocol }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Delete port mapping
router.delete('/:id/network/ports/:index', authenticateToken, requireServerAccess('settings'), async (req, res) => {
  try {
    const idx = parseInt(req.params.index, 10);
    let current = [];
    try {
      current = JSON.parse(req.server.additional_ports || '[]');
    } catch (e) {}

    if (idx < 0 || idx >= current.length) {
      return res.status(404).json({ success: false, message: 'Port mapping index not found.' });
    }

    const removed = current.splice(idx, 1)[0];
    ServerModel.update(req.server.id, {
      additional_ports: JSON.stringify(current)
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'PORT_REMOVED',
      details: `Removed port mapping ${removed.host}:${removed.container}`
    });

    res.json({ success: true, message: 'Port mapping removed successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Power actions: start, stop, restart, kill
router.post('/:id/power', authenticateToken, requireServerAccess('control'), async (req, res) => {
  try {
    const { action } = req.body;
    const serverName = req.server.name;

    if (!['start', 'stop', 'restart', 'kill'].includes(action)) {
      return res.status(400).json({ success: false, message: 'Invalid power action.' });
    }

    if (req.server.is_suspended || req.server.status === 'suspended') {
      return res.status(403).json({
        success: false,
        message: `This Virtual Machine is currently SUSPENDED (${req.server.suspend_reason || 'Suspended'}). It cannot be turned on until an Administrator unsuspends it.`
      });
    }

    console.log(`[Power Action] ${action.toUpperCase()} on ${serverName}`);

    if (action === 'start') {
      await DockerService.startVM(serverName);
    } else if (action === 'stop') {
      TerminalService.killSession(req.server.id);
      await DockerService.stopVM(serverName);
    } else if (action === 'restart') {
      TerminalService.killSession(req.server.id);
      await DockerService.restartVM(serverName);
    } else if (action === 'kill') {
      TerminalService.killSession(req.server.id);
      await DockerService.killVM(serverName);
    }

    const currentStatus = await DockerService.getStatus(serverName);
    ServerModel.update(req.server.id, { status: currentStatus });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: `SERVER_${action.toUpperCase()}`,
      details: `Power action "${action}" executed by ${req.user.username}`
    });

    res.json({
      success: true,
      message: `Server ${action} successful.`,
      status: currentStatus
    });
  } catch (err) {
    res.status(500).json({ success: false, message: `Power action failed: ${err.message}` });
  }
});

// Update server settings / resources
router.put('/:id', authenticateToken, requireServerAccess('settings'), async (req, res) => {
  try {
    const { name, hostname, memory_limit, cpu_limit, disk_limit, startup_cmd, env_vars, ssh_user, ssh_password } = req.body;
    const updates = {};
    const isAdmin = req.user && req.user.role === 'admin';

    const targetRam = memory_limit || req.server.memory_limit;
    const targetCpus = cpu_limit || req.server.cpu_limit;
    const targetDisk = disk_limit || req.server.disk_limit;

    // Validate resource limits against user's allocated quota
    if (!isAdmin) {
      const quotaCheck = validateResourceAllocation(req.user, {
        ram: targetRam,
        cpus: targetCpus,
        disk_size: targetDisk
      }, req.server.id);

      if (!quotaCheck.valid) {
        return res.status(403).json({
          success: false,
          message: quotaCheck.message
        });
      }
    }

    if (name) updates.name = name.trim().toLowerCase();
    if (hostname) updates.hostname = hostname.trim();
    if (memory_limit) updates.memory_limit = memory_limit;
    if (cpu_limit) updates.cpu_limit = String(cpu_limit);
    if (disk_limit) updates.disk_limit = disk_limit;

    if (startup_cmd !== undefined) updates.startup_cmd = startup_cmd;
    if (env_vars !== undefined) updates.env_vars = typeof env_vars === 'string' ? env_vars : JSON.stringify(env_vars);
    if (ssh_user) updates.ssh_user = String(ssh_user).trim();
    if (ssh_password) updates.ssh_password = String(ssh_password).trim();
    if (req.body.auto_suspend_type !== undefined) updates.auto_suspend_type = req.body.auto_suspend_type;
    if (req.body.auto_suspend_hours !== undefined) updates.auto_suspend_hours = parseInt(req.body.auto_suspend_hours, 10) || 0;
    if (req.body.auto_suspend_at !== undefined) updates.auto_suspend_at = req.body.auto_suspend_at;
    if (req.body.auto_suspend_time !== undefined) updates.auto_suspend_time = req.body.auto_suspend_time;

    if (updates.ssh_password || updates.ssh_user) {
      const targetUser = updates.ssh_user || req.server.ssh_user || 'root';
      const targetPass = updates.ssh_password || req.server.ssh_password || 'root';
      try {
        const { Client } = require('ssh2');
        const conn = new Client();
        conn.on('ready', () => {
          conn.exec(`echo "${targetUser}:${targetPass}" | chpasswd`, () => {
            conn.end();
          });
        }).on('error', () => {}).connect({
          host: '127.0.0.1',
          port: req.server.port_ssh,
          username: req.server.ssh_user || 'root',
          password: req.server.ssh_password || 'root',
          readyTimeout: 3000
        });
      } catch (e) {}
    }

    const updated = ServerModel.update(req.server.id, updates);

    // If server container is running and memory/cpu changed, dynamically apply resource update via docker
    if (memory_limit || cpu_limit) {
      try {
        const ramMb = parseRamToMb(targetRam);
        const overheadMb = Math.max(768, Math.round(ramMb * 0.5));
        const containerMem = `${ramMb + overheadMb}m`;
        const { exec } = require('child_process');
        exec(`docker update --memory "${containerMem}" --cpus "${targetCpus}" "${req.server.name}"`, () => {});
      } catch (e) {}
    }

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'SERVER_UPDATE',
      details: `Server configuration & resources updated`
    });

    res.json({ success: true, message: 'Server settings & resource limits updated successfully.', server: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Delete Server
router.delete('/:id', authenticateToken, requireServerAccess('settings'), async (req, res) => {
  try {
    const serverName = req.server.name;
    console.log(`[Delete Server] Removing container: ${serverName}`);

    TerminalService.killSession(req.server.id);

    // Remove docker container
    await DockerService.removeVM(serverName);

    // Delete DB record
    ServerModel.delete(req.server.id);

    ActivityLogModel.create({
      user_id: req.user.id,
      action: 'SERVER_DELETE',
      details: `Deleted VM "${serverName}"`
    });

    res.json({ success: true, message: 'Server deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Reinstall OS Image
router.post('/:id/reinstall', authenticateToken, requireServerAccess('settings'), async (req, res) => {
  try {
    const { image } = req.body;
    const targetImage = image || req.server.image;
    const serverName = req.server.name;

    TerminalService.killSession(req.server.id);

    console.log(`[Reinstall OS] Reinstalling ${serverName} with image ${targetImage}...`);

    // Remove old container
    await DockerService.removeVM(serverName);

    // Recreate container from clean image
    const containerResult = await DockerService.createVM({
      name: serverName,
      hostname: req.server.hostname,
      image: targetImage,
      port_ssh: req.server.port_ssh,
      ram: req.server.memory_limit,
      cpus: req.server.cpu_limit,
      disk_size: req.server.disk_limit
    });

    const updated = ServerModel.update(req.server.id, {
      image: targetImage,
      container_id: containerResult.containerId,
      status: 'running'
    });

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'SERVER_REINSTALL',
      details: `Reinstalled OS image to "${targetImage}"`
    });

    res.json({ success: true, message: 'OS reinstalled successfully.', server: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Reinstall failed: ' + err.message });
  }
});

// ----------------------------------------------------
// FILE MANAGER ROUTES
// ----------------------------------------------------

// List files
router.get('/:id/files', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const directory = req.query.path || '/root';
    const result = await FileService.listFiles(req.server, directory);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Read file content
router.get('/:id/files/content', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const filePath = req.query.path;
    if (!filePath) return res.status(400).json({ success: false, message: 'Path is required.' });

    const file = await FileService.readFile(req.server, filePath);
    res.json({ success: true, ...file });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Save file content
router.post('/:id/files/save', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const { path: filePath, content } = req.body;
    if (!filePath || content === undefined) {
      return res.status(400).json({ success: false, message: 'File path and content are required.' });
    }

    await FileService.writeFile(req.server, filePath, content);

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'FILE_EDIT',
      details: `Edited file: ${filePath}`
    });

    res.json({ success: true, message: 'File saved successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Create folder
router.post('/:id/files/folder', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const { path: dirPath } = req.body;
    if (!dirPath) return res.status(400).json({ success: false, message: 'Directory path is required.' });

    await FileService.createDirectory(req.server, dirPath);
    res.json({ success: true, message: 'Directory created.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Delete file/folder
router.post('/:id/files/delete', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const { path: targetPath } = req.body;
    if (!targetPath) return res.status(400).json({ success: false, message: 'Path is required.' });

    await FileService.deletePath(req.server, targetPath);

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'FILE_DELETE',
      details: `Deleted: ${targetPath}`
    });

    res.json({ success: true, message: 'Path deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Rename / move
router.post('/:id/files/rename', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const { oldPath, newPath } = req.body;
    if (!oldPath || !newPath) {
      return res.status(400).json({ success: false, message: 'Old path and new path are required.' });
    }

    await FileService.renamePath(req.server, oldPath, newPath);
    res.json({ success: true, message: 'File renamed successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Upload file to container
router.post('/:id/files/upload', authenticateToken, requireServerAccess('files'), containerFileUpload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded.' });
    }
    const targetDir = req.body.path || '/root';
    await FileService.uploadFile(req.server, req.file.path, targetDir, req.file.originalname);

    ActivityLogModel.create({
      user_id: req.user.id,
      server_id: req.server.id,
      action: 'FILE_UPLOAD',
      details: `Uploaded file ${req.file.originalname} to ${targetDir}`
    });

    res.json({ success: true, message: 'File uploaded into container successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Download file from container
router.get('/:id/files/download', authenticateToken, requireServerAccess('files'), async (req, res) => {
  try {
    const targetPath = req.query.path;
    if (!targetPath) return res.status(400).json({ success: false, message: 'File path is required.' });

    await FileService.streamDownload(req.server, targetPath, res);
  } catch (err) {
    if (!res.headersSent) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
});

// ----------------------------------------------------
// BACKUPS ROUTES
// ----------------------------------------------------

router.get('/:id/backups', authenticateToken, requireServerAccess('backups'), (req, res) => {
  const backups = BackupModel.getByServerId(req.server.id);
  res.json({ success: true, backups });
});

router.post('/:id/backups', authenticateToken, requireServerAccess('backups'), async (req, res) => {
  try {
    const { name } = req.body;
    const backup = await BackupService.createBackup(req.server, name, req.user.id);
    res.status(201).json({ success: true, message: 'Backup created successfully.', backup });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/:id/backups/:backupId/restore', authenticateToken, requireServerAccess('backups'), async (req, res) => {
  try {
    const backupId = parseInt(req.params.backupId, 10);
    const result = await BackupService.restoreBackup(backupId, req.server, req.user.id);
    res.json({ success: true, message: result.message });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/:id/backups/:backupId', authenticateToken, requireServerAccess('backups'), async (req, res) => {
  try {
    const backupId = parseInt(req.params.backupId, 10);
    await BackupService.deleteBackup(backupId, req.user.id);
    res.json({ success: true, message: 'Backup deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/:id/backups/:backupId/download', authenticateToken, requireServerAccess('backups'), (req, res) => {
  try {
    const backupId = parseInt(req.params.backupId, 10);
    const backup = BackupModel.findById(backupId);
    if (!backup || backup.server_id !== req.server.id) {
      return res.status(404).json({ success: false, message: 'Backup not found.' });
    }

    const filePath = path.join(CONFIG.BACKUP_DIR, backup.filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ success: false, message: 'Backup file missing on disk.' });
    }

    res.download(filePath, backup.filename);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// SCHEDULES ROUTES
// ----------------------------------------------------

router.get('/:id/schedules', authenticateToken, requireServerAccess('schedules'), (req, res) => {
  const schedules = ScheduleModel.getByServerId(req.server.id);
  res.json({ success: true, schedules });
});

router.post('/:id/schedules', authenticateToken, requireServerAccess('schedules'), (req, res) => {
  try {
    const { name, cron_expression, action, payload, is_active } = req.body;
    if (!name || !cron_expression || !action) {
      return res.status(400).json({ success: false, message: 'Name, cron expression, and action are required.' });
    }

    const sched = ScheduleModel.create({
      server_id: req.server.id,
      name,
      cron_expression,
      action,
      payload: payload || '',
      is_active: is_active !== undefined ? (is_active ? 1 : 0) : 1
    });

    SchedulerService.refreshAll();
    res.status(201).json({ success: true, message: 'Schedule created.', schedule: sched });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/:id/schedules/:schedId', authenticateToken, requireServerAccess('schedules'), (req, res) => {
  try {
    const schedId = parseInt(req.params.schedId, 10);
    const updated = ScheduleModel.update(schedId, req.body);
    SchedulerService.refreshAll();
    res.json({ success: true, message: 'Schedule updated.', schedule: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/:id/schedules/:schedId', authenticateToken, requireServerAccess('schedules'), (req, res) => {
  try {
    const schedId = parseInt(req.params.schedId, 10);
    ScheduleModel.delete(schedId);
    SchedulerService.refreshAll();
    res.json({ success: true, message: 'Schedule deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ----------------------------------------------------
// SUBUSERS ROUTES
// ----------------------------------------------------

router.get('/:id/subusers', authenticateToken, requireServerAccess('settings'), (req, res) => {
  const subusers = SubuserModel.getByServerId(req.server.id);
  res.json({ success: true, subusers });
});

router.post('/:id/subusers', authenticateToken, requireServerAccess('settings'), (req, res) => {
  try {
    const { email, permissions } = req.body;
    if (!email) return res.status(400).json({ success: false, message: 'User email is required.' });

    const targetUser = UserModel.findByEmail(email);
    if (!targetUser) {
      return res.status(404).json({ success: false, message: 'No registered user found with that email.' });
    }

    if (targetUser.id === req.server.user_id) {
      return res.status(400).json({ success: false, message: 'The server owner cannot be added as a subuser.' });
    }

    const existing = SubuserModel.findByServerAndUser(req.server.id, targetUser.id);
    if (existing) {
      return res.status(400).json({ success: false, message: 'This user is already a subuser of this server.' });
    }

    const sub = SubuserModel.create({
      server_id: req.server.id,
      user_id: targetUser.id,
      permissions: permissions || ['console', 'control']
    });

    res.status(201).json({ success: true, message: 'Subuser added successfully.', subuser: sub });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/:id/subusers/:subId', authenticateToken, requireServerAccess('settings'), (req, res) => {
  try {
    const subId = parseInt(req.params.subId, 10);
    const { permissions } = req.body;
    const updated = SubuserModel.update(subId, permissions);
    res.json({ success: true, message: 'Subuser permissions updated.', subuser: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/:id/subusers/:subId', authenticateToken, requireServerAccess('settings'), (req, res) => {
  try {
    const subId = parseInt(req.params.subId, 10);
    SubuserModel.delete(subId);
    res.json({ success: true, message: 'Subuser removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Server Activity
router.get('/:id/activity', authenticateToken, requireServerAccess(), (req, res) => {
  const activities = ActivityLogModel.getByServerId(req.server.id, 50);
  res.json({ success: true, activities });
});

module.exports = router;

