#!/bin/bash
set -e

cd /vm 2>/dev/null || true

# Environment variables
VM_NAME_VAL="${VM_NAME:-myvm}"
VM_HOST_VAL="${HOSTNAME:-myserver}"
RAM_VAL="${RAM:-1G}"
CPUS_VAL="${CPUS:-1}"
DISK_VAL="${DISK_SIZE:-10G}"
SSH_USER_VAL="${SSH_USER:-root}"
SSH_PASS_VAL="${SSH_PASSWORD:-root}"

# RAM conversion for QEMU -m (MB)
if [[ "$RAM_VAL" =~ [gG]$ ]]; then
    RAM_NUM="${RAM_VAL%[gG]*}"
    RAM_MB=$(echo "$RAM_NUM * 1024" | bc 2>/dev/null || awk "BEGIN {print int($RAM_NUM * 1024)}")
elif [[ "$RAM_VAL" =~ [mM]$ ]]; then
    RAM_MB="${RAM_VAL%[mM]*}"
else
    RAM_MB="${RAM_VAL}"
fi
RAM_MB=$(printf "%.0f" "$RAM_MB" 2>/dev/null || echo "1024")
if [ -z "$RAM_MB" ] || [ "$RAM_MB" -le 0 ] 2>/dev/null; then
    RAM_MB=1024
fi

# Detect disk image file in /vm
DISK_FILE=$(find /vm -maxdepth 1 \( -name "*.qcow2" -o -name "*.img" -o -name "*.raw" \) 2>/dev/null | head -n 1)
if [ -z "$DISK_FILE" ]; then
    echo "[!] No disk image found in /vm"
    exit 1
fi

echo "[i] Found VM disk: ${DISK_FILE}"

# Resize disk image safely
if [ -n "$DISK_VAL" ]; then
    echo "[i] Resizing disk to ${DISK_VAL}..."
    qemu-img resize "${DISK_FILE}" "${DISK_VAL}" >/dev/null 2>&1 || true
fi

# Generate cloud-init configuration
echo "[i] Generating cloud-init metadata for ${VM_HOST_VAL}..."
cat << USER_DATA > user-data
#cloud-config
hostname: ${VM_HOST_VAL}
manage_etc_hosts: true
user: ${SSH_USER_VAL}
password: ${SSH_PASS_VAL}
chpasswd:
  expire: false
ssh_pwauth: true
disable_root: false
runcmd:
  - echo "${SSH_USER_VAL}:${SSH_PASS_VAL}" | chpasswd
  - sed -i 's/#*PermitRootLogin.*/PermitRootLogin yes/g' /etc/ssh/sshd_config
  - sed -i 's/PermitRootLogin.*/PermitRootLogin yes/g' /etc/ssh/sshd_config
  - sed -i 's/#*PasswordAuthentication.*/PasswordAuthentication yes/g' /etc/ssh/sshd_config
  - sed -i 's/PasswordAuthentication.*/PasswordAuthentication yes/g' /etc/ssh/sshd_config
  - sed -i 's/#*PubkeyAuthentication.*/PubkeyAuthentication no/g' /etc/ssh/sshd_config
  - service ssh restart 2>/dev/null || /etc/init.d/ssh restart 2>/dev/null || true
USER_DATA

cat << META_DATA > meta-data
instance-id: ${VM_NAME_VAL}
local-hostname: ${VM_HOST_VAL}
META_DATA

cloud-localds seed.iso user-data meta-data

# Determine hardware acceleration
ACCEL_OPTS=""
if [ -c /dev/kvm ] && [ -w /dev/kvm ]; then
    echo "[i] KVM hardware acceleration detected and enabled."
    ACCEL_OPTS="-enable-kvm -cpu host"
else
    echo "[i] KVM device not available. Running with TCG multi-threaded emulation."
    ACCEL_OPTS="-accel tcg,thread=multi -cpu max"
fi

# Determine format
DISK_FORMAT="qcow2"
if [[ "$DISK_FILE" == *.raw ]]; then
    DISK_FORMAT="raw"
fi

echo "[i] Starting QEMU VM with ${RAM_MB}MB RAM and ${CPUS_VAL} CPU core(s)..."
exec qemu-system-x86_64 \
    ${ACCEL_OPTS} \
    -m "${RAM_MB}" \
    -smp "${CPUS_VAL}" \
    -nographic \
    -drive "file=${DISK_FILE},if=virtio,format=${DISK_FORMAT}" \
    -drive "file=/vm/seed.iso,if=virtio,format=raw" \
    -netdev "user,id=net0,hostfwd=tcp::22-:22" \
    -device "virtio-net-pci,netdev=net0"

