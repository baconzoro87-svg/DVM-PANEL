#!/usr/bin/env node
const readline = require('readline');
const { UserModel, PlanModel } = require('../db/models');
const { hashPassword } = require('../utils/security');

// Parse CLI flags: --username admin --email admin@dpanel.io --password secret --role admin
function parseArgs() {
  const args = process.argv.slice(2);
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].substring(2);
      const next = args[i + 1];
      if (next && !next.startsWith('--')) {
        flags[key] = next;
        i++;
      } else {
        flags[key] = true;
      }
    }
  }
  return flags;
}

function prompt(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => rl.question(question, ans => {
    rl.close();
    resolve(ans.trim());
  }));
}

async function run() {
  console.log('==============================================');
  console.log('       DVM Panel - User Creation Utility         ');
  console.log('==============================================\n');

  const flags = parseArgs();

  let username = flags.username;
  let email = flags.email;
  let password = flags.password;
  let role = flags.role || 'admin';
  let ram_limit = flags.ram || '4G';
  let cpu_limit = flags.cpu ? parseInt(flags.cpu, 10) : 4;
  let disk_limit = flags.disk || '40G';
  let max_servers = flags.servers ? parseInt(flags.servers, 10) : 10;

  if (!username) {
    username = await prompt('Enter Username [admin]: ') || 'admin';
  }

  if (!email) {
    email = await prompt(`Enter Email [${username}@dpanel.local]: `) || `${username}@dpanel.local`;
  }

  if (!password) {
    password = await prompt('Enter Password (min 6 characters): ');
    while (!password || password.length < 6) {
      console.log('⚠️ Password must be at least 6 characters.');
      password = await prompt('Enter Password: ');
    }
  }

  if (!flags.role) {
    const roleChoice = await prompt('Enter Role (1: admin, 2: user) [1]: ') || '1';
    role = roleChoice === '2' ? 'user' : 'admin';
  }

  // Check if user already exists
  const existingUser = UserModel.findByUsername(username);
  if (existingUser) {
    console.log(`\n⚠️ User "${username}" already exists (ID: ${existingUser.id}, Email: ${existingUser.email}).`);
    const updateChoice = await prompt('Would you like to reset/update this user\'s password? (Y/n) [Y]: ') || 'Y';
    if (updateChoice.toLowerCase().startsWith('y')) {
      const password_hash = await hashPassword(password);
      UserModel.update(existingUser.id, {
        password_hash,
        role: role || existingUser.role,
        status: 'active'
      });
      console.log('\n==============================================');
      console.log('✅ Password successfully updated!');
      console.log('----------------------------------------------');
      console.log(`   Username : ${existingUser.username}`);
      console.log(`   Email    : ${existingUser.email}`);
      console.log(`   Status   : ACTIVE`);
      console.log('==============================================\n');
      process.exit(0);
    } else {
      console.log('Operation cancelled.');
      process.exit(0);
    }
  }

  const existingEmail = UserModel.findByEmail(email);
  if (existingEmail) {
    console.error(`\n❌ Error: Email "${email}" is already registered by another account.`);
    process.exit(1);
  }

  try {
    const password_hash = await hashPassword(password);
    const user = UserModel.create({
      username,
      email,
      password_hash,
      role,
      ram_limit,
      cpu_limit,
      disk_limit,
      max_servers
    });

    console.log('\n==============================================');
    console.log('✅ User successfully created!');
    console.log('----------------------------------------------');
    console.log(`   ID       : ${user.id}`);
    console.log(`   Username : ${user.username}`);
    console.log(`   Email    : ${user.email}`);
    console.log(`   Role     : ${user.role.toUpperCase()}`);
    console.log(`   Limits   : ${user.max_servers} VMs | ${user.ram_limit} RAM | ${user.cpu_limit} Cores | ${user.disk_limit} SSD`);
    console.log('==============================================\n');
    process.exit(0);
  } catch (err) {
    console.error('\n❌ Failed to create user:', err.message);
    process.exit(1);
  }
}

run();

