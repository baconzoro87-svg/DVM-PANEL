const db = require('./index');

const UserModel = {
  findById: (id) => {
    return db.prepare('SELECT id, username, email, role, status, two_factor_enabled, avatar, ram_limit, cpu_limit, disk_limit, max_servers, created_at, updated_at FROM users WHERE id = ?').get(id);
  },

  findByIdFull: (id) => {
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  },

  findByEmail: (email) => {
    return db.prepare('SELECT * FROM users WHERE lower(email) = lower(?)').get(email);
  },

  findByUsername: (username) => {
    return db.prepare('SELECT * FROM users WHERE lower(username) = lower(?)').get(username);
  },

  findByEmailOrUsername: (identifier) => {
    return db.prepare('SELECT * FROM users WHERE lower(email) = lower(?) OR lower(username) = lower(?)').get(identifier, identifier);
  },

  getAll: () => {
    return db.prepare(`
      SELECT u.id, u.username, u.email, u.role, u.status, u.two_factor_enabled, u.avatar, 
             u.ram_limit, u.cpu_limit, u.disk_limit, u.max_servers, u.created_at,
             (SELECT COUNT(*) FROM servers WHERE servers.user_id = u.id) AS server_count
      FROM users u
      ORDER BY u.id DESC
    `).all();
  },

  create: ({ username, email, password_hash, role = 'user', ram_limit = '2G', cpu_limit = 2, disk_limit = '20G', max_servers = 3 }) => {
    const stmt = db.prepare(`
      INSERT INTO users (username, email, password_hash, role, status, ram_limit, cpu_limit, disk_limit, max_servers)
      VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?)
    `);
    const res = stmt.run(username, email, password_hash, role, ram_limit, cpu_limit, disk_limit, max_servers);
    return UserModel.findById(res.lastInsertRowid);
  },

  update: (id, fields) => {
    const allowed = ['username', 'email', 'role', 'status', 'avatar', 'ram_limit', 'cpu_limit', 'disk_limit', 'max_servers', 'password_hash', 'two_factor_secret', 'two_factor_enabled', 'reset_token', 'reset_token_expires'];
    const updates = [];
    const values = [];

    for (const [key, val] of Object.entries(fields)) {
      if (allowed.includes(key)) {
        updates.push(`${key} = ?`);
        values.push(val);
      }
    }

    if (updates.length === 0) return UserModel.findById(id);

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    db.prepare(query).run(...values);
    return UserModel.findById(id);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM users WHERE id = ?').run(id);
  },

  count: () => {
    return db.prepare('SELECT count(*) as count FROM users').get().count;
  }
};

const ServerModel = {
  findById: (id) => {
    return db.prepare(`
      SELECT s.*, u.username as owner_username, u.email as owner_email
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      WHERE s.id = ?
    `).get(id);
  },

  findByUuid: (uuid) => {
    return db.prepare(`
      SELECT s.*, u.username as owner_username, u.email as owner_email
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      WHERE s.uuid = ?
    `).get(uuid);
  },

  findByName: (name) => {
    return db.prepare('SELECT * FROM servers WHERE name = ?').get(name);
  },

  getAll: () => {
    return db.prepare(`
      SELECT s.*, u.username as owner_username, u.email as owner_email
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      ORDER BY s.id DESC
    `).all();
  },

  getByUserId: (userId) => {
    return db.prepare(`
      SELECT s.*, u.username as owner_username, u.email as owner_email
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      WHERE s.user_id = ?
      ORDER BY s.id DESC
    `).all(userId);
  },

  getAccessibleByUser: (userId) => {
    return db.prepare(`
      SELECT s.*, u.username as owner_username, u.email as owner_email,
             'owner' as access_level, '["all"]' as permissions
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      WHERE s.user_id = ?
      
      UNION
      
      SELECT s.*, u.username as owner_username, u.email as owner_email,
             'subuser' as access_level, sub.permissions
      FROM servers s
      LEFT JOIN users u ON s.user_id = u.id
      INNER JOIN subusers sub ON sub.server_id = s.id
      WHERE sub.user_id = ?
      
      ORDER BY id DESC
    `).all(userId, userId);
  },

  create: ({ uuid, name, hostname, image, port_ssh, additional_ports = '[]', memory_limit = '1G', cpu_limit = '1', disk_limit = '10G', user_id, container_id = null, status = 'stopped', env_vars = '{}', startup_cmd = '', ssh_user = 'root', ssh_password = 'root', auto_suspend_type = 'hours', auto_suspend_hours = 0, auto_suspend_at = null, auto_suspend_time = '', is_suspended = 0, suspend_reason = '' }) => {
    const stmt = db.prepare(`
      INSERT INTO servers (uuid, name, hostname, image, port_ssh, additional_ports, memory_limit, cpu_limit, disk_limit, user_id, container_id, status, env_vars, startup_cmd, ssh_user, ssh_password, auto_suspend_type, auto_suspend_hours, auto_suspend_at, auto_suspend_time, is_suspended, suspend_reason)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const res = stmt.run(uuid, name, hostname, image, port_ssh, additional_ports, memory_limit, cpu_limit, disk_limit, user_id, container_id, status, env_vars, startup_cmd, ssh_user, ssh_password, auto_suspend_type || 'hours', parseInt(auto_suspend_hours, 10) || 0, auto_suspend_at || null, auto_suspend_time || '', is_suspended ? 1 : 0, suspend_reason || '');
    return ServerModel.findById(res.lastInsertRowid);
  },

  update: (id, fields) => {
    const allowed = ['name', 'hostname', 'image', 'port_ssh', 'additional_ports', 'memory_limit', 'cpu_limit', 'disk_limit', 'user_id', 'container_id', 'status', 'env_vars', 'startup_cmd', 'ssh_user', 'ssh_password', 'auto_suspend_type', 'auto_suspend_hours', 'auto_suspend_at', 'auto_suspend_time', 'is_suspended', 'suspend_reason'];
    const updates = [];
    const values = [];

    for (const [key, val] of Object.entries(fields)) {
      if (allowed.includes(key)) {
        updates.push(`${key} = ?`);
        values.push(val);
      }
    }

    if (updates.length === 0) return ServerModel.findById(id);

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const query = `UPDATE servers SET ${updates.join(', ')} WHERE id = ?`;
    db.prepare(query).run(...values);
    return ServerModel.findById(id);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM servers WHERE id = ?').run(id);
  },

  getAllUsedPorts: () => {
    const rows = db.prepare('SELECT port_ssh, additional_ports FROM servers').all();
    const ports = new Set();
    for (const row of rows) {
      if (row.port_ssh) ports.add(Number(row.port_ssh));
      try {
        const extra = JSON.parse(row.additional_ports || '[]');
        for (const p of extra) {
          if (p.host) ports.add(Number(p.host));
        }
      } catch (e) {}
    }
    return ports;
  },

  count: () => {
    return db.prepare('SELECT count(*) as count FROM servers').get().count;
  },

  countRunning: () => {
    return db.prepare("SELECT count(*) as count FROM servers WHERE status = 'running'").get().count;
  }
};

const SettingsModel = {
  getAll: () => {
    const rows = db.prepare('SELECT * FROM settings').all();
    const result = {};
    for (const row of rows) {
      result[row.key] = row.value;
    }
    return result;
  },

  getByCategory: (category) => {
    return db.prepare('SELECT * FROM settings WHERE category = ?').all(category);
  },

  get: (key, defaultValue = '') => {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : defaultValue;
  },

  set: (key, value, category = 'general') => {
    const stmt = db.prepare(`
      INSERT INTO settings (key, value, category) VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, category = excluded.category
    `);
    stmt.run(key, String(value), category);
    return value;
  },

  setMany: (settingsObj) => {
    const stmt = db.prepare(`
      INSERT INTO settings (key, value, category) VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `);
    for (const [key, value] of Object.entries(settingsObj)) {
      if (value !== undefined && value !== null) {
        stmt.run(key, String(value), 'general');
      }
    }
    return SettingsModel.getAll();
  }
};

const SubuserModel = {
  getByServerId: (serverId) => {
    return db.prepare(`
      SELECT sub.*, u.username, u.email, u.avatar
      FROM subusers sub
      JOIN users u ON sub.user_id = u.id
      WHERE sub.server_id = ?
    `).all(serverId);
  },

  findByServerAndUser: (serverId, userId) => {
    return db.prepare('SELECT * FROM subusers WHERE server_id = ? AND user_id = ?').get(serverId, userId);
  },

  create: ({ server_id, user_id, permissions = '["console","control"]' }) => {
    const stmt = db.prepare(`
      INSERT INTO subusers (server_id, user_id, permissions)
      VALUES (?, ?, ?)
    `);
    const res = stmt.run(server_id, user_id, typeof permissions === 'string' ? permissions : JSON.stringify(permissions));
    return db.prepare('SELECT * FROM subusers WHERE id = ?').get(res.lastInsertRowid);
  },

  update: (id, permissions) => {
    const perms = typeof permissions === 'string' ? permissions : JSON.stringify(permissions);
    db.prepare('UPDATE subusers SET permissions = ? WHERE id = ?').run(perms, id);
    return db.prepare('SELECT * FROM subusers WHERE id = ?').get(id);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM subusers WHERE id = ?').run(id);
  }
};

const BackupModel = {
  getByServerId: (serverId) => {
    return db.prepare('SELECT * FROM backups WHERE server_id = ? ORDER BY id DESC').all(serverId);
  },

  findById: (id) => {
    return db.prepare('SELECT * FROM backups WHERE id = ?').get(id);
  },

  findByUuid: (uuid) => {
    return db.prepare('SELECT * FROM backups WHERE uuid = ?').get(uuid);
  },

  create: ({ uuid, server_id, name, filename, size_bytes = 0, status = 'completed' }) => {
    const stmt = db.prepare(`
      INSERT INTO backups (uuid, server_id, name, filename, size_bytes, status)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const res = stmt.run(uuid, server_id, name, filename, size_bytes, status);
    return BackupModel.findById(res.lastInsertRowid);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM backups WHERE id = ?').run(id);
  }
};

const ScheduleModel = {
  getByServerId: (serverId) => {
    return db.prepare('SELECT * FROM schedules WHERE server_id = ? ORDER BY id DESC').all(serverId);
  },

  getAllActive: () => {
    return db.prepare('SELECT s.*, srv.name as server_name, srv.container_id, srv.status as server_status FROM schedules s JOIN servers srv ON s.server_id = srv.id WHERE s.is_active = 1').all();
  },

  findById: (id) => {
    return db.prepare('SELECT * FROM schedules WHERE id = ?').get(id);
  },

  create: ({ server_id, name, cron_expression, action, payload = '', is_active = 1 }) => {
    const stmt = db.prepare(`
      INSERT INTO schedules (server_id, name, cron_expression, action, payload, is_active)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const res = stmt.run(server_id, name, cron_expression, action, payload, is_active);
    return ScheduleModel.findById(res.lastInsertRowid);
  },

  update: (id, fields) => {
    const allowed = ['name', 'cron_expression', 'action', 'payload', 'is_active', 'last_run'];
    const updates = [];
    const values = [];

    for (const [key, val] of Object.entries(fields)) {
      if (allowed.includes(key)) {
        updates.push(`${key} = ?`);
        values.push(val);
      }
    }

    if (updates.length === 0) return ScheduleModel.findById(id);

    values.push(id);
    db.prepare(`UPDATE schedules SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    return ScheduleModel.findById(id);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM schedules WHERE id = ?').run(id);
  }
};

const ActivityLogModel = {
  create: ({ user_id = null, server_id = null, action, details = '', ip_address = '', user_agent = '' }) => {
    const stmt = db.prepare(`
      INSERT INTO activity_logs (user_id, server_id, action, details, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(user_id, server_id, action, details, ip_address, user_agent);
  },

  getRecent: (limit = 50) => {
    return db.prepare(`
      SELECT l.*, u.username, u.email, s.name as server_name
      FROM activity_logs l
      LEFT JOIN users u ON l.user_id = u.id
      LEFT JOIN servers s ON l.server_id = s.id
      ORDER BY l.id DESC
      LIMIT ?
    `).all(limit);
  },

  getByServerId: (serverId, limit = 50) => {
    return db.prepare(`
      SELECT l.*, u.username, u.email
      FROM activity_logs l
      LEFT JOIN users u ON l.user_id = u.id
      WHERE l.server_id = ?
      ORDER BY l.id DESC
      LIMIT ?
    `).all(serverId, limit);
  },

  getByUserId: (userId, limit = 50) => {
    return db.prepare(`
      SELECT l.*, s.name as server_name
      FROM activity_logs l
      LEFT JOIN servers s ON l.server_id = s.id
      WHERE l.user_id = ?
      ORDER BY l.id DESC
      LIMIT ?
    `).all(userId, limit);
  }
};

const LoginHistoryModel = {
  create: ({ user_id = null, username, ip_address = '', user_agent = '', status }) => {
    const stmt = db.prepare(`
      INSERT INTO login_history (user_id, username, ip_address, user_agent, status)
      VALUES (?, ?, ?, ?, ?)
    `);
    return stmt.run(user_id, username, ip_address, user_agent, status);
  },

  getRecent: (limit = 100) => {
    return db.prepare('SELECT * FROM login_history ORDER BY id DESC LIMIT ?').all(limit);
  },

  getByUserId: (userId, limit = 50) => {
    return db.prepare('SELECT * FROM login_history WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit);
  }
};

const TicketModel = {
  getAll: () => {
    return db.prepare(`
      SELECT t.*, u.username, u.email,
             (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as message_count
      FROM tickets t
      JOIN users u ON t.user_id = u.id
      ORDER BY t.updated_at DESC
    `).all();
  },

  getByUserId: (userId) => {
    return db.prepare(`
      SELECT t.*, u.username, u.email,
             (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as message_count
      FROM tickets t
      JOIN users u ON t.user_id = u.id
      WHERE t.user_id = ?
      ORDER BY t.updated_at DESC
    `).all(userId);
  },

  findById: (id) => {
    return db.prepare(`
      SELECT t.*, u.username, u.email
      FROM tickets t
      JOIN users u ON t.user_id = u.id
      WHERE t.id = ?
    `).get(id);
  },

  create: ({ user_id, title, priority = 'medium' }) => {
    const stmt = db.prepare(`
      INSERT INTO tickets (user_id, title, priority, status)
      VALUES (?, ?, ?, 'open')
    `);
    const res = stmt.run(user_id, title, priority);
    return TicketModel.findById(res.lastInsertRowid);
  },

  updateStatus: (id, status) => {
    db.prepare('UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(status, id);
    return TicketModel.findById(id);
  },

  getMessages: (ticketId) => {
    return db.prepare(`
      SELECT m.*, u.username, u.role, u.avatar
      FROM ticket_messages m
      JOIN users u ON m.user_id = u.id
      WHERE m.ticket_id = ?
      ORDER BY m.id ASC
    `).all(ticketId);
  },

  addMessage: ({ ticket_id, user_id, message }) => {
    const stmt = db.prepare(`
      INSERT INTO ticket_messages (ticket_id, user_id, message)
      VALUES (?, ?, ?)
    `);
    stmt.run(ticket_id, user_id, message);
    db.prepare('UPDATE tickets SET updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(ticket_id);
    return db.prepare('SELECT m.*, u.username, u.role, u.avatar FROM ticket_messages m JOIN users u ON m.user_id = u.id WHERE m.ticket_id = ? ORDER BY m.id DESC LIMIT 1').get(ticket_id);
  }
};

const PlanModel = {
  getAll: () => {
    return db.prepare('SELECT * FROM plans ORDER BY id ASC').all();
  },

  findById: (id) => {
    return db.prepare('SELECT * FROM plans WHERE id = ?').get(id);
  },

  getDefault: () => {
    return db.prepare('SELECT * FROM plans WHERE is_default = 1 LIMIT 1').get() || db.prepare('SELECT * FROM plans LIMIT 1').get();
  },

  create: ({ name, price = '₹0 / Free', max_servers = 3, max_ram = '2G', max_cpu = 2, max_disk = '20G', is_default = 0 }) => {
    if (is_default) {
      db.prepare('UPDATE plans SET is_default = 0').run();
    }
    const stmt = db.prepare(`
      INSERT INTO plans (name, price, max_servers, max_ram, max_cpu, max_disk, is_default)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const res = stmt.run(name, price || '₹0 / Free', max_servers, max_ram, max_cpu, max_disk, is_default ? 1 : 0);
    return PlanModel.findById(res.lastInsertRowid);
  },

  update: (id, fields) => {
    if (fields.is_default) {
      db.prepare('UPDATE plans SET is_default = 0').run();
    }
    const allowed = ['name', 'price', 'max_servers', 'max_ram', 'max_cpu', 'max_disk', 'is_default'];
    const updates = [];
    const values = [];
    for (const [k, v] of Object.entries(fields)) {
      if (allowed.includes(k)) {
        updates.push(`${k} = ?`);
        values.push(k === 'is_default' ? (v ? 1 : 0) : v);
      }
    }
    if (updates.length > 0) {
      values.push(id);
      db.prepare(`UPDATE plans SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    }
    return PlanModel.findById(id);
  },

  setDefault: (id) => {
    db.prepare('UPDATE plans SET is_default = 0').run();
    db.prepare('UPDATE plans SET is_default = 1 WHERE id = ?').run(id);
    return PlanModel.findById(id);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM plans WHERE id = ?').run(id);
  }
};

const ApiKeyModel = {
  getAll: () => {
    return db.prepare(`
      SELECT a.*, u.username, u.email
      FROM api_keys a
      JOIN users u ON a.user_id = u.id
      ORDER BY a.id DESC
    `).all();
  },

  getByUserId: (userId) => {
    return db.prepare('SELECT * FROM api_keys WHERE user_id = ? ORDER BY id DESC').all(userId);
  },

  create: ({ user_id, name, key_hash, prefix, permissions = '["all"]' }) => {
    const stmt = db.prepare(`
      INSERT INTO api_keys (user_id, name, key_hash, prefix, permissions)
      VALUES (?, ?, ?, ?, ?)
    `);
    const res = stmt.run(user_id, name, key_hash, prefix, typeof permissions === 'string' ? permissions : JSON.stringify(permissions));
    return db.prepare('SELECT * FROM api_keys WHERE id = ?').get(res.lastInsertRowid);
  },

  delete: (id) => {
    return db.prepare('DELETE FROM api_keys WHERE id = ?').run(id);
  }
};

module.exports = {
  UserModel,
  ServerModel,
  SettingsModel,
  SubuserModel,
  BackupModel,
  ScheduleModel,
  ActivityLogModel,
  LoginHistoryModel,
  TicketModel,
  PlanModel,
  ApiKeyModel
};

