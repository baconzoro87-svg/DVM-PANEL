const fs = require('fs');
const path = require('path');
const CONFIG = require('../config');

// Ensure data directory exists
if (!fs.existsSync(CONFIG.DATA_DIR)) {
  fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });
}
if (!fs.existsSync(CONFIG.UPLOAD_DIR)) {
  fs.mkdirSync(CONFIG.UPLOAD_DIR, { recursive: true });
}
if (!fs.existsSync(CONFIG.BACKUP_DIR)) {
  fs.mkdirSync(CONFIG.BACKUP_DIR, { recursive: true });
}

// Universal Crash-Proof SQLite Loader (node:sqlite built into Node 22+, better-sqlite3 for Node 18/20)
let db;
let engine = 'none';

// 1. Try Node.js official built-in zero-dependency SQLite first (Node 22+)
try {
  const { DatabaseSync } = require('node:sqlite');
  if (typeof DatabaseSync === 'function') {
    db = new DatabaseSync(CONFIG.DB_PATH);
    engine = 'node:sqlite';
  }
} catch (e) {
  // node:sqlite not present on older Node versions
}

// 2. If node:sqlite not available, safely probe and load better-sqlite3
if (!db) {
  try {
    const { execSync } = require('child_process');
    // Safety check in isolated child process to ensure better-sqlite3 does not segfault
    execSync('node -e "require(\'better-sqlite3\')"', { stdio: 'ignore', timeout: 3000 });
    const Database = require('better-sqlite3');
    db = new Database(CONFIG.DB_PATH);
    engine = 'better-sqlite3';
  } catch (e1) {
    try {
      const Database = require('better-sqlite3');
      db = new Database(CONFIG.DB_PATH);
      engine = 'better-sqlite3';
    } catch (e2) {
      console.error('Fatal: SQLite module not found or incompatible. Please upgrade to Node.js 22+ (which includes built-in SQLite) or install better-sqlite3.');
      throw e2;
    }
  }
}

// Enable WAL mode for better concurrency and foreign keys
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      status TEXT DEFAULT 'active',
      two_factor_secret TEXT,
      two_factor_enabled INTEGER DEFAULT 0,
      avatar TEXT DEFAULT '',
      ram_limit TEXT DEFAULT '2G',
      cpu_limit INTEGER DEFAULT 2,
      disk_limit TEXT DEFAULT '20G',
      max_servers INTEGER DEFAULT 3,
      reset_token TEXT,
      reset_token_expires DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS servers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      hostname TEXT NOT NULL,
      image TEXT NOT NULL,
      port_ssh INTEGER NOT NULL,
      additional_ports TEXT DEFAULT '[]',
      memory_limit TEXT DEFAULT '1G',
      cpu_limit TEXT DEFAULT '1',
      disk_limit TEXT DEFAULT '10G',
      user_id INTEGER NOT NULL,
      container_id TEXT,
      status TEXT DEFAULT 'stopped',
      env_vars TEXT DEFAULT '{}',
      startup_cmd TEXT DEFAULT '',
      ssh_user TEXT DEFAULT 'root',
      ssh_password TEXT DEFAULT 'root',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS subusers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      server_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      permissions TEXT NOT NULL DEFAULT '["console","control"]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS backups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT UNIQUE NOT NULL,
      server_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      filename TEXT NOT NULL,
      size_bytes INTEGER DEFAULT 0,
      status TEXT DEFAULT 'completed',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      server_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      cron_expression TEXT NOT NULL,
      action TEXT NOT NULL,
      payload TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      last_run DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      category TEXT DEFAULT 'general'
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      server_id INTEGER,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      user_agent TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS login_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT,
      ip_address TEXT,
      user_agent TEXT,
      status TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      status TEXT DEFAULT 'open',
      priority TEXT DEFAULT 'medium',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ticket_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      message TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price TEXT DEFAULT '₹0 / Free',
      max_servers INTEGER DEFAULT 3,
      max_ram TEXT DEFAULT '2G',
      max_cpu INTEGER DEFAULT 2,
      max_disk TEXT DEFAULT '20G',
      is_default INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS api_keys (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      key_hash TEXT NOT NULL,
      prefix TEXT NOT NULL,
      permissions TEXT DEFAULT '["all"]',
      last_used_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Safe migrations for newly added columns
  try { db.exec("ALTER TABLE plans ADD COLUMN price TEXT DEFAULT '₹0 / Free';"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN is_suspended INTEGER DEFAULT 0;"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN suspend_reason TEXT DEFAULT '';"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN auto_suspend_hours INTEGER DEFAULT 0;"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN auto_suspend_type TEXT DEFAULT 'hours';"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN auto_suspend_at DATETIME DEFAULT NULL;"); } catch (e) {}
  try { db.exec("ALTER TABLE servers ADD COLUMN auto_suspend_time TEXT DEFAULT '';"); } catch (e) {}

  // Seed default settings if empty
  const defaultSettings = [
    { key: 'panel_name', value: 'DVM Panel', category: 'general' },
    { key: 'panel_logo', value: '', category: 'general' },
    { key: 'panel_logo_url', value: '', category: 'general' },
    { key: 'panel_favicon_name', value: 'DVM Panel', category: 'general' },
    { key: 'panel_favicon_url', value: '', category: 'general' },
    { key: 'auto_suspend_enabled', value: 'false', category: 'general' },
    { key: 'auto_suspend_hours', value: '24', category: 'general' },
    { key: 'auto_suspend_action', value: 'stop', category: 'general' },
    { key: 'background_type', value: 'preset', category: 'appearance' },
    { key: 'background_url', value: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop', category: 'appearance' },
    { key: 'background_category', value: 'black-dark', category: 'appearance' },
    { key: 'transparency', value: '75', category: 'appearance' },
    { key: 'blur', value: '14', category: 'appearance' },
    { key: 'theme', value: 'dark-glass', category: 'appearance' },
    { key: 'accent_color', value: '#6366f1', category: 'appearance' },
    { key: 'custom_css', value: '', category: 'appearance' },
    { key: 'music_enabled', value: 'false', category: 'music' },
    { key: 'music_type', value: 'url', category: 'music' },
    { key: 'music_url', value: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3', category: 'music' },
    { key: 'music_title', value: 'Ambient Synthwave', category: 'music' },
    { key: 'music_volume', value: '45', category: 'music' },
    { key: 'music_autoplay', value: 'false', category: 'music' },
    { key: 'social_discord', value: 'https://discord.gg/', category: 'social' },
    { key: 'social_telegram', value: 'https://t.me/', category: 'social' },
    { key: 'social_github', value: 'https://github.com/', category: 'social' },
    { key: 'register_enabled', value: 'true', category: 'security' },
    { key: 'require_2fa', value: 'false', category: 'security' },
    { key: 'smtp_host', value: '', category: 'mail' },
    { key: 'smtp_port', value: '587', category: 'mail' },
    { key: 'smtp_user', value: '', category: 'mail' },
    { key: 'smtp_pass', value: '', category: 'mail' },
    { key: 'smtp_from', value: '', category: 'mail' }
  ];

  const insertSetting = db.prepare(`
    INSERT OR IGNORE INTO settings (key, value, category) VALUES (?, ?, ?)
  `);

  for (const s of defaultSettings) {
    insertSetting.run(s.key, s.value, s.category);
  }

  // Seed default plans
  const defaultPlans = [
    { name: 'Starter Free', price: '₹0 / Free', max_servers: 2, max_ram: '1G', max_cpu: 1, max_disk: '10G', is_default: 1 },
    { name: 'Pro VPS', price: '₹299 / mo', max_servers: 5, max_ram: '4G', max_cpu: 2, max_disk: '40G', is_default: 0 },
    { name: 'Enterprise Power', price: '₹999 / mo', max_servers: 15, max_ram: '16G', max_cpu: 8, max_disk: '160G', is_default: 0 }
  ];

  const countPlans = db.prepare('SELECT count(*) as count FROM plans').get();
  if (countPlans.count === 0) {
    const insertPlan = db.prepare(`
      INSERT INTO plans (name, price, max_servers, max_ram, max_cpu, max_disk, is_default)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const p of defaultPlans) {
      insertPlan.run(p.name, p.price, p.max_servers, p.max_ram, p.max_cpu, p.max_disk, p.is_default);
    }
  }

  // Seed default admin user if database is fresh
  const countUsers = db.prepare('SELECT count(*) as count FROM users').get();
  if (countUsers.count === 0) {
    const bcrypt = require('bcryptjs');
    const defaultHash = bcrypt.hashSync('admin123', 10);
    const insertAdmin = db.prepare(`
      INSERT INTO users (username, email, password_hash, role, status, ram_limit, cpu_limit, disk_limit, max_servers)
      VALUES (?, ?, ?, 'admin', 'active', '16G', 8, '160G', 50)
    `);
    insertAdmin.run('admin', 'admin@dpanel.io', defaultHash);
    console.log('[DB] Initialized default Administrator account (Username: admin / admin@dpanel.io, Password: admin123)');
  }
}

initSchema();

module.exports = db;

