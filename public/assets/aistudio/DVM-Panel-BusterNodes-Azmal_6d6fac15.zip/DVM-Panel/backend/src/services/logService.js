const { spawn } = require('child_process');
const { ServerModel } = require('../db/models');
const { verifyToken } = require('../utils/security');

class LogService {
  static handleConnection(ws, req) {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    const serverId = parseInt(url.searchParams.get('serverId'), 10);

    if (!token || !serverId) {
      ws.send('[dpanel Log Error] Missing authentication token or server ID.\r\n');
      return ws.close();
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      ws.send('[dpanel Log Error] Authentication token invalid or expired.\r\n');
      return ws.close();
    }

    const server = ServerModel.findById(serverId);
    if (!server) {
      ws.send('[dpanel Log Error] Server not found.\r\n');
      return ws.close();
    }

    // Check user/subuser permissions
    if (decoded.role !== 'admin' && server.user_id !== decoded.id) {
      const { SubuserModel } = require('../db/models');
      const subuser = SubuserModel.findByServerAndUser(serverId, decoded.id);
      if (!subuser) {
        ws.send('[dpanel Log Error] Access denied.\r\n');
        return ws.close();
      }
    }

    const containerName = server.name;

    ws.send(`\x1b[36m--- Connected to Live Real-Time Logs Stream for VM [${containerName}] ---\x1b[0m\r\n`);

    let logProcess;
    try {
      logProcess = spawn('docker', ['logs', '-f', '--tail', '200', containerName]);
    } catch (err) {
      ws.send(`\x1b[31mFailed to start log stream: ${err.message}\x1b[0m\r\n`);
      return ws.close();
    }

    logProcess.stdout.on('data', (data) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(data.toString('utf-8'));
      }
    });

    logProcess.stderr.on('data', (data) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(data.toString('utf-8'));
      }
    });

    logProcess.on('error', (err) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(`\r\n\x1b[31m[Log Stream Error]: ${err.message}\x1b[0m\r\n`);
      }
    });

    logProcess.on('exit', (code) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(`\r\n\x1b[33m[Log stream closed with code ${code}]\x1b[0m\r\n`);
        ws.close();
      }
    });

    ws.on('close', () => {
      if (logProcess && !logProcess.killed) {
        logProcess.kill('SIGTERM');
      }
    });
  }
}

module.exports = LogService;

