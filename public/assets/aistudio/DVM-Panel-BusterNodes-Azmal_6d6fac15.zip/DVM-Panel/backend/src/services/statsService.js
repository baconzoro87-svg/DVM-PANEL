const os = require('os');
const si = require('systeminformation');
const DockerService = require('./dockerService');
const { ServerModel, UserModel } = require('../db/models');

// Ring buffer for server performance analytics (max 60 points per server)
const serverHistoryMap = new Map();
const MAX_HISTORY_POINTS = 60;

class StatsService {
  /**
   * Get host system hardware & resource metrics
   */
  static async getHostStats() {
    try {
      const [cpuLoad, mem, fsSize, osInfo] = await Promise.all([
        si.currentLoad().catch(() => ({ currentLoad: 0, cpus: [] })),
        si.mem().catch(() => ({ total: os.totalmem(), free: os.freemem(), used: os.totalmem() - os.freemem() })),
        si.fsSize().catch(() => [{ size: 0, used: 0, available: 0, use: 0, mount: '/' }]),
        si.osInfo().catch(() => ({ platform: os.platform(), distro: 'Linux', release: os.release() }))
      ]);

      const mainDisk = fsSize.find(d => d.mount === '/') || fsSize[0] || { size: 100 * 1024 * 1024 * 1024, used: 10 * 1024 * 1024 * 1024, use: 10 };

      const totalServers = ServerModel.count();
      const runningServers = ServerModel.countRunning();
      const totalUsers = UserModel.count();

      return {
        cpu: {
          load_percent: Math.round(cpuLoad.currentLoad || 0),
          cores: os.cpus().length,
          model: os.cpus()[0] ? os.cpus()[0].model : 'Generic CPU'
        },
        memory: {
          total_bytes: mem.total,
          used_bytes: mem.used,
          free_bytes: mem.free,
          used_percent: Math.round((mem.used / mem.total) * 100)
        },
        disk: {
          total_bytes: mainDisk.size,
          used_bytes: mainDisk.used,
          free_bytes: mainDisk.available,
          used_percent: Math.round(mainDisk.use || 0)
        },
        os: {
          platform: osInfo.platform,
          distro: osInfo.distro,
          release: osInfo.release,
          uptime_seconds: os.uptime()
        },
        overview: {
          total_servers: totalServers,
          running_servers: runningServers,
          stopped_servers: totalServers - runningServers,
          total_users: totalUsers
        }
      };
    } catch (err) {
      console.error('[StatsService] Error getting host stats:', err);
      return {
        cpu: { load_percent: 0, cores: os.cpus().length, model: 'Generic CPU' },
        memory: { total_bytes: os.totalmem(), used_bytes: os.totalmem() - os.freemem(), free_bytes: os.freemem(), used_percent: 50 },
        disk: { total_bytes: 100000000000, used_bytes: 20000000000, free_bytes: 80000000000, used_percent: 20 },
        os: { platform: os.platform(), distro: 'Linux', release: os.release(), uptime_seconds: os.uptime() },
        overview: { total_servers: 0, running_servers: 0, stopped_servers: 0, total_users: 1 }
      };
    }
  }

  /**
   * Push sample to server time-series history
   */
  static recordSample(serverId, stats) {
    if (!serverHistoryMap.has(serverId)) {
      serverHistoryMap.set(serverId, []);
    }
    const history = serverHistoryMap.get(serverId);
    const now = new Date();
    const timeLabel = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    const point = {
      time: timeLabel,
      timestamp: Date.now(),
      cpu: stats.cpu_percent || 0,
      memoryPercent: stats.memory_percent || stats.memory?.percent || 0,
      memoryUsedMb: Math.round((stats.memory?.used_bytes || 0) / (1024 * 1024)),
      rxSpeedKb: Math.round((stats.network?.rx_speed_bytes || 0) / 1024 * 10) / 10,
      txSpeedKb: Math.round((stats.network?.tx_speed_bytes || 0) / 1024 * 10) / 10,
      rxBytes: stats.network?.rx_bytes || 0,
      txBytes: stats.network?.tx_bytes || 0,
      pids: stats.pids || 0
    };

    history.push(point);
    if (history.length > MAX_HISTORY_POINTS) {
      history.shift();
    }
    return history;
  }

  /**
   * Get server live analytics and historical time-series data
   */
  static async getServerAnalytics(server) {
    const status = await DockerService.getStatus(server.name);
    const stats = await DockerService.getStats(server.name);
    let history = serverHistoryMap.get(server.id) || [];

    if (status === 'running') {
      history = StatsService.recordSample(server.id, stats);
    }

    let additionalPorts = [];
    try {
      additionalPorts = JSON.parse(server.additional_ports || '[]');
    } catch (e) {}

    return {
      success: true,
      serverId: server.id,
      serverName: server.name,
      status,
      current: stats,
      history,
      network: {
        primaryPortSsh: server.port_ssh,
        additionalPorts,
        ipAddress: stats.network?.ip || '127.0.0.1',
        gateway: stats.network?.gateway || '172.17.0.1',
        macAddress: stats.network?.mac || 'N/A',
        rxSpeed: stats.network?.rx_speed_str || '0 B/s',
        txSpeed: stats.network?.tx_speed_str || '0 B/s',
        totalRx: stats.network?.rx_str || '0 B',
        totalTx: stats.network?.tx_str || '0 B',
        totalTransfer: stats.network?.total_str || '0 B'
      },
      uptime: {
        seconds: stats.uptime_seconds || 0,
        startedAt: stats.started_at
      }
    };
  }

  /**
   * Broadcast live stats over WebSockets to subscribed dashboard or server overview clients
   */
  static handleStatsWebSocket(ws, req) {
    const url = new URL(req.url, 'http://localhost');
    const serverId = url.searchParams.get('serverId');

    const timer = setInterval(async () => {
      if (ws.readyState !== ws.OPEN) {
        clearInterval(timer);
        return;
      }

      try {
        if (serverId) {
          const server = ServerModel.findById(parseInt(serverId, 10));
          if (server) {
            const analytics = await StatsService.getServerAnalytics(server);
            ws.send(JSON.stringify({
              type: 'server_stats',
              serverId: server.id,
              status: analytics.status,
              stats: analytics.current,
              analytics
            }));
          }
        } else {
          // Host stats for Admin dashboard
          const hostStats = await StatsService.getHostStats();
          ws.send(JSON.stringify({ type: 'host_stats', data: hostStats }));
        }
      } catch (err) {
        // silent catch
      }
    }, 2000);

    ws.on('close', () => {
      clearInterval(timer);
    });
  }
}

module.exports = StatsService;
