const { SettingsModel } = require('../db/models');

const CACHE_TTL_MS = 15 * 60 * 1000; // 15 mins
const cacheMap = new Map();

const CATEGORIES = [
  { slug: 'all', name: 'All / Latest 4K', count: '10,000+' },
  { slug: 'black-dark', name: 'Black & Dark (AMOLED)', count: '1,400+' },
  { slug: 'cute-kawaii-wallpapers', name: 'Cute & Kawaii', count: '850+' },
  { slug: 'ultrawide-monitor-hd-wallpapers', name: 'Ultrawide 21:9 / 32:9', count: '2,200+' },
  { slug: 'cool-wallpapers', name: 'Cool Wallpapers', count: '3,100+' },
  { slug: 'aesthetic-wallpapers', name: 'Aesthetic & Synthwave', count: '1,600+' },
  { slug: 'space', name: 'Space & Cosmos', count: '980+' },
  { slug: 'cr7-wallpapers', name: 'CR7 & Sports', count: '650+' },
  { slug: 'anime', name: 'Anime & Manga', count: '2,800+' },
  { slug: 'cars', name: 'Supercars & Vehicles', count: '2,400+' },
  { slug: 'games', name: 'Gaming 4K', count: '3,500+' },
  { slug: 'superheroes', name: 'Superheroes & Comics', count: '1,800+' },
  { slug: 'nature', name: 'Nature & Landscapes', count: '2,900+' },
  { slug: 'fantasy', name: 'Fantasy & Sci-Fi', count: '1,500+' },
  { slug: 'minimal', name: 'Minimalist & OLED', count: '1,200+' },
  { slug: 'abstract', name: 'Abstract & 3D CGI', count: '2,100+' },
  { slug: 'movies', name: 'Movies & TV Series', count: '1,900+' },
  { slug: 'technology', name: 'Technology & Cyber', count: '1,100+' },
  { slug: 'bikes', name: 'Bikes & Motorcycles', count: '750+' },
  { slug: 'animals', name: 'Animals & Wildlife', count: '920+' },
  { slug: 'architecture', name: 'Architecture & City', count: '1,300+' }
];

// Fallback curated wallpapers in case network request fails
const FALLBACK_CATALOG = {
  'black-dark': [
    { id: '27072', title: 'Hennessey Blackbird Stealth 5K', thumb: 'https://4kwallpapers.com/images/walls/thumbs/27072.jpg', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/27072.jpg' },
    { id: '26972', title: 'Lah Kara Ninth Jedi Dark 5K', thumb: 'https://4kwallpapers.com/images/walls/thumbs/26972.png', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/26972.png' },
    { id: '26911', title: 'Judge Dredd OLED AMOLED 8K', thumb: 'https://4kwallpapers.com/images/walls/thumbs/26911.png', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/26911.png' },
    { id: '26735', title: 'Microsoft Surface Dark Waves', thumb: 'https://4kwallpapers.com/images/walls/thumbs/26735.jpg', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/26735.jpg' },
    { id: '26628', title: 'Apple WWDC Dark Glow Aesthetic', thumb: 'https://4kwallpapers.com/images/walls/thumbs/26628.png', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/26628.png' },
    { id: '26500', title: 'Cyberpunk Obsidian Minimalist', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=400&auto=format&fit=crop' }
  ],
  'space': [
    { id: '22923', title: 'Futuristic Spaceship Deep Space', thumb: 'https://4kwallpapers.com/images/walls/thumbs/22923.jpg', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/22923.jpg' },
    { id: '26741', title: 'Europa Jupiter Moon NASA 5K', thumb: 'https://4kwallpapers.com/images/walls/thumbs/26741.jpg', url: 'https://4kwallpapers.com/images/walls/thumbs_3t/26741.jpg' },
    { id: 'space-1', title: 'Deep Space Nebula Galaxy', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=400&auto=format&fit=crop' },
    { id: 'space-2', title: 'Interstellar Cosmic Cluster', url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=400&auto=format&fit=crop' }
  ],
  'aesthetic-wallpapers': [
    { id: 'aes-1', title: 'Neon Sunset Cyberpunk Highway', url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=400&auto=format&fit=crop' },
    { id: 'aes-2', title: 'Synthwave Neon Drive', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=400&auto=format&fit=crop' },
    { id: 'aes-3', title: 'Purple Skyline Horizon', url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=400&auto=format&fit=crop' }
  ],
  'cute-kawaii-wallpapers': [
    { id: 'cute-1', title: 'Pastel Dream Clouds', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=400&auto=format&fit=crop' },
    { id: 'cute-2', title: 'Cute Pink Fantasy Land', url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=400&auto=format&fit=crop' }
  ],
  'cr7-wallpapers': [
    { id: 'cr7-1', title: 'Cristiano Ronaldo Stadium Glow', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=400&auto=format&fit=crop' },
    { id: 'cr7-2', title: 'Champions Arena Night', url: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?q=80&w=400&auto=format&fit=crop' }
  ]
};

class WallpaperService {
  static getCategories() {
    return CATEGORIES;
  }

  /**
   * Scrapes & fetches live 4K wallpapers from 4kwallpapers.com
   */
  static async fetchWallpapers({ category = 'all', page = 1, search = '' }) {
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const searchTrim = String(search || '').trim();
    const catSlug = String(category || 'all').trim().toLowerCase();

    const cacheKey = `${catSlug}:${searchTrim}:${pageNum}`;
    const cached = cacheMap.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
      return cached.data;
    }

    let targetUrl = 'https://4kwallpapers.com/';
    if (searchTrim) {
      targetUrl = `https://4kwallpapers.com/search/?q=${encodeURIComponent(searchTrim)}${pageNum > 1 ? `&page=${pageNum}` : ''}`;
    } else if (catSlug && catSlug !== 'all') {
      // Map aliases
      let mappedSlug = catSlug;
      if (catSlug === 'cute-kawaii-wallpapers') mappedSlug = 'cute';
      if (catSlug === 'cr7-wallpapers') mappedSlug = 'sports';
      if (catSlug === 'minimalist') mappedSlug = 'minimal';
      targetUrl = `https://4kwallpapers.com/${mappedSlug}/${pageNum > 1 ? `?page=${pageNum}` : ''}`;
    } else if (pageNum > 1) {
      targetUrl = `https://4kwallpapers.com/?page=${pageNum}`;
    }

    try {
      const response = await fetch(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5'
        },
        signal: AbortSignal.timeout(8000)
      });

      if (!response.ok) {
        throw new Error(`HTTP status ${response.status}`);
      }

      const html = await response.text();

      // Extract all thumbnail images
      const imgRegex = /<img[^>]*itemprop="thumbnail"[^>]*src="([^"]+)"[^>]*alt="([^"]*)"/gi;
      const wallpapers = [];
      let match;

      while ((match = imgRegex.exec(html)) !== null) {
        const thumbUrl = match[1];
        const altText = match[2];

        // Example thumbUrl: https://4kwallpapers.com/images/walls/thumbs/27072.jpg
        // or /images/walls/thumbs/27072.png
        const idMatch = thumbUrl.match(/\/(\d+)\.(jpg|png|webp)/i);
        const imgId = idMatch ? idMatch[1] : Math.random().toString(36).substring(7);
        const ext = idMatch ? idMatch[2] : 'jpg';

        const title = altText.split(',')[0] || '4K Ultra HD Wallpaper';
        const cleanTitle = title.trim();
        const tags = altText.split(',').map(s => s.trim()).filter(Boolean);

        const thumb = thumbUrl.startsWith('http') ? thumbUrl : `https://4kwallpapers.com${thumbUrl}`;
        const previewUrl = `https://4kwallpapers.com/images/walls/thumbs_2t/${imgId}.${ext}`;
        const full4kUrl = `https://4kwallpapers.com/images/walls/thumbs_3t/${imgId}.${ext}`;

        wallpapers.push({
          id: imgId,
          title: cleanTitle,
          fullTitle: altText,
          tags,
          thumb,
          previewUrl,
          url: full4kUrl,
          category: catSlug,
          source: '4kwallpapers.com'
        });
      }

      // Check if next page exists
      const hasNextPage = html.includes(`page=${pageNum + 1}`) || html.includes(`/${catSlug}/?page=${pageNum + 1}`) || wallpapers.length >= 20;

      const result = {
        success: true,
        source: '4kwallpapers.com',
        category: catSlug,
        search: searchTrim,
        page: pageNum,
        hasNextPage,
        hasPrevPage: pageNum > 1,
        totalOnPage: wallpapers.length,
        wallpapers: wallpapers.length > 0 ? wallpapers : (FALLBACK_CATALOG[catSlug] || FALLBACK_CATALOG['black-dark'])
      };

      cacheMap.set(cacheKey, { data: result, timestamp: Date.now() });
      return result;
    } catch (err) {
      console.warn(`[WallpaperService] Fallback for ${catSlug} (page ${pageNum}): ${err.message}`);
      const fallbackList = FALLBACK_CATALOG[catSlug] || FALLBACK_CATALOG['black-dark'] || [];
      return {
        success: true,
        source: 'fallback-cache',
        category: catSlug,
        search: searchTrim,
        page: pageNum,
        hasNextPage: false,
        hasPrevPage: pageNum > 1,
        totalOnPage: fallbackList.length,
        wallpapers: fallbackList.map(item => ({
          ...item,
          category: catSlug,
          previewUrl: item.thumb,
          source: '4kwallpapers.com'
        }))
      };
    }
  }

  /**
   * Get user/admin favorite wallpapers
   */
  static getFavorites() {
    try {
      const raw = SettingsModel.get('wallpaper_favorites', '[]');
      return JSON.parse(raw);
    } catch (e) {
      return [];
    }
  }

  /**
   * Toggle a wallpaper in favorites
   */
  static toggleFavorite(wallpaper) {
    let favs = WallpaperService.getFavorites();
    const existsIdx = favs.findIndex(f => f.url === wallpaper.url || (f.id && f.id === wallpaper.id));

    let isFavorited = false;
    if (existsIdx >= 0) {
      favs.splice(existsIdx, 1);
      isFavorited = false;
    } else {
      favs.unshift({
        id: wallpaper.id || String(Date.now()),
        title: wallpaper.title || '4K Wallpaper',
        thumb: wallpaper.thumb || wallpaper.url,
        previewUrl: wallpaper.previewUrl || wallpaper.url,
        url: wallpaper.url,
        category: wallpaper.category || 'general',
        savedAt: new Date().toISOString()
      });
      isFavorited = true;
    }

    SettingsModel.set('wallpaper_favorites', JSON.stringify(favs), 'branding');
    return { isFavorited, count: favs.length, favorites: favs };
  }
}

module.exports = WallpaperService;

