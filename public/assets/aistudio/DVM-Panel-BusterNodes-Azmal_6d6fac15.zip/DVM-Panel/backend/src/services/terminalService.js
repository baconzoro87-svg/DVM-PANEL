const { Client } = require('ssh2');
const { ServerModel, SubuserModel } = require('../db/models');
const { verifyToken } = require('../utils/security');

/**
 * Persistent SSH Session for a Virtual Machine
 * Stays alive in the background when the user closes the web tab or navigates away.
 */
class PersistentSshSession {
  constructor(serverId, server, sshUser, sshPass, sshPort) {
    this.serverId = serverId;
    this.server = server;
    this.sshUser = sshUser;
    this.sshPass = sshPass;
    this.sshPort = sshPort;

    this.conn = null;
    this.stream = null;
    this.ws = null; // Attached WebSocket client
    this.outputBuffer = []; // Ring buffer of recent output
    this.totalBufferSize = 0;
    this.maxBufferBytes = 512 * 1024; // 512 KB terminal scrollback buffer

    this.isConnected = false;
    this.isConnecting = false;
    this.isDead = false;
    this.cols = 120;
    this.rows = 32;
    this.retryTimeout = null;
    this.attempts = 0;
    this.maxAttempts = 30;

    this.connect();
  }

  connect() {
    if (this.isConnected || this.isConnecting || this.isDead) return;
    this.isConnecting = true;
    this.attempts++;

    try {
      if (this.conn) {
        try { this.conn.end(); } catch (e) {}
      }
      this.conn = new Client();
    } catch (err) {
      this.isConnecting = false;
      return;
    }

    this.conn.on('ready', () => {
      this.isConnected = true;
      this.isConnecting = false;
      this.attempts = 0;
      if (this.retryTimeout) clearTimeout(this.retryTimeout);

      const readyMsg = `\r\n\x1b[32m✔ Persistent SSH Session Active: [${this.server.name}] (Port ${this.sshPort})\x1b[0m\r\n\r\n`;
      this.broadcast(readyMsg);

      this.conn.shell({
        term: 'xterm-256color',
        cols: this.cols,
        rows: this.rows
      }, (err, stream) => {
        if (err) {
          const errMsg = `\r\n\x1b[31m[SSH Shell Error]: ${err.message}\x1b[0m\r\n`;
          this.broadcast(errMsg);
          this.destroy();
          return;
        }

        this.stream = stream;

        stream.on('data', (data) => {
          this.broadcast(data.toString('utf-8'));
        });

        stream.stderr.on('data', (data) => {
          this.broadcast(data.toString('utf-8'));
        });

        stream.on('close', () => {
          const closeMsg = '\r\n\x1b[33m[SSH terminal session closed by guest VM]\x1b[0m\r\n';
          this.broadcast(closeMsg);
          this.destroy();
        });
      });
    });

    this.conn.on('error', (err) => {
      this.isConnecting = false;
      this.isConnected = false;

      if (!this.isDead && this.attempts < this.maxAttempts) {
        const retryMsg = `\x1b[33m⏳ Waiting for VM SSH daemon on port ${this.sshPort} (Attempt ${this.attempts}/${this.maxAttempts})...\x1b[0m\r\n`;
        this.broadcast(retryMsg);
        this.retryTimeout = setTimeout(() => this.connect(), 2500);
      } else if (!this.isDead) {
        const failMsg = `\r\n\x1b[31m✖ SSH Connection Error: ${err.message}\x1b[0m\r\n\x1b[33m💡 Please make sure the VM is running and port ${this.sshPort} is active.\x1b[0m\r\n`;
        this.broadcast(failMsg);
        this.destroy();
      }
    });

    this.conn.connect({
      host: '127.0.0.1',
      port: this.sshPort,
      username: this.sshUser,
      password: this.sshPass,
      readyTimeout: 10000,
      keepaliveInterval: 5000,
      keepaliveCountMax: 5
    });
  }

  broadcast(chunk) {
    // 1. Add to persistent scrollback ring buffer
    this.outputBuffer.push(chunk);
    this.totalBufferSize += chunk.length;
    while (this.totalBufferSize > this.maxBufferBytes && this.outputBuffer.length > 1) {
      const shifted = this.outputBuffer.shift();
      this.totalBufferSize -= shifted.length;
    }

    // 2. Send to attached browser client if currently open
    if (this.ws && this.ws.readyState === this.ws.OPEN) {
      try {
        this.ws.send(chunk);
      } catch (e) {}
    }
  }

  attach(ws, initialCols, initialRows) {
    this.ws = ws;

    if (initialCols && initialRows) {
      this.resize(initialCols, initialRows);
    }

    // Replay entire scrollback buffer to the newly attached browser tab
    if (this.outputBuffer.length > 0) {
      for (const chunk of this.outputBuffer) {
        if (ws.readyState === ws.OPEN) {
          ws.send(chunk);
        }
      }
    } else {
      ws.send(`\r\n\x1b[36m⚡ Connected to background SSH session for [${this.server.name}]...\x1b[0m\r\n`);
    }
  }

  detach(ws) {
    if (this.ws === ws) {
      this.ws = null;
    }
    // We intentionally DO NOT close the SSH connection!
    // The VM shell and all running background jobs remain alive 24/7!
  }

  writeInput(data) {
    if (this.stream && this.stream.writable) {
      this.stream.write(data);
    }
  }

  resize(cols, rows) {
    this.cols = cols;
    this.rows = rows;
    if (this.stream && typeof this.stream.setWindow === 'function') {
      try {
        this.stream.setWindow(rows, cols, 0, 0);
      } catch (e) {}
    }
  }

  destroy() {
    this.isDead = true;
    this.isConnected = false;
    this.isConnecting = false;

    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
      this.retryTimeout = null;
    }
    if (this.stream) {
      try { this.stream.end(); } catch (e) {}
      this.stream = null;
    }
    if (this.conn) {
      try { this.conn.end(); } catch (e) {}
      this.conn = null;
    }
    if (this.ws && this.ws.readyState === this.ws.OPEN) {
      try { this.ws.close(); } catch (e) {}
      this.ws = null;
    }
    TerminalService.sessions.delete(this.serverId);
  }
}

class TerminalService {
  // Global map of active persistent sessions per VM: Map<serverId, PersistentSshSession>
  static sessions = new Map();

  /**
   * Initializes WebSocket SSH Terminal handler with persistent session reconnection
   */
  static handleConnection(ws, req) {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    const serverId = parseInt(url.searchParams.get('serverId'), 10);

    if (!token || !serverId) {
      ws.send('\r\n\x1b[31m[dpanel Error] Missing authentication token or server ID.\x1b[0m\r\n');
      return ws.close();
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      ws.send('\r\n\x1b[31m[dpanel Error] Authentication failed: invalid or expired token.\x1b[0m\r\n');
      return ws.close();
    }

    const server = ServerModel.findById(serverId);
    if (!server) {
      ws.send('\r\n\x1b[31m[dpanel Error] VM Server not found in database.\x1b[0m\r\n');
      return ws.close();
    }

    if (server.is_suspended || server.status === 'suspended') {
      ws.send('\r\n\x1b[31m[dpanel Notice] This Virtual Machine is currently SUSPENDED. Terminal & Console are disabled.\x1b[0m\r\n');
      return ws.close();
    }

    // Check user & subuser permissions
    if (decoded.role !== 'admin' && server.user_id !== decoded.id) {
      const subuser = SubuserModel.findByServerAndUser(serverId, decoded.id);
      if (!subuser) {
        ws.send('\r\n\x1b[31m[dpanel Error] Access denied: You do not have permission for this VM.\x1b[0m\r\n');
        return ws.close();
      }
      try {
        const perms = JSON.parse(subuser.permissions);
        if (!perms.includes('all') && !perms.includes('console')) {
          ws.send('\r\n\x1b[31m[dpanel Error] Console access permission required.\x1b[0m\r\n');
          return ws.close();
        }
      } catch (e) {
        ws.send('\r\n\x1b[31m[dpanel Error] Invalid permissions configuration.\x1b[0m\r\n');
        return ws.close();
      }
    }

    const sshUser = server.ssh_user || 'root';
    const sshPass = server.ssh_password || 'root';
    const sshPort = server.port_ssh || 25501;

    let session = TerminalService.sessions.get(serverId);

    // If session doesn't exist or is dead, create a new persistent session
    if (!session || session.isDead) {
      session = new PersistentSshSession(serverId, server, sshUser, sshPass, sshPort);
      TerminalService.sessions.set(serverId, session);
    }

    // Attach this WebSocket connection to the session
    session.attach(ws);

    // Handle incoming input & resize events from browser xterm
    ws.on('message', (msg) => {
      try {
        const str = msg.toString('utf-8');
        if (str.startsWith('{') && str.endsWith('}')) {
          try {
            const parsed = JSON.parse(str);

            if (parsed.type === 'resize' && parsed.cols && parsed.rows) {
              session.resize(parsed.cols, parsed.rows);
              return;
            }

            if (parsed.type === 'input' && parsed.data !== undefined) {
              session.writeInput(parsed.data);
              return;
            }

            if (parsed.type === 'kill_session' || parsed.type === 'restart_session') {
              // User explicitly requested to terminate the terminal session
              session.destroy();
              const newSession = new PersistentSshSession(serverId, server, sshUser, sshPass, sshPort);
              TerminalService.sessions.set(serverId, newSession);
              newSession.attach(ws);
              return;
            }
          } catch (e) {}
        }

        // Raw input stream fallback
        session.writeInput(str);
      } catch (err) {
        console.error('[TerminalService SSH] Input error:', err);
      }
    });

    // When the browser tab closes or user navigates away, DETACH without killing session!
    ws.on('close', () => {
      session.detach(ws);
    });
  }

  /**
   * Explicitly kill session (e.g. on server stop, restart, or delete)
   */
  static killSession(serverId) {
    const session = TerminalService.sessions.get(serverId);
    if (session) {
      session.destroy();
    }
  }
}

module.exports = TerminalService;
