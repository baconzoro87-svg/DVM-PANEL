const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const CONFIG = require('../config');

class DockerService {
  /**
   * Checks if Docker is running and available
   */
  static async ping() {
    try {
      const { stdout } = await execPromise('docker version --format "{{.Server.Version}}"');
      return { ok: true, version: stdout.trim() };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }

  /**
   * Pulls a Docker image if not already present
   */
  static async ensureImage(imageName) {
    try {
      // Check if image exists locally
      const { stdout } = await execPromise(`docker images -q "${imageName}"`);
      if (stdout.trim()) {
        return { success: true, message: 'Image is already local' };
      }
      console.log(`[DockerService] Pulling image: ${imageName}...`);
      await execPromise(`docker pull "${imageName}"`);
      console.log(`[DockerService] Successfully pulled image: ${imageName}`);
      return { success: true, message: 'Image pulled successfully' };
    } catch (err) {
      console.error(`[DockerService] Error pulling image ${imageName}:`, err.message);
      // If pull fails, let it try running anyway in case docker daemon resolves it
      return { success: false, error: err.message };
    }
  }

  /**
   * Creates and starts a container according to the requested command pattern:
   * docker run -d --privileged -p $port:22 -e VM_NAME=$VM_NAME -e HOSTNAME=$HOSTNAME ...
   */
  static async createVM({
    name,
    hostname,
    image,
    port_ssh,
    ram = '1G',
    cpus = '1',
    disk_size = '10G',
    env_vars = {},
    additional_ports = []
  }) {
    // 1. Ensure image is downloaded
    await this.ensureImage(image);

    // 2. Check if a container with this name already exists
    try {
      const { stdout } = await execPromise(`docker ps -a -q -f name=^/${name}$`);
      if (stdout.trim()) {
        // Remove old container if it exists
        await execPromise(`docker rm -f "${name}"`);
      }
    } catch (e) {}

    // 3. Calculate RAM values
    let ramLower = String(ram).trim().toLowerCase();
    let guestRamMb = 1024;
    if (ramLower.endsWith('g')) {
      guestRamMb = Math.round(parseFloat(ramLower) * 1024);
    } else if (ramLower.endsWith('m')) {
      guestRamMb = Math.round(parseFloat(ramLower));
    } else if (ramLower.endsWith('k')) {
      guestRamMb = Math.round(parseFloat(ramLower) / 1024);
    } else if (!isNaN(parseFloat(ramLower))) {
      guestRamMb = Math.round(parseFloat(ramLower) * 1024);
    }
    if (isNaN(guestRamMb) || guestRamMb <= 0) guestRamMb = 1024;

    // Container memory limit needs overhead buffer for QEMU hypervisor process, page tables, disk IO & buffers
    // For example: 1GB guest VM gets ~1.75GB container memory so OOM killer is never triggered
    const overheadMb = Math.max(768, Math.round(guestRamMb * 0.5));
    const containerMemoryLimit = `${guestRamMb + overheadMb}m`;
    const guestRamFormatted = `${guestRamMb}M`;

    // Format CPUs: e.g. "1", "2.5", "4"
    let cpusFormatted = String(cpus).trim();

    // Format DISK_SIZE: e.g. "10G", "1T" -> "1000G"
    let diskFormatted = String(disk_size).trim().toUpperCase();
    if (diskFormatted.endsWith('T')) {
      const tVal = parseFloat(diskFormatted);
      diskFormatted = `${Math.round(tVal * 1024)}G`;
    } else if (!diskFormatted.endsWith('G') && !diskFormatted.endsWith('M')) {
      if (/^\d+$/.test(diskFormatted)) {
        diskFormatted = `${diskFormatted}G`;
      }
    }

    const bootScriptPath = path.resolve(__dirname, '../scripts/boot-vm.sh');

    // 4. Build arguments array for docker run
    const args = [
      'run',
      '-d',
      '--privileged',
      '--name', name,
      '--hostname', hostname || name,
      '--restart', 'unless-stopped',
      '--memory', containerMemoryLimit,
      '--cpus', cpusFormatted,
      '-p', `${port_ssh}:22`
    ];

    if (fs.existsSync('/dev/kvm')) {
      args.push('--device', '/dev/kvm:/dev/kvm');
    }

    if (fs.existsSync(bootScriptPath)) {
      args.push('-v', `${bootScriptPath}:/boot-vm.sh:ro`);
    }

    // Additional port mappings
    if (Array.isArray(additional_ports)) {
      for (const p of additional_ports) {
        if (p.host && p.container) {
          args.push('-p', `${p.host}:${p.container}`);
        }
      }
    }

    // Default & custom environment variables
    args.push('-e', `VM_NAME=${name}`);
    args.push('-e', `HOSTNAME=${hostname || name}`);
    args.push('-e', `RAM=${guestRamFormatted}`);
    args.push('-e', `CPUS=${cpusFormatted}`);
    args.push('-e', `DISK_SIZE=${diskFormatted}`);

    if (env_vars && typeof env_vars === 'object') {
      for (const [key, val] of Object.entries(env_vars)) {
        if (key && val !== undefined && !['VM_NAME', 'HOSTNAME', 'RAM', 'CPUS', 'DISK_SIZE'].includes(key)) {
          args.push('-e', `${key}=${val}`);
        }
      }
    }

    // Target image (uses the image's built-in /boot-vm.sh or our mounted optimized /boot-vm.sh)
    args.push(image);

    console.log(`[DockerService] Executing: docker ${args.join(' ')}`);

    try {
      const { stdout } = await execPromise(`docker ${args.map(a => `"${a}"`).join(' ')}`);
      const containerId = stdout.trim();
      return {
        success: true,
        containerId: containerId.substring(0, 12),
        fullContainerId: containerId
      };
    } catch (err) {
      console.error(`[DockerService] Failed to create container:`, err.message);
      throw new Error(err.message);
    }
  }

  static async startVM(containerNameOrId) {
    const { stdout } = await execPromise(`docker start "${containerNameOrId}"`);
    return stdout.trim();
  }

  static async stopVM(containerNameOrId) {
    const { stdout } = await execPromise(`docker stop -t 10 "${containerNameOrId}"`);
    return stdout.trim();
  }

  static async restartVM(containerNameOrId) {
    const { stdout } = await execPromise(`docker restart -t 5 "${containerNameOrId}"`);
    return stdout.trim();
  }

  static async killVM(containerNameOrId) {
    const { stdout } = await execPromise(`docker kill "${containerNameOrId}"`);
    return stdout.trim();
  }

  static async removeVM(containerNameOrId) {
    try {
      await execPromise(`docker rm -f "${containerNameOrId}"`);
      return true;
    } catch (err) {
      console.warn(`[DockerService] Container remove warning: ${err.message}`);
      return false;
    }
  }

  static async getStatus(containerNameOrId) {
    try {
      const { stdout } = await execPromise(`docker inspect -f "{{.State.Status}}" "${containerNameOrId}"`);
      return stdout.trim(); // 'running', 'exited', 'paused', 'restarting', etc.
    } catch (err) {
      return 'stopped';
    }
  }

  static async inspectVM(containerNameOrId) {
    try {
      const { stdout } = await execPromise(`docker inspect "${containerNameOrId}"`);
      const parsed = JSON.parse(stdout);
      return parsed[0] || null;
    } catch (err) {
      return null;
    }
  }

  /**
   * Retrieves high-precision live resource & network usage analytics
   */
  static async getStats(containerNameOrId) {
    const parseByteString = (str) => {
      if (!str) return 0;
      const s = String(str).trim();
      const match = s.match(/^([\d.]+)\s*([a-zA-Z]+)?$/);
      if (!match) return 0;
      const num = parseFloat(match[1]);
      const unit = (match[2] || 'B').toUpperCase();
      if (unit === 'B') return num;
      if (unit === 'KB' || unit === 'KIB' || unit === 'K') return num * 1024;
      if (unit === 'MB' || unit === 'MIB' || unit === 'M') return num * 1024 * 1024;
      if (unit === 'GB' || unit === 'GIB' || unit === 'G') return num * 1024 * 1024 * 1024;
      if (unit === 'TB' || unit === 'TIB' || unit === 'T') return num * 1024 * 1024 * 1024 * 1024;
      return num;
    };

    const formatBytes = (bytes, decimals = 2) => {
      if (!bytes || bytes === 0 || isNaN(bytes)) return '0 B';
      const k = 1024;
      const dm = decimals < 0 ? 0 : decimals;
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      const safeIdx = Math.min(sizes.length - 1, Math.max(0, i));
      return parseFloat((bytes / Math.pow(k, safeIdx)).toFixed(dm)) + ' ' + sizes[safeIdx];
    };

    try {
      const format = '{"cpu":"{{.CPUPerc}}","mem_usage":"{{.MemUsage}}","mem_perc":"{{.MemPerc}}","net_io":"{{.NetIO}}","block_io":"{{.BlockIO}}","pids":"{{.PIDs}}"}';
      const { stdout } = await execPromise(`docker stats --no-stream --format '${format}' "${containerNameOrId}"`);
      const data = JSON.parse(stdout.trim());

      // CPU Percentage
      const cpuPercent = parseFloat(data.cpu.replace('%', '')) || 0;

      // Memory Parsing
      let usedMemStr = '0B';
      let limitMemStr = '0B';
      if (data.mem_usage && data.mem_usage.includes('/')) {
        const parts = data.mem_usage.split('/');
        usedMemStr = parts[0].trim();
        limitMemStr = parts[1].trim();
      }
      const memoryUsedBytes = parseByteString(usedMemStr);
      const memoryLimitBytes = parseByteString(limitMemStr);
      const memoryFreeBytes = Math.max(0, memoryLimitBytes - memoryUsedBytes);
      const memoryPercent = parseFloat(data.mem_perc.replace('%', '')) || 0;

      // Network IO Parsing
      let rxStr = '0B';
      let txStr = '0B';
      if (data.net_io && data.net_io.includes('/')) {
        const parts = data.net_io.split('/');
        rxStr = parts[0].trim();
        txStr = parts[1].trim();
      }
      const rxBytes = parseByteString(rxStr);
      const txBytes = parseByteString(txStr);

      // Network speed calculation (delta)
      if (!global._prevNetStats) global._prevNetStats = new Map();
      const prev = global._prevNetStats.get(containerNameOrId);
      const now = Date.now();
      let rxSpeedBytes = 0;
      let txSpeedBytes = 0;
      if (prev) {
        const dtSec = (now - prev.time) / 1000;
        if (dtSec > 0.4) {
          rxSpeedBytes = Math.max(0, Math.round((rxBytes - prev.rx) / dtSec));
          txSpeedBytes = Math.max(0, Math.round((txBytes - prev.tx) / dtSec));
        } else {
          rxSpeedBytes = prev.rxSpeed || 0;
          txSpeedBytes = prev.txSpeed || 0;
        }
      }
      global._prevNetStats.set(containerNameOrId, { rx: rxBytes, tx: txBytes, time: now, rxSpeed: rxSpeedBytes, txSpeed: txSpeedBytes });

      // Block IO (Disk IO) Parsing
      let readStr = '0B';
      let writeStr = '0B';
      if (data.block_io && data.block_io.includes('/')) {
        const parts = data.block_io.split('/');
        readStr = parts[0].trim();
        writeStr = parts[1].trim();
      }
      const blockReadBytes = parseByteString(readStr);
      const blockWriteBytes = parseByteString(writeStr);

      // Network inspection details
      let ipAddress = '127.0.0.1';
      let gateway = '172.17.0.1';
      let macAddress = 'N/A';
      let startedAt = null;
      let uptimeSeconds = 0;

      try {
        const { stdout: inspectOut } = await execPromise(`docker inspect --format '{{json .NetworkSettings}}|{{.State.StartedAt}}|{{.State.Status}}' "${containerNameOrId}"`);
        const [netSettingsJson, startAtStr, stateStatus] = inspectOut.trim().split('|');
        if (netSettingsJson) {
          const netSettings = JSON.parse(netSettingsJson);
          ipAddress = netSettings.IPAddress || (netSettings.Networks?.bridge?.IPAddress) || '127.0.0.1';
          gateway = netSettings.Gateway || (netSettings.Networks?.bridge?.Gateway) || '172.17.0.1';
          macAddress = netSettings.MacAddress || (netSettings.Networks?.bridge?.MacAddress) || 'N/A';
        }
        if (startAtStr && stateStatus === 'running') {
          startedAt = startAtStr;
          uptimeSeconds = Math.max(0, Math.round((now - new Date(startAtStr).getTime()) / 1000));
        }
      } catch (e) {}

      return {
        cpu_percent: cpuPercent,
        memory: {
          used_bytes: memoryUsedBytes,
          limit_bytes: memoryLimitBytes,
          free_bytes: memoryFreeBytes,
          used_str: formatBytes(memoryUsedBytes),
          limit_str: formatBytes(memoryLimitBytes),
          free_str: formatBytes(memoryFreeBytes),
          percent: memoryPercent
        },
        memory_usage_str: data.mem_usage,
        memory_percent: memoryPercent,
        network: {
          rx_bytes: rxBytes,
          tx_bytes: txBytes,
          rx_str: formatBytes(rxBytes),
          tx_str: formatBytes(txBytes),
          rx_speed_str: `${formatBytes(rxSpeedBytes)}/s`,
          tx_speed_str: `${formatBytes(txSpeedBytes)}/s`,
          rx_speed_bytes: rxSpeedBytes,
          tx_speed_bytes: txSpeedBytes,
          total_str: formatBytes(rxBytes + txBytes),
          ip: ipAddress,
          gateway: gateway,
          mac: macAddress
        },
        network_io: data.net_io,
        disk_io: {
          read_bytes: blockReadBytes,
          write_bytes: blockWriteBytes,
          read_str: formatBytes(blockReadBytes),
          write_str: formatBytes(blockWriteBytes),
          total_str: formatBytes(blockReadBytes + blockWriteBytes)
        },
        block_io: data.block_io,
        pids: parseInt(data.pids, 10) || 0,
        uptime_seconds: uptimeSeconds,
        started_at: startedAt,
        raw: data
      };
    } catch (err) {
      return {
        cpu_percent: 0,
        memory: { used_bytes: 0, limit_bytes: 0, free_bytes: 0, used_str: '0 B', limit_str: '0 B', free_str: '0 B', percent: 0 },
        memory_usage_str: '0B / 0B',
        memory_percent: 0,
        network: { rx_bytes: 0, tx_bytes: 0, rx_str: '0 B', tx_str: '0 B', rx_speed_str: '0 B/s', tx_speed_str: '0 B/s', rx_speed_bytes: 0, tx_speed_bytes: 0, total_str: '0 B', ip: '127.0.0.1', gateway: '172.17.0.1', mac: 'N/A' },
        network_io: '0B / 0B',
        disk_io: { read_bytes: 0, write_bytes: 0, read_str: '0 B', write_str: '0 B', total_str: '0 B' },
        block_io: '0B / 0B',
        pids: 0,
        uptime_seconds: 0,
        started_at: null
      };
    }
  }

  /**
   * Run a one-off command inside the container and get output
   */
  static async execCommand(containerNameOrId, command) {
    try {
      const { stdout, stderr } = await execPromise(`docker exec "${containerNameOrId}" sh -c "${command.replace(/"/g, '\\"')}"`);
      return { stdout, stderr, exitCode: 0 };
    } catch (err) {
      return { stdout: err.stdout || '', stderr: err.stderr || err.message, exitCode: err.code || 1 };
    }
  }

  /**
   * List all images available locally
   */
  static async listImages() {
    try {
      const { stdout } = await execPromise('docker images --format "{{.Repository}}:{{.Tag}}|{{.Size}}|{{.ID}}"');
      const lines = stdout.trim().split('\n').filter(Boolean);
      return lines.map(line => {
        const [tag, size, id] = line.split('|');
        return { tag, size, id };
      });
    } catch (err) {
      return [];
    }
  }

  /**
   * Prune dangling images and stopped containers
   */
  static async systemPrune() {
    try {
      const { stdout } = await execPromise('docker system prune -f');
      return { success: true, output: stdout };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = DockerService;

