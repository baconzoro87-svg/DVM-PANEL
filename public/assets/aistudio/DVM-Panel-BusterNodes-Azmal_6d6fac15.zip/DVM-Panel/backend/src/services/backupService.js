const { exec, spawn } = require('child_process');
const util = require('util');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const execPromise = util.promisify(exec);
const CONFIG = require('../config');
const { BackupModel, ActivityLogModel } = require('../db/models');

class BackupService {
  /**
   * Create a full container snapshot backup (.tar.gz)
   */
  static async createBackup(server, name = 'Auto Backup', userId = null) {
    const backupUuid = uuidv4();
    const safeName = (name || 'backup').replace(/[^a-zA-Z0-9_-]/g, '_');
    const filename = `${server.name}_${safeName}_${Date.now()}.tar.gz`;
    const backupPath = path.join(CONFIG.BACKUP_DIR, filename);

    const record = BackupModel.create({
      uuid: backupUuid,
      server_id: server.id,
      name: name || `Backup ${new Date().toLocaleDateString()}`,
      filename,
      size_bytes: 0,
      status: 'creating'
    });

    try {
      console.log(`[BackupService] Starting backup for server ${server.name} to ${backupPath}...`);
      
      // Export container to tar.gz
      await execPromise(`docker export "${server.name}" | gzip > "${backupPath}"`);

      const stats = fs.statSync(backupPath);
      db = require('../db');
      db.prepare('UPDATE backups SET size_bytes = ?, status = ? WHERE id = ?').run(stats.size, 'completed', record.id);

      ActivityLogModel.create({
        user_id: userId,
        server_id: server.id,
        action: 'BACKUP_CREATE',
        details: `Created backup "${name}" (${(stats.size / (1024 * 1024)).toFixed(2)} MB)`
      });

      return BackupModel.findById(record.id);
    } catch (err) {
      console.error('[BackupService] Backup creation failed:', err);
      const db = require('../db');
      db.prepare('UPDATE backups SET status = ? WHERE id = ?').run('failed', record.id);
      throw new Error(`Backup failed: ${err.message}`);
    }
  }

  /**
   * Restore a backup into a new or existing container
   */
  static async restoreBackup(backupId, server, userId = null) {
    const backup = BackupModel.findById(backupId);
    if (!backup) throw new Error('Backup not found');

    const backupPath = path.join(CONFIG.BACKUP_DIR, backup.filename);
    if (!fs.existsSync(backupPath)) {
      throw new Error('Backup archive file not found on disk.');
    }

    try {
      console.log(`[BackupService] Restoring backup ${backup.name} to ${server.name}...`);
      
      // Temporary image name from backup
      const tempImage = `dpanel-restore-${server.name.toLowerCase()}:latest`;
      await execPromise(`docker import "${backupPath}" "${tempImage}"`);

      // Recreate or start VM with this restored image
      const DockerService = require('./dockerService');
      await DockerService.removeVM(server.name);

      await DockerService.createVM({
        name: server.name,
        hostname: server.hostname,
        image: tempImage,
        port_ssh: server.port_ssh,
        ram: server.memory_limit,
        cpus: server.cpu_limit,
        disk_size: server.disk_limit
      });

      ActivityLogModel.create({
        user_id: userId,
        server_id: server.id,
        action: 'BACKUP_RESTORE',
        details: `Restored server from backup "${backup.name}"`
      });

      return { success: true, message: 'Server restored successfully' };
    } catch (err) {
      console.error('[BackupService] Backup restoration failed:', err);
      throw new Error(`Restore failed: ${err.message}`);
    }
  }

  /**
   * Delete backup
   */
  static async deleteBackup(backupId, userId = null) {
    const backup = BackupModel.findById(backupId);
    if (!backup) throw new Error('Backup not found');

    const backupPath = path.join(CONFIG.BACKUP_DIR, backup.filename);
    if (fs.existsSync(backupPath)) {
      try {
        fs.unlinkSync(backupPath);
      } catch (e) {}
    }

    BackupModel.delete(backupId);

    ActivityLogModel.create({
      user_id: userId,
      server_id: backup.server_id,
      action: 'BACKUP_DELETE',
      details: `Deleted backup "${backup.name}"`
    });

    return { success: true };
  }
}

module.exports = BackupService;

