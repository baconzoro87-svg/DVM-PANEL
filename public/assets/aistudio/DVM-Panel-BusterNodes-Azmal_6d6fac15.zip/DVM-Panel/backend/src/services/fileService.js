const { Client } = require('ssh2');
const path = require('path');
const fs = require('fs');

/**
 * Format numeric file mode to standard POSIX string (e.g. -rw-r--r--, drwxr-xr-x)
 */
function formatPermissions(mode, isDir) {
  let str = isDir ? 'd' : '-';
  str += (mode & 0o400) ? 'r' : '-';
  str += (mode & 0o200) ? 'w' : '-';
  str += (mode & 0o100) ? 'x' : '-';
  str += (mode & 0o040) ? 'r' : '-';
  str += (mode & 0o020) ? 'w' : '-';
  str += (mode & 0o010) ? 'x' : '-';
  str += (mode & 0o004) ? 'r' : '-';
  str += (mode & 0o002) ? 'w' : '-';
  str += (mode & 0o001) ? 'x' : '-';
  return str;
}

class FileService {
  /**
   * Sanitizes and normalizes container/VM path
   */
  static cleanPath(p) {
    if (!p) return '/root';
    let normalized = path.posix.normalize(p);
    if (!normalized.startsWith('/')) {
      normalized = '/' + normalized;
    }
    return normalized;
  }

  /**
   * Connect to the VM via SSH and open an SFTP session
   */
  static async getSftp(server) {
    return new Promise((resolve, reject) => {
      const conn = new Client();
      const sshPort = server.port_ssh || 25501;
      const sshUser = server.ssh_user || 'root';
      const sshPass = server.ssh_password || 'root';

      conn.on('ready', () => {
        conn.sftp((err, sftp) => {
          if (err) {
            conn.end();
            return reject(new Error('Failed to start SFTP subsystem: ' + err.message));
          }
          resolve({ conn, sftp });
        });
      });

      conn.on('error', (err) => {
        reject(new Error(`SFTP SSH connection failed on port ${sshPort} (${sshUser}): ${err.message}`));
      });

      conn.connect({
        host: '127.0.0.1',
        port: sshPort,
        username: sshUser,
        password: sshPass,
        readyTimeout: 8000,
        keepaliveInterval: 5000
      });
    });
  }

  /**
   * List files in a directory inside the VM via SFTP
   */
  static async listFiles(server, dirPath = '/root') {
    const target = this.cleanPath(dirPath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      const list = await new Promise((resolve, reject) => {
        sftp.readdir(target, (err, items) => {
          if (err) return reject(err);
          resolve(items || []);
        });
      });

      const items = list.map(item => {
        const isDir = item.attrs.isDirectory();
        const isSymlink = item.attrs.isSymbolicLink();
        const size = item.attrs.size || 0;
        const mtime = item.attrs.mtime ? new Date(item.attrs.mtime * 1000).toISOString() : new Date().toISOString();
        const permissions = formatPermissions(item.attrs.mode, isDir);
        const itemPath = path.posix.join(target, item.filename);

        return {
          name: item.filename,
          path: itemPath,
          isDirectory: isDir,
          isSymlink: isSymlink,
          size: size,
          modifiedAt: mtime,
          permissions: permissions,
          owner: `${item.attrs.uid || 0}:${item.attrs.gid || 0}`
        };
      });

      // Sort: folders first, then alphabetical
      items.sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name);
      });

      return {
        currentPath: target,
        items
      };
    } finally {
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Read file content via SFTP
   */
  static async readFile(server, filePath) {
    const target = this.cleanPath(filePath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      const stats = await new Promise((resolve, reject) => {
        sftp.stat(target, (err, st) => {
          if (err) return reject(err);
          resolve(st);
        });
      });

      if (stats.size > 5 * 1024 * 1024) {
        throw new Error('File is too large to view in the web editor (Max: 5MB). Please download it instead.');
      }

      const buffer = await new Promise((resolve, reject) => {
        sftp.readFile(target, (err, data) => {
          if (err) return reject(err);
          resolve(data);
        });
      });

      // Check if binary
      let isBinary = false;
      const checkLength = Math.min(buffer.length, 512);
      for (let i = 0; i < checkLength; i++) {
        if (buffer[i] === 0) {
          isBinary = true;
          break;
        }
      }

      return {
        path: target,
        name: path.posix.basename(target),
        size: stats.size,
        modifiedAt: stats.mtime ? new Date(stats.mtime * 1000).toISOString() : new Date().toISOString(),
        content: isBinary ? null : buffer.toString('utf-8'),
        isBinary
      };
    } finally {
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Write / save file content via SFTP
   */
  static async writeFile(server, filePath, content) {
    const target = this.cleanPath(filePath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      await new Promise((resolve, reject) => {
        sftp.writeFile(target, content, 'utf8', (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
      return true;
    } finally {
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Create directory via SSH / SFTP
   */
  static async createDirectory(server, dirPath) {
    const target = this.cleanPath(dirPath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      await new Promise((resolve, reject) => {
        conn.exec(`mkdir -p "${target}"`, (err, stream) => {
          if (err) return reject(err);
          let resolved = false;
          const finish = (code) => {
            if (resolved) return;
            resolved = true;
            if (code === 0 || code === null || code === undefined) resolve();
            else reject(new Error(`mkdir failed with exit code ${code}`));
          };
          stream.on('exit', finish);
          stream.on('close', finish);
        });
      });
      return true;
    } finally {
      try { sftp.end(); } catch (e) {}
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Create new empty file
   */
  static async createFile(server, filePath, initialContent = '') {
    return this.writeFile(server, filePath, initialContent);
  }

  /**
   * Delete file or directory inside the VM
   */
  static async deletePath(server, targetPath) {
    const target = this.cleanPath(targetPath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      await new Promise((resolve, reject) => {
        conn.exec(`rm -rf "${target}"`, (err, stream) => {
          if (err) return reject(err);
          let resolved = false;
          const finish = (code) => {
            if (resolved) return;
            resolved = true;
            if (code === 0 || code === null || code === undefined) resolve();
            else reject(new Error(`rm -rf failed with exit code ${code}`));
          };
          stream.on('exit', finish);
          stream.on('close', finish);
        });
      });
      return true;
    } finally {
      try { sftp.end(); } catch (e) {}
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Rename / move file or directory inside the VM
   */
  static async renamePath(server, oldPath, newPath) {
    const src = this.cleanPath(oldPath);
    const dst = this.cleanPath(newPath);
    let { conn, sftp } = await this.getSftp(server);

    try {
      await new Promise((resolve, reject) => {
        sftp.rename(src, dst, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
      return true;
    } finally {
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Upload a local temporary file into the VM filesystem via SFTP
   */
  static async uploadFile(server, localTempPath, targetDir, originalName) {
    const dir = this.cleanPath(targetDir);
    const destination = path.posix.join(dir, originalName);
    let { conn, sftp } = await this.getSftp(server);

    try {
      await new Promise((resolve, reject) => {
        sftp.fastPut(localTempPath, destination, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });

      // Cleanup local temp file
      try { fs.unlinkSync(localTempPath); } catch (e) {}
      return true;
    } finally {
      try { conn.end(); } catch (e) {}
    }
  }

  /**
   * Stream download a file from the VM to HTTP response
   */
  static async streamDownload(server, filePath, res) {
    const target = this.cleanPath(filePath);
    const filename = path.posix.basename(target);
    let { conn, sftp } = await this.getSftp(server);

    try {
      const stats = await new Promise((resolve, reject) => {
        sftp.stat(target, (err, st) => {
          if (err) return reject(err);
          resolve(st);
        });
      });

      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Length', stats.size);

      const readStream = sftp.createReadStream(target);
      readStream.pipe(res);

      readStream.on('end', () => {
        try { conn.end(); } catch (e) {}
      });

      readStream.on('error', (err) => {
        try { conn.end(); } catch (e) {}
        if (!res.headersSent) {
          res.status(500).json({ success: false, message: err.message });
        }
      });
    } catch (err) {
      try { conn.end(); } catch (e) {}
      throw err;
    }
  }
}

module.exports = FileService;
