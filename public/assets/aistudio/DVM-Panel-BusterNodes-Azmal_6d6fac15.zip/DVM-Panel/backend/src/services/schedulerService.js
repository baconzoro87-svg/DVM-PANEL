const cron = require('node-cron');
const { ScheduleModel, ServerModel, ActivityLogModel, SettingsModel, UserModel } = require('../db/models');
const DockerService = require('./dockerService');
const BackupService = require('./backupService');

class SchedulerService {
  static runningJobs = new Map();
  static workerInterval = null;

  static init() {
    console.log('[SchedulerService] Initializing server cron schedules & auto-suspend worker...');
    this.refreshAll();
    this.startAutoSuspendWorker();
  }

  /**
   * High-frequency (every 5 seconds) Auto-Suspend Worker
   */
  static startAutoSuspendWorker() {
    if (this.workerInterval) {
      clearInterval(this.workerInterval);
    }

    const checkAndSuspendVMs = async () => {
      try {
        const globalAutoSuspendEnabled = SettingsModel.get('auto_suspend_enabled') === 'true';
        const globalAutoSuspendHours = parseFloat(SettingsModel.get('auto_suspend_hours') || '24');

        const allServers = ServerModel.getAll();
        const nowMs = Date.now();
        const now = new Date();
        const currentHH = String(now.getHours()).padStart(2, '0');
        const currentMM = String(now.getMinutes()).padStart(2, '0');
        const currentTimeStr = `${currentHH}:${currentMM}`;

        for (const s of allServers) {
          // Check 1: If server owner user is suspended, automatically suspend VM immediately
          const owner = UserModel.findById(s.user_id);
          if (owner && owner.status === 'suspended' && (!s.is_suspended || s.status !== 'suspended')) {
            console.log(`[Auto-Suspend Worker] Suspending VM "${s.name}" (ID: ${s.id}) because owner "${owner.username}" is suspended`);
            try { await DockerService.stopVM(s.name); } catch(e) {}
            ServerModel.update(s.id, {
              status: 'suspended',
              is_suspended: 1,
              suspend_reason: 'Owner user account is suspended'
            });
            ActivityLogModel.create({
              server_id: s.id,
              user_id: s.user_id,
              action: 'AUTO_SUSPEND_VM',
              details: `Auto-suspended VM "${s.name}" because owner account "${owner.username}" is suspended`
            });
            continue;
          }

          // Check 2: If server is marked as suspended, ensure container is NEVER turned on or running
          if (s.is_suspended || s.status === 'suspended') {
            let dockerStatus = 'stopped';
            try { dockerStatus = await DockerService.getStatus(s.name); } catch(e) {}
            if (dockerStatus === 'running' || dockerStatus === 'restarting') {
              console.log(`[Auto-Suspend Worker] 🛑 Enforcing suspension: Container "${s.name}" was running while suspended. Stopping container...`);
              try { await DockerService.stopVM(s.name); } catch(e) {}
              ServerModel.update(s.id, { status: 'suspended', is_suspended: 1 });
            }
            continue;
          }

          // Check 3: If server is not currently marked as suspended
          if (!s.is_suspended) {
            let dockerStatus = 'stopped';
            try {
              dockerStatus = await DockerService.getStatus(s.name);
            } catch (e) {
              dockerStatus = s.status || 'stopped';
            }

            const isRunning = dockerStatus === 'running' || s.status === 'running';
            if (!isRunning) {
              continue;
            }

            const suspendType = s.auto_suspend_type || 'hours';

            // Mode A: Exact Calendar Date & Time
            if (suspendType === 'datetime' && s.auto_suspend_at) {
              let targetMs = NaN;
              if (s.auto_suspend_at.includes('Z') || s.auto_suspend_at.includes('+')) {
                targetMs = new Date(s.auto_suspend_at).getTime();
              } else {
                targetMs = new Date(s.auto_suspend_at).getTime();
                if (isNaN(targetMs)) {
                  targetMs = new Date(s.auto_suspend_at.replace(' ', 'T') + 'Z').getTime();
                }
              }

              if (!isNaN(targetMs) && nowMs >= targetMs) {
                console.log(`[Auto-Suspend Worker] 📅 Target calendar reached for VM "${s.name}" (${s.auto_suspend_at}). Suspending now...`);
                try { await DockerService.stopVM(s.name); } catch(e) {}
                ServerModel.update(s.id, {
                  status: 'suspended',
                  is_suspended: 1,
                  suspend_reason: `Auto-suspended on scheduled calendar date & time (${s.auto_suspend_at})`
                });
                ActivityLogModel.create({
                  server_id: s.id,
                  user_id: s.user_id,
                  action: 'AUTO_SUSPEND_VM',
                  details: `VM "${s.name}" auto-suspended on scheduled calendar date: ${s.auto_suspend_at}`
                });
                continue;
              }
            }

            // Mode B: Daily Recurring Schedule (e.g. 23:00 / 11 PM or 05:49 AM)
            if (suspendType === 'daily_time') {
              let shouldSuspend = false;
              let targetMs = NaN;

              if (s.auto_suspend_at) {
                targetMs = new Date(s.auto_suspend_at).getTime();
                if (!isNaN(targetMs) && nowMs >= targetMs) {
                  shouldSuspend = true;
                }
              }

              if (!shouldSuspend && s.auto_suspend_time) {
                if (currentTimeStr === s.auto_suspend_time) {
                  shouldSuspend = true;
                }
              }

              if (shouldSuspend) {
                console.log(`[Auto-Suspend Worker] ⏰ Daily sleep schedule reached for VM "${s.name}" (${s.auto_suspend_time || 'Daily'}). Suspending now...`);
                try { await DockerService.stopVM(s.name); } catch(e) {}

                // Advance next target date by 24 hours for seamless daily repeat
                const nextDate = new Date(nowMs + 24 * 60 * 60 * 1000);
                ServerModel.update(s.id, {
                  status: 'suspended',
                  is_suspended: 1,
                  suspend_reason: `Auto-suspended by daily sleep schedule (${s.auto_suspend_time || 'Daily'})`,
                  auto_suspend_at: nextDate.toISOString()
                });

                ActivityLogModel.create({
                  server_id: s.id,
                  user_id: s.user_id,
                  action: 'AUTO_SUSPEND_VM',
                  details: `VM "${s.name}" auto-suspended by daily recurring schedule at ${s.auto_suspend_time}`
                });
                continue;
              }
            }

            // Mode C: Continuous Runtime Timer Hours / Minutes
            if (suspendType === 'hours') {
              const vmHours = parseFloat(s.auto_suspend_hours) || 0;
              const effectiveHours = vmHours > 0 ? vmHours : (globalAutoSuspendEnabled ? globalAutoSuspendHours : 0);

              if (effectiveHours > 0) {
                const rawUpdated = s.updated_at || s.created_at;
                let updatedMs = Date.now();
                if (rawUpdated) {
                  const d = new Date(rawUpdated.replace(' ', 'T') + (rawUpdated.includes('Z') ? '' : 'Z'));
                  if (!isNaN(d.getTime())) updatedMs = d.getTime();
                }

                const hoursRunning = (nowMs - updatedMs) / (1000 * 60 * 60);

                if (hoursRunning >= effectiveHours) {
                  console.log(`[Auto-Suspend Worker] ⏳ Runtime limit reached for VM "${s.name}" (${hoursRunning.toFixed(2)}h >= ${effectiveHours}h). Suspending now...`);
                  try { await DockerService.stopVM(s.name); } catch(e) {}
                  ServerModel.update(s.id, {
                    status: 'suspended',
                    is_suspended: 1,
                    suspend_reason: `Auto-suspended after reaching ${effectiveHours}h continuous runtime threshold`
                  });
                  ActivityLogModel.create({
                    server_id: s.id,
                    user_id: s.user_id,
                    action: 'AUTO_SUSPEND_VM',
                    details: `VM "${s.name}" auto-suspended after ${effectiveHours} hours continuous runtime limit`
                  });
                }
              }
            }
          }
        }
      } catch (err) {
        console.error('[SchedulerService] Auto-suspend worker error:', err.message);
      }
    };

    // Run immediately on boot
    checkAndSuspendVMs();

    // Run every 5 seconds for instant real-time response
    this.workerInterval = setInterval(checkAndSuspendVMs, 5000);
  }

  static refreshAll() {
    // Clear existing active cron jobs
    for (const [id, job] of this.runningJobs.entries()) {
      job.stop();
      this.runningJobs.delete(id);
    }

    try {
      const schedules = ScheduleModel.getAllActive();
      for (const sched of schedules) {
        this.registerJob(sched);
      }
      console.log(`[SchedulerService] Loaded ${schedules.length} active schedule(s).`);
    } catch (err) {
      console.error('[SchedulerService] Failed to load schedules:', err.message);
    }
  }

  static registerJob(sched) {
    if (!cron.validate(sched.cron_expression)) {
      console.warn(`[SchedulerService] Invalid cron expression: "${sched.cron_expression}" for schedule ${sched.name}`);
      return;
    }

    const job = cron.schedule(sched.cron_expression, async () => {
      console.log(`[SchedulerService] Executing schedule "${sched.name}" (${sched.action}) for server ${sched.server_id}`);
      try {
        const server = ServerModel.findById(sched.server_id);
        if (!server) {
          console.warn(`[SchedulerService] Server ${sched.server_id} not found for schedule "${sched.name}"`);
          return;
        }

        if (server.is_suspended && ['start', 'restart'].includes(sched.action)) {
          console.log(`[SchedulerService] Skipping "${sched.name}" because server is suspended`);
          return;
        }

        switch (sched.action) {
          case 'start':
            await DockerService.startVM(server.name);
            ServerModel.update(server.id, { status: 'running' });
            break;
          case 'stop':
            await DockerService.stopVM(server.name);
            ServerModel.update(server.id, { status: 'stopped' });
            break;
          case 'restart':
            await DockerService.restartVM(server.name);
            ServerModel.update(server.id, { status: 'running' });
            break;
          case 'backup':
            await BackupService.createBackup(server.id, `Schedule: ${sched.name}`);
            break;
          default:
            console.warn(`[SchedulerService] Unknown action "${sched.action}"`);
        }

        ScheduleModel.update(sched.id, { last_run_at: new Date().toISOString() });
        ActivityLogModel.create({
          server_id: server.id,
          user_id: sched.user_id || server.user_id,
          action: `SCHEDULE_${sched.action.toUpperCase()}`,
          details: `Scheduled task "${sched.name}" executed successfully.`
        });
      } catch (err) {
        console.error(`[SchedulerService] Error executing schedule "${sched.name}":`, err.message);
      }
    });

    this.runningJobs.set(sched.id, job);
  }

  static addJob(sched) {
    if (sched.is_active) {
      this.registerJob(sched);
    }
  }

  static removeJob(schedId) {
    const job = this.runningJobs.get(schedId);
    if (job) {
      job.stop();
      this.runningJobs.delete(schedId);
    }
  }
}

module.exports = SchedulerService;
