const http = require('http');
const express = require('express');
const cors = require('cors');
const { WebSocketServer } = require('ws');
const path = require('path');
const fs = require('fs');

const CONFIG = require('./config');
const authRoutes = require('./routes/auth');
const usersRoutes = require('./routes/users');
const serversRoutes = require('./routes/servers');
const adminRoutes = require('./routes/admin');
const settingsRoutes = require('./routes/settings');
const ticketsRoutes = require('./routes/tickets');
const portsRoutes = require('./routes/ports');

const TerminalService = require('./services/terminalService');
const LogService = require('./services/logService');
const StatsService = require('./services/statsService');
const SchedulerService = require('./services/schedulerService');
const DockerService = require('./services/dockerService');

const app = express();

// Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static media
app.use('/uploads', express.static(CONFIG.UPLOAD_DIR));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/servers', serversRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/tickets', ticketsRoutes);
app.use('/api/ports', portsRoutes);

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const docker = await DockerService.ping();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    name: 'dpanel API Server',
    port: CONFIG.PORT,
    webPort: CONFIG.WEB_PORT,
    docker: docker.ok ? `Docker ${docker.version}` : 'Unavailable'
  });
});

// Create HTTP server
const server = http.createServer(app);

// WebSocket Server
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const { pathname } = new URL(request.url, `http://${request.headers.host}`);

  if (pathname.startsWith('/ws/terminal')) {
    wss.handleUpgrade(request, socket, head, (ws) => {
      TerminalService.handleConnection(ws, request);
    });
  } else if (pathname.startsWith('/ws/logs')) {
    wss.handleUpgrade(request, socket, head, (ws) => {
      LogService.handleConnection(ws, request);
    });
  } else if (pathname.startsWith('/ws/stats')) {
    wss.handleUpgrade(request, socket, head, (ws) => {
      StatsService.handleStatsWebSocket(ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Start scheduler
SchedulerService.init();

// Start API Server
server.listen(CONFIG.PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log(`🚀 DVM Panel API & WebSocket Server running on port ${CONFIG.PORT}`);
  console.log(`🌐 Expected Web Interface on port ${CONFIG.WEB_PORT}`);
  console.log(`📦 Data directory: ${CONFIG.DATA_DIR}`);
  console.log('====================================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  server.close(() => process.exit(0));
});
process.on('SIGINT', () => {
  console.log('SIGINT received, closing server...');
  server.close(() => process.exit(0));
});

module.exports = { app, server };

