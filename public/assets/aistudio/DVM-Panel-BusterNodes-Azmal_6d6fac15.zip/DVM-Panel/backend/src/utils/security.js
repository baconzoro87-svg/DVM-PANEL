const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { authenticator } = require('otplib');
const qrcode = require('qrcode');
const crypto = require('crypto');
const config = require('../config');

const JWT_SECRET = config.JWT_SECRET || 'dpanel_super_secret_jwt_key_2026_x89f_secure';
const JWT_EXPIRES_IN = config.JWT_EXPIRES_IN || '7d';

// Password hashing
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

// Password verification
async function comparePassword(password, hash) {
  if (!password || !hash) return false;
  return bcrypt.compare(password, hash);
}

// JWT Token Generation
function generateToken(user) {
  const payload = {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role
  };
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN
  });
}

// JWT Token Verification
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

// 2FA TOTP Secret Generation
function generate2FASecret(username = 'User') {
  const secret = authenticator.generateSecret();
  const serviceName = 'dpanel';
  const otpauthUrl = authenticator.keyuri(username, serviceName, secret);
  return { secret, otpauthUrl };
}

// 2FA QR Code Data URL Generation
async function generate2FAQRCode(otpauthUrl) {
  return qrcode.toDataURL(otpauthUrl, {
    margin: 2,
    color: {
      dark: '#000000',
      light: '#ffffff'
    }
  });
}

// 2FA Token Verification
function verify2FAToken(secret, token) {
  try {
    return authenticator.verify({ token: String(token).trim(), secret });
  } catch {
    return false;
  }
}

// API Key Generator
function generateApiKey() {
  const rawKey = `dp_${crypto.randomBytes(24).toString('hex')}`;
  const prefix = rawKey.substring(0, 7);
  const hash = crypto.createHash('sha256').update(rawKey).digest('hex');
  return { rawKey, prefix, hash };
}

module.exports = {
  hashPassword,
  comparePassword,
  generateToken,
  verifyToken,
  generate2FASecret,
  generate2FAQRCode,
  verify2FAToken,
  generateApiKey
};
