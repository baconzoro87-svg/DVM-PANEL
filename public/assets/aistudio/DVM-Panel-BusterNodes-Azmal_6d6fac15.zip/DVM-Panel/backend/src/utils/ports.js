const net = require('net');
const CONFIG = require('../config');
const { ServerModel } = require('../db/models');

/**
 * Checks if a specific port is currently open and bound on host
 */
function isPortInUseOnHost(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        resolve(true);
      } else {
        resolve(false);
      }
    });
    server.once('listening', () => {
      server.close();
      resolve(false);
    });
    server.listen(port, '0.0.0.0');
  });
}

/**
 * Finds the next available port in the 25501 - 25599 range
 */
async function allocateNextFreePort(preferredPort = null) {
  const usedPortsInDb = ServerModel.getAllUsedPorts();
  const min = CONFIG.PORT_RANGE.MIN; // 25501
  const max = CONFIG.PORT_RANGE.MAX; // 25599

  // If user requested a preferred port in range, check if it's free
  if (preferredPort && preferredPort >= min && preferredPort <= max) {
    if (!usedPortsInDb.has(preferredPort)) {
      const inUse = await isPortInUseOnHost(preferredPort);
      if (!inUse) {
        return preferredPort;
      }
    }
  }

  // Scan range
  for (let port = min; port <= max; port++) {
    if (!usedPortsInDb.has(port)) {
      const inUse = await isPortInUseOnHost(port);
      if (!inUse) {
        return port;
      }
    }
  }

  throw new Error(`No available ports in range ${min}-${max}`);
}

module.exports = {
  isPortInUseOnHost,
  allocateNextFreePort
};

