const { ServerModel } = require('../db/models');

/**
 * Parses RAM string to Megabytes (integer)
 * e.g. "1G" -> 1024, "512M" -> 512, "2" -> 2048, "1.5G" -> 1536
 */
function parseRamToMb(val) {
  if (!val) return 1024;
  const s = String(val).trim().toUpperCase();
  if (s.endsWith('M')) {
    return parseInt(s.slice(0, -1), 10) || 1024;
  }
  if (s.endsWith('G')) {
    const num = parseFloat(s.slice(0, -1));
    return isNaN(num) ? 1024 : Math.round(num * 1024);
  }
  if (s.endsWith('K')) {
    const num = parseFloat(s.slice(0, -1));
    return isNaN(num) ? 1024 : Math.round(num / 1024);
  }
  const num = parseFloat(s);
  if (isNaN(num)) return 1024;
  return num >= 32 ? Math.round(num) : Math.round(num * 1024);
}

/**
 * Parses CPU cores (integer)
 * e.g. "1" -> 1, "2.5" -> 2, 4 -> 4
 */
function parseCpu(val) {
  if (!val) return 1;
  const num = Math.round(parseFloat(val) || 1);
  return Math.max(1, Math.min(64, num));
}

/**
 * Parses Disk string to Gigabytes (integer)
 * e.g. "10G" -> 10, "1T" -> 1024, "500G" -> 500
 */
function parseDiskToGb(val) {
  if (!val) return 10;
  const s = String(val).trim().toUpperCase();
  if (s.endsWith('T')) {
    const num = parseFloat(s.slice(0, -1));
    return isNaN(num) ? 1024 : Math.round(num * 1024);
  }
  if (s.endsWith('G')) {
    const num = parseInt(s.slice(0, -1), 10);
    return isNaN(num) ? 10 : num;
  }
  if (s.endsWith('M')) {
    const num = parseFloat(s.slice(0, -1));
    return isNaN(num) ? 10 : Math.max(1, Math.round(num / 1024));
  }
  const num = parseInt(s, 10);
  return isNaN(num) ? 10 : num;
}

/**
 * Formats MB to friendly string
 * e.g. 1024 -> "1G", 512 -> "512M", 2048 -> "2G"
 */
function formatRam(mb) {
  if (mb % 1024 === 0) {
    return `${mb / 1024}G`;
  }
  return `${mb}M`;
}

/**
 * Formats GB to friendly string
 * e.g. 10 -> "10G", 1024 -> "1T"
 */
function formatDisk(gb) {
  if (gb >= 1024 && gb % 1024 === 0) {
    return `${gb / 1024}T`;
  }
  return `${gb}G`;
}

/**
 * Calculates current resource usage across all servers owned by a user
 */
function getUserResourceUsage(userId, excludeServerId = null) {
  const allServers = ServerModel.getByUserId(userId) || [];
  const servers = excludeServerId
    ? allServers.filter(s => s.id !== parseInt(excludeServerId, 10))
    : allServers;

  let totalUsedRamMb = 0;
  let totalUsedCpu = 0;
  let totalUsedDiskGb = 0;

  for (const s of servers) {
    totalUsedRamMb += parseRamToMb(s.memory_limit);
    totalUsedCpu += parseCpu(s.cpu_limit);
    totalUsedDiskGb += parseDiskToGb(s.disk_limit);
  }

  return {
    usedRamMb: totalUsedRamMb,
    usedCpu: totalUsedCpu,
    usedDiskGb: totalUsedDiskGb,
    serverCount: servers.length,
    totalServers: allServers.length
  };
}

/**
 * Calculates remaining available quota for a user
 */
function getUserQuota(user, excludeServerId = null) {
  const isAdmin = user.role === 'admin';

  const maxRamMb = parseRamToMb(user.ram_limit || '2G');
  const maxCpu = parseCpu(user.cpu_limit || 2);
  const maxDiskGb = parseDiskToGb(user.disk_limit || '20G');
  const maxServers = parseInt(user.max_servers, 10) || 3;

  const usage = getUserResourceUsage(user.id, excludeServerId);

  const availableRamMb = isAdmin ? 65536 : Math.max(0, maxRamMb - usage.usedRamMb);
  const availableCpu = isAdmin ? 64 : Math.max(0, maxCpu - usage.usedCpu);
  const availableDiskGb = isAdmin ? 10240 : Math.max(0, maxDiskGb - usage.usedDiskGb);
  const availableServers = isAdmin ? 999 : Math.max(0, maxServers - usage.serverCount);

  return {
    isAdmin,
    limits: {
      ramMb: maxRamMb,
      ramStr: formatRam(maxRamMb),
      cpu: maxCpu,
      diskGb: maxDiskGb,
      diskStr: formatDisk(maxDiskGb),
      maxServers
    },
    used: {
      ramMb: usage.usedRamMb,
      ramStr: formatRam(usage.usedRamMb),
      cpu: usage.usedCpu,
      diskGb: usage.usedDiskGb,
      diskStr: formatDisk(usage.usedDiskGb),
      serverCount: usage.serverCount,
      totalServersOwned: usage.totalServers
    },
    available: {
      ramMb: availableRamMb,
      ramStr: formatRam(availableRamMb),
      cpu: availableCpu,
      diskGb: availableDiskGb,
      diskStr: formatDisk(availableDiskGb),
      servers: availableServers
    }
  };
}

/**
 * Validates if the requested resources fit inside the user's quota
 */
function validateResourceAllocation(user, { ram, cpus, disk_size }, excludeServerId = null) {
  if (user.role === 'admin') {
    return { valid: true };
  }

  const requestedRamMb = parseRamToMb(ram);
  const requestedCpu = parseCpu(cpus);
  const requestedDiskGb = parseDiskToGb(disk_size);

  const quota = getUserQuota(user, excludeServerId);

  // Check server creation limit if new server
  if (!excludeServerId && quota.available.servers <= 0) {
    return {
      valid: false,
      message: `Server limit reached (${quota.limits.maxServers} VMs max). Delete an existing VM or contact admin to increase your limit.`
    };
  }

  // Check RAM Limit
  if (requestedRamMb > quota.available.ramMb) {
    return {
      valid: false,
      message: `RAM limit exceeded! You have ${quota.available.ramStr} RAM available (Total Quota: ${quota.limits.ramStr}), but requested ${formatRam(requestedRamMb)}.`
    };
  }

  // Check CPU Limit
  if (requestedCpu > quota.available.cpu) {
    return {
      valid: false,
      message: `CPU limit exceeded! You have ${quota.available.cpu} core(s) available (Total Quota: ${quota.limits.cpu} Cores), but requested ${requestedCpu} core(s).`
    };
  }

  // Check Disk Storage Limit
  if (requestedDiskGb > quota.available.diskGb) {
    return {
      valid: false,
      message: `Disk storage limit exceeded! You have ${quota.available.diskStr} available (Total Quota: ${quota.limits.diskStr}), but requested ${formatDisk(requestedDiskGb)}.`
    };
  }

  return {
    valid: true,
    quota
  };
}

module.exports = {
  parseRamToMb,
  parseCpu,
  parseDiskToGb,
  formatRam,
  formatDisk,
  getUserResourceUsage,
  getUserQuota,
  validateResourceAllocation
};

