const { verifyToken } = require('../utils/security');
const { UserModel, ServerModel, SubuserModel } = require('../db/models');

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.cookies && req.cookies.token) || req.query.token;

  if (!token) {
    return res.status(401).json({ success: false, message: 'Authentication required. No token provided.' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token.' });
  }

  const user = UserModel.findById(decoded.id);
  if (!user) {
    return res.status(401).json({ success: false, message: 'User not found.' });
  }

  if (user.status === 'suspended') {
    return res.status(403).json({ success: false, message: 'Your account has been suspended. Please contact the administrator.' });
  }

  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin privileges required.' });
  }
  next();
}

function requireModeratorOrAdmin(req, res, next) {
  if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'moderator')) {
    return res.status(403).json({ success: false, message: 'Moderator or Admin privileges required.' });
  }
  next();
}

/**
 * Checks if the requesting user has access to a specific server
 * (either owner, admin, or subuser with specific permission)
 */
function requireServerAccess(permission = null) {
  return (req, res, next) => {
    const serverId = parseInt(req.params.id || req.params.serverId, 10);
    if (!serverId) {
      return res.status(400).json({ success: false, message: 'Invalid server ID.' });
    }

    const server = ServerModel.findById(serverId);
    if (!server) {
      return res.status(404).json({ success: false, message: 'Server not found.' });
    }

    // Admins have universal access
    if (req.user.role === 'admin') {
      req.server = server;
      req.accessLevel = 'admin';
      return next();
    }

    // Owner has full access
    if (server.user_id === req.user.id) {
      req.server = server;
      req.accessLevel = 'owner';
      return next();
    }

    // Check subuser permissions
    const subuser = SubuserModel.findByServerAndUser(serverId, req.user.id);
    if (subuser) {
      let perms = [];
      try {
        perms = JSON.parse(subuser.permissions);
      } catch (e) {
        perms = [];
      }

      if (!permission || perms.includes('all') || perms.includes(permission)) {
        req.server = server;
        req.accessLevel = 'subuser';
        req.permissions = perms;
        return next();
      }
      return res.status(403).json({ success: false, message: `Access denied. Missing '${permission}' permission.` });
    }

    return res.status(403).json({ success: false, message: 'Access denied to this server.' });
  };
}

module.exports = {
  authenticateToken,
  requireAdmin,
  requireModeratorOrAdmin,
  requireServerAccess
};

