const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const CONFIG = require('../config');

// General media storage (logos, backgrounds, audio)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let subfolder = 'general';
    if (file.fieldname === 'logo' || file.fieldname === 'favicon') {
      subfolder = 'branding';
    } else if (file.fieldname === 'background') {
      subfolder = 'wallpapers';
    } else if (file.fieldname === 'music') {
      subfolder = 'audio';
    } else if (file.fieldname === 'avatar') {
      subfolder = 'avatars';
    }
    const dest = path.join(CONFIG.UPLOAD_DIR, subfolder);
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const safeName = `${uuidv4()}${ext}`;
    cb(null, safeName);
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  cb(null, true);
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB max
  }
});

// Temporary memory or disk storage for container file uploads
const containerFileUpload = multer({
  dest: path.join(CONFIG.DATA_DIR, 'tmp_uploads'),
  limits: {
    fileSize: 500 * 1024 * 1024 // 500MB max per upload
  }
});

module.exports = {
  upload,
  containerFileUpload
};

