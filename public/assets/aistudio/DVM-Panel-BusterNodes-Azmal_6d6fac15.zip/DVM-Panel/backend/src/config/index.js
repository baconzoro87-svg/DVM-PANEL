const path = require('path');
require('dotenv').config();

const ROOT_DIR = path.resolve(__dirname, '../../../');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT_DIR, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

const CONFIG = {
  PORT: parseInt(process.env.PORT || '3002', 10),
  WEB_PORT: parseInt(process.env.WEB_PORT || '3001', 10),
  JWT_SECRET: process.env.JWT_SECRET || 'dpanel_super_secret_jwt_key_2026_x89f_secure',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  ROOT_DIR,
  DATA_DIR,
  UPLOAD_DIR,
  BACKUP_DIR,
  DB_PATH: path.join(DATA_DIR, 'dpanel.sqlite'),
  PORT_RANGE: {
    MIN: 25501,
    MAX: 25599
  },
  DEFAULT_VM_SPECS: {
    NAME: 'vm1',
    HOSTNAME: 'vm1',
    RAM: '1G',
    CPUS: '1',
    DISK_SIZE: '10G'
  },
  SUPPORTED_IMAGES: [
    {
      id: 'nobitaa/ubuntu:22',
      name: 'Ubuntu 22.04 LTS (Jammy)',
      tag: 'nobitaa/ubuntu:22',
      category: 'Ubuntu',
      icon: 'ubuntu'
    },
    {
      id: 'nobitaa/ubuntu:24',
      name: 'Ubuntu 24.04 LTS (Noble)',
      tag: 'nobitaa/ubuntu:24',
      category: 'Ubuntu',
      icon: 'ubuntu'
    },
    {
      id: 'nobitaa/debain:11',
      name: 'Debian 11 (Bullseye)',
      tag: 'nobitaa/debain:11',
      category: 'Debian',
      icon: 'debian'
    },
    {
      id: 'nobitaa/debain:12',
      name: 'Debian 12 (Bookworm)',
      tag: 'nobitaa/debain:12',
      category: 'Debian',
      icon: 'debian'
    },
    {
      id: 'nobitaa/debain:13',
      name: 'Debian 13 (Trixie)',
      tag: 'nobitaa/debain:13',
      category: 'Debian',
      icon: 'debian'
    }
  ],
  WALLPAPER_CATEGORIES: [
    {
      name: 'Black / Dark',
      slug: 'black-dark',
      wallpapers: [
        { title: 'Abstract Dark Obsidian', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=400&auto=format&fit=crop' },
        { title: 'Dark Cyber Grid', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=400&auto=format&fit=crop' },
        { title: 'OLED Minimal Waves', url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?q=80&w=400&auto=format&fit=crop' }
      ]
    },
    {
      name: 'Aesthetic & Synthwave',
      slug: 'aesthetic-wallpapers',
      wallpapers: [
        { title: 'Neon Sunset Cyberpunk', url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=400&auto=format&fit=crop' },
        { title: 'Synthwave Highway', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=400&auto=format&fit=crop' },
        { title: 'Purple Aesthetic Skyline', url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=400&auto=format&fit=crop' }
      ]
    },
    {
      name: 'Space & Cosmos',
      slug: 'space',
      wallpapers: [
        { title: 'Deep Space Nebula', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=400&auto=format&fit=crop' },
        { title: 'Interstellar Galaxy', url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?q=80&w=400&auto=format&fit=crop' },
        { title: 'Cosmic Eclipse', url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?q=80&w=400&auto=format&fit=crop' }
      ]
    },
    {
      name: 'Cute & Kawaii',
      slug: 'cute-kawaii-wallpapers',
      wallpapers: [
        { title: 'Pastel Clouds & Stars', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=400&auto=format&fit=crop' },
        { title: 'Cute Pink Dreamscape', url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=400&auto=format&fit=crop' }
      ]
    },
    {
      name: 'Ultrawide & Cool',
      slug: 'ultrawide-monitor-hd-wallpapers',
      wallpapers: [
        { title: 'Cyber Mountain Sunset 4K', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=400&auto=format&fit=crop' },
        { title: 'Geometric Minimal Neon', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=400&auto=format&fit=crop' }
      ]
    },
    {
      name: 'CR7 & Sports',
      slug: 'cr7-wallpapers',
      wallpapers: [
        { title: 'Stadium Lights Gold Aura', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=400&auto=format&fit=crop' },
        { title: 'Dynamic Champions Energy', url: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?q=80&w=2560&auto=format&fit=crop', thumb: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?q=80&w=400&auto=format&fit=crop' }
      ]
    }
  ]
};

module.exports = CONFIG;

